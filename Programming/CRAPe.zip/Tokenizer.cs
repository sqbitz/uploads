﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Reflection;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

public class Tokenizer
{
	private List<Tuple<int, int, List<Token>>> lineTokens;
	public Dictionary<string, Type> ReferencedTypes;
	private SortedSet<string> referencedAssemblies;
	
	public Dictionary<string, Token> Variables;
	public Dictionary<string, Tuple<string, int>> Definitions;

	private List<Token> currLineTokens;	
	private string currLine;
	private int currLineNum;
	private Dictionary<int, int> lineLengths;
	
	private string currentFile = null;
	
	MyAutoComplete acTypes;
	MyAutoComplete acProps;
	
	int tokenizeCount = 0;
	
	private int usingLinesHash = -1;
	
	private object tokenizeTaskLock = new object();
	private Task tokenizeTask = null;
	private Regex regexLines = new Regex(".*", RegexOptions.Compiled);
		
	OutlineNode outlineNodeTop;
	OutlineNode outlineNodeCurrent;
	
	CancellationTokenSource cts;
	
	public EventHandler CompileErrors;
	
	public static Regex regexHTML = new Regex(@"(?<start>\</?)(\!doctype )?(?<tagName>\w+)(?<attr>\s*[\w-]+(=""[\w ,-=#';:@\?\(\)]*"")?)*(?<end>\s*/?\>)",
								RegexOptions.Compiled,
								TimeSpan.FromMilliseconds(500));
	public static Regex regexSQL = new Regex(@"SELECT |UPDATE |DELETE |FROM |INSERT INTO |(INNER|(LEFT|RIGHT) OUTER) JOIN| ON |WHERE |SET |(ORDER|GROUP) BY| (A|DE)SC|AND |OR |LIKE |LIMIT|=|>|<| IN |BETWEEN|MAX|MIN|SUM|AVG|COUNT|IFNULL|HAVING |DISTINCT | IS NULL|SUBSTR|(R|L)?TRIM|LENGTH|VALUES |REPLACE|EXPLAIN QUERY PLAN|CREATE (TABLE|VIEW|INDEX)|CONSTRAINT| AS \w+|'.*?'|\*",
								RegexOptions.Compiled,
								TimeSpan.FromMilliseconds(500));

	public Tokenizer(MyAutoComplete types, MyAutoComplete props)
	{
		currLineTokens = new List<Token>();
		lineTokens = new List<Tuple<int, int, List<Token>>>();
		
		referencedAssemblies = new SortedSet<string>();
		ReferencedTypes = new Dictionary<string, Type>();
		
		Variables = new Dictionary<string, Token>();
		Definitions = new Dictionary<string, Tuple<string, int>>();
		
		lineLengths = new Dictionary<int, int>();
		
		this.acTypes = types;
		this.acProps = props;
		
		outlineNodeTop = new OutlineNode() { Name = "file" };
		cts = new CancellationTokenSource();
	}
	
	public EventHandler<TokenizeCompleteEventArgs> TokenizeComplete;

	public void ShowACProps(int index, string name)
	{
		//Console.WriteLine("Show Props: " + index + " |" + name + "|");
		
		List<Token> tokens = null;
		lock(tokenizeTaskLock)
		{
			var lt = lineTokens.FirstOrDefault(x => index >= x.Item1 && index <= x.Item2);
			if(lt != null)
				tokens = lt.Item3;			
		}
		
		Token workingToken = null;
		Type workingType = null;

		//Console.WriteLine("\n\n-----------------------------------------------------");
		if(tokens != null)
		{
			//foreach(var t in tokens)
			//	Console.WriteLine(t);

			workingToken = tokens
				.Where(x => x.Type != typeof(object))
				.Where(x => 
					x.EndIndex == index -1
					|| x.EndIndex == index - 2
					|| (index >= x.StartIndex && index <= x.EndIndex))
				//.OrderByDescending(x => x.Type != typeof(object) ? 1 : 0)
				.LastOrDefault();
			if(workingToken != null && workingToken.Type != typeof(object))
			{
				workingType = workingToken.Type;
				name = "T " + workingToken.Name;
			}
		}

		if(workingType == null && Variables.ContainsKey(name))
			workingType = Variables[name].Type;
		if(workingType == null && ReferencedTypes.ContainsKey(name))
			workingType = ReferencedTypes[name];
		
		var tSplit = name.Split('.');
		if(workingType == null && tSplit.Length > 1)
		{	
			if(tokens != null)
			{
				var t = tokens.FirstOrDefault(x => x.Name == tSplit[0] && x.Type != typeof(object));
				if(t != null)
					workingType = t.Type;	
			}
			else if(Variables.ContainsKey(tSplit[0]))
			{
				//Console.WriteLine("Found " + tSplit[0] + " in Variables");
				workingType = Variables[tSplit[0]].Type;
			}
			
			if(workingType != null)
				for(var i = 1; i < tSplit.Length; i++)
				{
					MemberInfo match = workingType.GetMembers().FirstOrDefault(x => x.Name == tSplit[i]);
					if(match != null && match.MemberType == MemberTypes.Method)
						workingType = ((MethodInfo)match).ReturnType;
					else if(match != null && match.MemberType == MemberTypes.Property)
						workingType = ((PropertyInfo)match).PropertyType;
					else if(match != null && match.MemberType == MemberTypes.Field)
						workingType = ((FieldInfo)match).FieldType;
	
					//Console.WriteLine("TSplit: " + tSplit[i] + " " + match);
				}
		}

		//Console.WriteLine("name: " + name.PadRight(10) + " type: " + workingType);

		if(workingType != null && acProps.Visible == false)
		{
			//Console.WriteLine("name: " + name.PadRight(10) + " type: " + workingType);
			acProps.Clear();
			foreach(var m in workingType.GetMethods()
							.Where(x => x.IsPrivate == false)
							.Where(x => !x.Name.StartsWith("add_")
									&& !x.Name.StartsWith("set_")
									&& !x.Name.StartsWith("get_")
									&& !x.Name.StartsWith("remove_")))
				acProps.AddItem(m.Name, m.ReturnType, MyAutoComplete.ItemType.Method);			
			foreach(var p in workingType.GetProperties())
				acProps.AddItem(p.Name, p.PropertyType, MyAutoComplete.ItemType.Property);
			foreach(var e in workingType.GetEvents())
				acProps.AddItem(e.Name, e.EventHandlerType, MyAutoComplete.ItemType.Event);
			foreach(var f in workingType.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public))
				acProps.AddItem(f.Name, f.FieldType, MyAutoComplete.ItemType.Property);
			if(workingType.IsEnum)
				foreach(var e in workingType.GetEnumNames().OrderBy(x => x))
					acProps.AddItem(e, workingType, MyAutoComplete.ItemType.Enum);
	
	
			acProps.Open();
		}

	}
		
	public List<Tuple<int, int, List<Token>>> GetTokens()
	{
		lock(tokenizeTaskLock)
			return lineTokens;
	}
	
	public void Clear()
	{
		lock(tokenizeTaskLock)
		{
			Variables.Clear();
			lineTokens.Clear();
			currentFile = null;
		}
	}
	
	public List<Token> GetLineTokens(int charIndex)
	{
		lock(tokenizeTaskLock)
		{
			try
			{
			var lt = lineTokens.FirstOrDefault(x => charIndex >= x.Item1 && charIndex <= x.Item2);
			if(lt == null)
				return null;
				
			return lt.Item3;
			}
			catch(Exception) {}
			
			return null;
		}
	}
	
	public void CompileProject(List<string> referencedDLLs, CompilationErrors tabCompilationErrors, string projectType)
	{
		var compileErrorRegex = new Regex(@"(?<path>\w:(\\[\w\s]+)+)\\(?<filename>[\w\s]+\.\w\w)\((?<sLine>\d+),(?<sColumn>\d+),(?<eLine>\d+),(?<eColumn>\d+)\): error \w+: (?<error>.*)");

		/*
		var jsCompiler = new Microsoft.JScript.JScriptCodeProvider();
		var jsFiles = Directory.EnumerateFiles(".", "*.js", SearchOption.AllDirectories);
		var jsResults = jsCompiler.CompileAssemblyFromFile(new System.CodeDom.Compiler.CompilerParameters(), jsFiles.ToArray());
		foreach(var jsr in jsResults.Output)
			Console.WriteLine(jsr);
		*/

		using(var compiler = System.CodeDom.Compiler.CodeDomProvider.CreateProvider("C#"))
		{
			var references = new List<string>{ 
				"mscorlib.dll",
				"System.dll",
				"System.Core.dll",
				"System.Data.dll",
				"System.Data.Linq.dll",
				"System.Data.Entity.dll",
				"System.Windows.Forms.dll",
				"System.Drawing.dll",
				"System.Xml.dll",
				"System.Web.dll",
				"System.Web.Extensions.dll",
				"System.Runtime.Serialization.Json.dll"
			};
			
			references.AddRange(referencedDLLs);
			
			var outputPath = "development.dll";
			var binPath = Path.Combine(Application.StartupPath, "bin");
			if(Directory.Exists(binPath))
				outputPath = Path.Combine(binPath, outputPath);
			
			var options= new System.CodeDom.Compiler.CompilerParameters(references.ToArray(), outputPath, true) {
				GenerateInMemory = true,
				GenerateExecutable = false,
				CompilerOptions = "/errorendlocation /lib:bin /t:" + projectType
			};
			
			var currDir = Directory.GetCurrentDirectory();
			var files = System.IO.Directory.EnumerateFiles(currDir, "*.cs", SearchOption.AllDirectories)
									.Where(x => x.Contains("\\backups") == false)
									.ToArray();
			//foreach(var f in files)
			//	Console.WriteLine(f);
			var results = compiler.CompileAssemblyFromFile(options, files);
	
			/*tabCompilationErrors.Clear();
			foreach(System.CodeDom.Compiler.CompilerError err in results.Errors)
			{
				var m = compileErrorRegex.Match(err);
				if(m.Success)
					tabCompilationErrors.Add(err.FileName, 
									err.Line.ToString(), err.Column.ToString(), 
									"0", "0", //m.Groups["eLine"].Value, m.Groups["eColumn"].Value,
									err.ErrorText);
	
				Console.WriteLine("Error: " + err);
			}*/
	
			tabCompilationErrors.Clear();
			foreach(var o in results.Output)
			{
				var m = compileErrorRegex.Match(o);
				if(m.Success)
				{
					var fileName = m.Groups["filename"].Value;
					var path = m.Groups["path"].Value;
					path = path.Substring(1).Replace(currDir.Substring(1), ""); //Some do c: some do C:
					
					tabCompilationErrors.Add(Path.Combine(path, fileName).TrimStart('\\'), 
									m.Groups["sLine"].Value, m.Groups["sColumn"].Value, 
									m.Groups["eLine"].Value, m.Groups["eColumn"].Value,
									m.Groups["error"].Value);
				}
				//Console.WriteLine("Output: " + o);
			}
	
			if(tabCompilationErrors.ErrorCount > 0)
			{
				//Console.WriteLine("Unable to background compile");
				var errors = tabCompilationErrors.GetFileErrors(currentFile);
				CompileErrors(errors, null);
				
				var tabControl = tabCompilationErrors.Parent as TabControl;
				tabControl.SelectTab(tabCompilationErrors);
				
				return;
			}
			
			try
			{
				Assembly ass = results.CompiledAssembly;
				foreach(var t in ass.GetTypes())
				{
					var typeName = t.Name;
	
					if(typeName.Contains("."))
						typeName = typeName.Substring(typeName.LastIndexOf(".") + 1);
	
					ReferencedTypes[typeName] = t;
				}
			}
			catch(Exception) {}
		}
	}
	
	public bool Tokenize(string text, string[] lines, string fileName, int currentLineNum, string currentLine, bool partialTokenize)
	{				
		currentFile = fileName;
		currLine = currentLine;
		currLineNum = currentLineNum;
		
		if(tokenizeTask == null || tokenizeTask.IsCompleted)
		{
			tokenizeCount++;
			//Console.WriteLine("Tokenize " + tokenizeCount.ToString().PadLeft(5) + " " + fileName);
			tokenizeTask = Task.Run(() => {
				if(fileName.EndsWith("cs") || fileName.EndsWith("js"))
					tokenizeCS(text, lines, partialTokenize, cts.Token);
				else if(fileName.EndsWith("html"))
					tokenizeHTML(text, cts.Token);
				else if(fileName.Trim() == "SQL Editor")
					tokenizeSQL(text, cts.Token);
			}, cts.Token);	
			return true;
		}
		else
			return false;
	}
		
	private void tokenizeCS(string text, string[] splitLines, bool partialTokenize, CancellationToken ct)
	{
		var sw = new Stopwatch();
		sw.Start();
		//var splitLines = text.Split('\n');

		//May want to come back to this at some point... I think I've got it working right now though
		partialTokenize = false;
		
		updateReferences(splitLines);

		//for(var i = 0; i < splitLines.Length; i++)
		//	Console.WriteLine(splitLines[i].Replace("\n", "~").Replace("\t", "_____"));
		//Console.WriteLine(text.Replace("\n", "~\n").Replace("\t", "_____"));
		
		int lineNum = 0;
		
		int multiLineCommentStart = -1;
		int multiLineCommentEnd = -1;

		outlineNodeTop.Nodes.Clear();
		outlineNodeCurrent = null;		
		
		var tokens = new List<Token>();
		
		if(partialTokenize)
		{
			text = currLine;
			splitLines = new string[] { text };
			currLineTokens.Clear();
		}
		else
		{
			for(var i = 0; i < splitLines.Length; i++)
				lineLengths[i] = splitLines[i].Length;
			
			lineTokens.Clear();
		}
		
		
		
		var index = 0;
		for(var line = 0; line < splitLines.Length; line++)
		{
			if(ct.IsCancellationRequested)
			{
				Console.WriteLine("Cancel request");
				return;
			}
				
			var currLineNum = line;
			var currLineFirstCharIndex = index;
			var c = splitLines[currLineNum];			
			
			//Console.WriteLine(currLineNum.ToString().PadRight(5) + index.ToString().PadRight(5) + c.Replace("\t", "_").Replace("\n", "~"));
						
			try
			{
				if(string.IsNullOrWhiteSpace(c))
				{
					//Console.WriteLine("Skip " + line + " " + index + " " + c.Length);
					index += c.Length + 1;	//+1 for the \n
					continue;
				}
	
				var endIndex = index + c.Length;
	
				tokens.Clear();
				var sb = new StringBuilder();
	
				var splitTokens = new [] {
					' ',
					'.',
					';',
					':',
					',',
					'(', ')',
					'[', ']',
					'{', '}',
					'\n'
				};
				var opTokens = new [] {
					'?', '!',
					'|', '&',
					'+', '-', '*', '/',
					'=',
					'<', '>'
				};
				
				//Skip lines that consist of just a splitToken
				if(splitTokens.Any(x => x.ToString() == c.Trim()))
				{
					//Console.WriteLine("Skip T" + c + " " + line + " length:" + c.Length);
					index += c.Length + 1;	//+1 for the \n
					continue;
				}
				
				var endChar = ';';
				var lineNoSpace = c.Replace(" ", "").ToLower().Trim();
								
				bool foundStatementEnd = false;
	
				var nextTokenType = TokenType.None;
				var level = 0;
				//Console.WriteLine(lineNoSpace);
				
				int substringLength;
				
				var multiLineStmts = new [] {
					"for", 
					"foreach", 
					"while", 
					"if", 
					"elseif", 
					"else",
					"using",
					"lock"
				};
				var typeDeclarationStmts = new [] {
					"public",
					"protected",
					"private",
					"try",
					"catch"
				};
				
				
				if(typeDeclarationStmts.Any(x => lineNoSpace.StartsWith(x)))				
					endChar = '{';
					
				//Handle variable declarations (this only works with single line)
				if(typeDeclarationStmts.Any(x => lineNoSpace.StartsWith(x) && lineNoSpace.EndsWith(";")))
					endChar = ';';
					
				//Handle comments that are the whole line
				if(lineNoSpace.Trim().StartsWith("//"))
					endChar = '\n';
					
				if(multiLineStmts.Any(x => lineNoSpace.StartsWith(x + "(")))
				{
					var parenCount = 1;
					var inDoubleQuote = false;
					var inSingleQuote = false;
					int searchIndex = c.IndexOf("(") + index + 1;
					bool good = true;						
					
					while(parenCount != 0)
					{
						//This will normally occur while the user is typing... nothing to worry about
						if(searchIndex >= text.Length)
						{	
							//Console.WriteLine("Unable to find Paren\n" + c);
							return;
						}
						
						if(text[searchIndex] == '"' && text[searchIndex - 1] != '\\' && !inSingleQuote)
							inDoubleQuote = !inDoubleQuote;
						if(text[searchIndex].ToString() == "'" && text[searchIndex + 1].ToString() != "'" && !inDoubleQuote)
							inSingleQuote = !inSingleQuote;
								
						if(text[searchIndex] == '(' && !inDoubleQuote && !inSingleQuote)
							parenCount++;
						if(text[searchIndex] == ')' && !inDoubleQuote && !inSingleQuote)
							parenCount--;
							
						//Console.Write(text[searchIndex] + " " + searchIndex + " " + parenCount);
						//Console.ReadLine();
														
						searchIndex++;											
					}
					
					substringLength = searchIndex - index;
					
					var y = index + substringLength;
					while(y < text.Length - 1 && text[y++] != '\n')
						substringLength++;
				}
				else
				{
					substringLength = text.IndexOf(endChar, index) - index + (endChar == ';' ? 1 : 0);
					
					var y = index + substringLength;
					while(y < text.Length - 1 && text[y++] != '\n')
						substringLength++;

					//We might have trailing characters after  endChar
					if(substringLength < c.Length)
					{
						substringLength = c.Length;
						//Console.WriteLine(c + " " + substringLength);
					}
				}
					

				if(substringLength < 0)
				{
					index += c.Length + 1;	//+1 for the \n
					continue;
				}
				endIndex = index + substringLength;
				
				var workingSet = text.Substring(index, substringLength);
				//Console.WriteLine("\n" + line.ToString().PadRight(6) + c);
				//Console.WriteLine(line.ToString().PadRight(5) + "|" + workingSet.Replace("\n", "~").Replace("\t", "_") + (endChar == '\n' ? "\\" : "|") + substringLength);
								
				int currStartIndex = 0;
				while(workingSet[currStartIndex] == '\t' || workingSet[currStartIndex] == '\n' || workingSet[currStartIndex] == ' ')
					currStartIndex++;

				//Increase the  line  variable to account for newlines in the workingSet					
				var workingSetNewLines = workingSet.Count(x => x == '\n');				
				line += workingSetNewLines;
										
				int i = currStartIndex;				
				while(i < workingSet.Length && workingSet[i] != endChar)
				{					
					var currChar = workingSet[i];
					//Console.WriteLine(i.ToString().PadRight(5) + currChar.ToString() + " " + (i + currLineFirstCharIndex).ToString().PadRight(5) + text[i + currLineFirstCharIndex]);
															
					if(splitTokens.Any(x => x == currChar))
					{
						//if(i - 1 > 0 && splitTokens.Any(x => x == workingSet[i-1]))
						//{
						//	i++;
						//	continue;	 //Skip consecutive split tokens
						//}
						
						foundStatementEnd = currChar == ';';
						
						var splitCharToken = new Token(currChar.ToString(),
									i + currLineFirstCharIndex,
									i + currLineFirstCharIndex,
									level,
									TokenType.SplitChar);							
	
						var t = new Token(sb.ToString(), 
									currStartIndex + currLineFirstCharIndex,
									(i - 1) + currLineFirstCharIndex,
									level,
									nextTokenType);
						nextTokenType = TokenType.None;
	
						if(currChar == '(' || currChar == '[' || currChar == '{')
							level++;
						else if(currChar == ')' || currChar == ']' || currChar == '}')
						{							
							level--;
							splitCharToken.Level--;
							var prev = tokens.LastOrDefault(x => x.Level == level);
							if(prev != null) //Could occur for a cast... not sure how to handle that yet.
								prev.EndIndex = i + currLineFirstCharIndex;
						}
	
						if(currChar == '(')
						{
							t.TokenType = TokenType.Method;
						}
						else if(currChar == '.')
						{
							t.TokenType = TokenType.Class;
							nextTokenType = TokenType.Property;
						}
						else if(currChar == '[' && tokens.Any(x => x.Name == "new"))
						{
							sb.Append(currChar);
							while(i < workingSet.Length - 1 && workingSet[++i] != ']')
								sb.Append(workingSet[i]);
							sb.Append(workingSet[i]);

							t.TokenType = TokenType.Class;
							t.Type = typeof(Array);
							t.Name = sb.ToString().Trim();
							t.EndIndex = i + currLineFirstCharIndex;;
						}
	
						sb = new StringBuilder();
	
						currStartIndex = ++i;
	
						if(!string.IsNullOrEmpty(t.Name))
							tokens.Add(t);
							
						if(!char.IsWhiteSpace(currChar))
							tokens.Add(splitCharToken);
	
						continue;
					}
	
					if(opTokens.Any(x => x == currChar))
					{
						bool isGeneric = false;
						if(sb.Length > 0)
						{
							var t = new Token(sb.ToString(),
								currStartIndex + currLineFirstCharIndex,
								(i - 2) + currLineFirstCharIndex,
								level,
								nextTokenType
							);
							tokens.Add(t);
							
							if(ReferencedTypes.ContainsKey(t.Name) && ReferencedTypes[t.Name].IsGenericType)
							{
								isGeneric = true;
								sb.Append(workingSet[i]);
								while(i < workingSet.Length - 1 && workingSet[++i] != '>')
									sb.Append(workingSet[i]);
								sb.Append(workingSet[i]);
								
								var gt = ReferencedTypes[t.Name];
								//t.Type = Type.GetType(gt.Name.Replace("T", "string"), false);
								t.Type = gt;
								t.Name = sb.ToString().Trim();
								t.EndIndex = i + currLineFirstCharIndex;
								sb = new StringBuilder();
								currStartIndex = i;
								i++;
								continue;
							}
						}
								
						sb = new StringBuilder();
						currStartIndex = i;
	
						//Operations aren't longer than 2 characters
						sb.Append(currChar);
						if(i+1 < workingSet.Length && opTokens.Any(x => x == workingSet[i+1]))
							sb.Append(workingSet[++i]);
							
						var ot = new Token(sb.ToString(),
									currStartIndex + currLineFirstCharIndex,
									i + currLineFirstCharIndex,
									level,
									TokenType.Operation);
						
						if(sb.ToString() == "//")
						{
							var newLineDistance = workingSet.IndexOf("\n", i) - i;
							if(newLineDistance < 0)
								ot.Name = workingSet.Trim();
							else 
								ot.Name = "/" + workingSet.Substring(i, newLineDistance).Trim();

							ot.EndIndex = i + ot.Name.Length + currLineFirstCharIndex - 2;
							ot.TokenType = TokenType.Comment;
							i += ot.Name.Length - 1;
						}
						else if(sb.ToString() == "/*")
						{
							multiLineCommentStart = i + currLineFirstCharIndex - 2;  //-2 to include the slash star
							multiLineCommentEnd = -1;
						}
						else if(sb.ToString() == "*/")
							multiLineCommentEnd = i + currLineFirstCharIndex;
	
						tokens.Add(ot);
	
						sb = new StringBuilder();
						currStartIndex = ++i;
						continue;
					}
	
					//Handle numbers with periods mainly
					if(sb.Length == 0 && char.IsDigit(currChar))
					{
						var numTerminators = new [] { ',', ';', ')', '&', '|', '<', '>', ']' }.Union(opTokens).Distinct();
						while(numTerminators.Any(x => x == workingSet[i]) == false)
							sb.Append(workingSet[i++]);
	
						//Go Back one from the terminator
						i--;
					}
					else //Everything else
						sb.Append(currChar);
	
					if(currChar == '"') //Handle Strings
					{
						while(i < workingSet.Length - 1 && workingSet[++i] != '"')
							sb.Append(workingSet[i]);
						sb.Append(workingSet[i]); //Tack on the last quote
					}
	
					if(currChar.ToString() == "'") //Handle Chars
					{
						//Console.WriteLine("Char" + workingSet);
						if(++i < workingSet.Length)
						{
							sb.Append(workingSet[i]);
							if(workingSet[i] == '\\')
								sb.Append(workingSet[++i]); //Append the escaped character
						}
						sb.Append(workingSet[++i]); //Append closing tick							
					}

					i++;
				}
	
				if(!string.IsNullOrEmpty(sb.ToString().Trim()))
					tokens.Add(new Token(sb.ToString().TrimEnd(),
									currStartIndex + currLineFirstCharIndex,
									(i - 1) + currLineFirstCharIndex,
									level,
									nextTokenType));
				
				if(endChar == ';')
					tokens.Add(new Token(";",
							i + currLineFirstCharIndex,
							i + currLineFirstCharIndex,
							level,
							TokenType.SplitChar));
					
				foreach(var l in tokens)
				{
					int it;
					double d;
					decimal de;
					float f;
					bool b;
					if((l.Name.StartsWith("\"") || l.Name.StartsWith("@\"")) && l.Name.EndsWith("\""))
						l.Type = typeof(string);
					else if(l.Name.StartsWith("'") && l.Name.EndsWith("'"))
						l.Type = typeof(char);
					else if(int.TryParse(l.Name, out it))
						l.Type = typeof(int);
					else if(l.Name.EndsWith("d") && double.TryParse(l.Name.TrimEnd('d'), out d))
						l.Type = typeof(double);
					else if(l.Name.EndsWith("m") && decimal.TryParse(l.Name.TrimEnd('m'), out de))
						l.Type = typeof(decimal);
					else if(bool.TryParse(l.Name, out b))
						l.Type = typeof(bool);	
					else if(ReferencedTypes.ContainsKey(l.Name))
						l.Type = ReferencedTypes[l.Name];						
					else if(Variables.ContainsKey(l.Name))
						l.Type = Variables[l.Name].Type;
					else if(l.TokenType == TokenType.Property)
					{
						var prev = tokens[tokens.IndexOf(l) - 2];
						if(prev.Type.IsEnum)
							l.Type = prev.Type;
						else
						{
							var propType = prev.Type.GetProperties().FirstOrDefault(x => x.Name == l.Name);
							if(propType != null)
								l.Type = propType.PropertyType;
						}
					}	
						
					if(multiLineCommentStart >= 0 && l.StartIndex >= multiLineCommentStart && (multiLineCommentEnd == -1 || l.EndIndex <= multiLineCommentEnd))
						l.TokenType = TokenType.Comment;
				}
				
				foreach(var methodToken in tokens.Where(x => x.TokenType == TokenType.Method))
				{
					var methodTokenIndex = tokens.IndexOf(methodToken);
					if(methodTokenIndex < 0)
						continue;
						
					//Console.WriteLine("working : " + methodToken.Name + " " + methodToken.StartIndex);
						
					var methodClassToken = tokens.LastOrDefault(x => x.Level == methodToken.Level && x.TokenType != TokenType.SplitChar && x.StartIndex < methodToken.StartIndex);					
					if(methodClassToken == null)							
						continue;

					var methodInfo = methodClassToken.Type.GetMethods().FirstOrDefault(x => x.Name == methodToken.Name);
					if(methodInfo != null)
						methodToken.Type = methodInfo.ReturnType;
				}
				
				foreach(var assignToken in tokens.Where(x => x.TokenType == TokenType.Operation && x.Name == "="))
				{
					var assignTokenIndex = tokens.IndexOf(assignToken);
					if(assignTokenIndex <= 0)
						continue;
					
					try
					{
						var variable = tokens[assignTokenIndex - 1];
						variable.Type = tokens[assignTokenIndex + 1].Type;
	
						if(assignTokenIndex + 1 < tokens.Count && tokens[assignTokenIndex + 1].Name == "new")
							variable.Type = tokens[assignTokenIndex + 2].Type;
	
						if(assignTokenIndex - 2 >= 0 && tokens[assignTokenIndex - 2].Type != typeof(object))
							variable.Type = tokens[assignTokenIndex - 2].Type;
	
						var lastMethodToken = tokens.LastOrDefault(x => x.TokenType == TokenType.Method
											&& x.Type != typeof(object)
											&& x.Level == variable.Level);
						if(lastMethodToken != null)
							variable.Type = lastMethodToken.Type;
	
						Variables[variable.Name] = variable;
						Definitions[variable.Name] = Tuple.Create("", variable.StartIndex);
						acTypes.AddItem(variable.Name, variable.Type, MyAutoComplete.ItemType.Variable);	
					}
					catch(Exception)
					{}
				}
				
				//Handle type definitions like   public string a;
				if(tokens.Count == 3 && tokens[1].Type != null && typeDeclarationStmts.Any(x => x == tokens[0].Name))
				{				
					tokens[2].Type = tokens[1].Type;
					Variables[tokens[2].Name] = tokens[2];
					acTypes.AddItem(tokens[2].Name, tokens[2].Type, MyAutoComplete.ItemType.Variable);
				}
									
				var oct = tokens.FirstOrDefault(x => x.Name == "class");
				if(oct != null)
				{
					if(outlineNodeCurrent != null)
						outlineNodeTop.Nodes.Add(outlineNodeCurrent);
						
					var classNameToken = tokens[tokens.IndexOf(oct) + 1];
					outlineNodeCurrent = new OutlineNode("class " +classNameToken.Name, classNameToken.StartIndex);
				}

				var mt = tokens.FirstOrDefault(x => x.TokenType == TokenType.Method);
				if(mt != null && (tokens[0].Name == "public" || tokens[0].Name == "protected" || tokens[0].Name == "private"))
				{
					outlineNodeCurrent.AddNode(mt);
					
					Definitions[mt.Name] = Tuple.Create("", mt.StartIndex);
					
					var firstArgToken = tokens.FirstOrDefault(x => x.Level == 1);
					var lastArgToken = tokens.LastOrDefault(x => x.Level == 1);
					if(firstArgToken != null && lastArgToken != null && tokens.Any(x => x.Name == "<" || x.Name == ">") == false)
					{
						for(var argI = tokens.IndexOf(firstArgToken); argI < tokens.IndexOf(lastArgToken); argI++)
						{
							if(ReferencedTypes.ContainsKey(tokens[argI].Name))
							{
								//Console.WriteLine(tokens[argI].Name + " T" + ReferencedTypes[tokens[argI].Name]);
								//Console.WriteLine(tokens[argI + 1].Name);
								
								tokens[argI].Type = ReferencedTypes[tokens[argI].Name];
								tokens[argI + 1].Type = tokens[argI].Type;
								
								Variables[tokens[argI + 1].Name] = tokens[argI + 1];
								acTypes.AddItem(tokens[argI + 1].Name, tokens[argI + 1].Type, MyAutoComplete.ItemType.Variable);

							}
							
							argI++;
						}
					}
				}
				
				/*
				var jsInterpolateVarRegex = new Regex(@"\$\{.*?\}", RegexOptions.Compiled);
				var interpolatedVars = jsInterpolateVarRegex.Matches(workingSet);
				foreach(Match match in interpolatedVars)
					tokens.Add(new Token(match.Value,
									match.Index + currLineFirstCharIndex,
									match.Index + match.Length + currLineFirstCharIndex,
									0,
									TokenType.InterpolatedVariable));
				*/	
				if(tokens.Any())
					lock(tokenizeTaskLock)
					{
						if(partialTokenize)
							currLineTokens.AddRange(tokens);
						else
							lineTokens.Add(Tuple.Create(currLineFirstCharIndex, tokens.Max(x => x.EndIndex), tokens.ToList()));
					}
										
				//Console.WriteLine(currLineNum.ToString().PadRight(6) + index.ToString().PadRight(6)+ endIndex.ToString().PadRight(6)+ workingSet);
				index += workingSet.Length + 1;	//+1 for the \n				
			}
			catch(Exception ex)
			{
				//Console.WriteLine(c);
				//foreach(var t in tokens)
				//	Console.WriteLine(t);
				//Console.WriteLine(ex);
			}			
		}
		
		outlineNodeTop.Nodes.Add(outlineNodeCurrent);
		
		//lock(tokenizeTaskLock)
		//	Console.WriteLine("Tokenize Complete: " + lineTokens.Count + " tokens on text of length:" + text.Length + " Took:" + sw.ElapsedMilliseconds);
			
		TokenizeComplete(this, new TokenizeCompleteEventArgs{
			TimeElapsed = sw.ElapsedMilliseconds,
			Outline = outlineNodeTop
		});
	}
	
	private void tokenizeHTML(string text, CancellationToken ct)
	{
		var sw = new Stopwatch();
		sw.Start();
		
		var tokens = new List<Token>();
		lineTokens.Clear();
		
		outlineNodeTop.Nodes.Clear();
		outlineNodeCurrent = null;
		
		var splitLines = text.Split('\n');
		
		//Console.Write("|" + splitLines.Length);
		
		var index = 0;
		var level = 0;
		for(var line = 0; line < splitLines.Length; line++)
		{
			if(ct.IsCancellationRequested)
			{
				Console.WriteLine("Cancel request");
				return;
			}
			
			var currLineNum = line;
			var currLineFirstCharIndex = index;
			var c = splitLines[currLineNum];
			
			if(string.IsNullOrWhiteSpace(c))
			{
				//Console.WriteLine("Skip " + line + " " + index);
				index += c.Length + 1;	//+1 for the \n
				continue;
			}
		
			tokens.Clear();
			
			var commentStart = c.IndexOf("<!--");
			var commentEnd = c.IndexOf("-->");
			if(commentStart >= 0 && commentEnd > 4)
				tokens.Add(new Token(c.Substring(commentStart, commentEnd - commentStart + 3),
								currLineFirstCharIndex + commentStart,
								currLineFirstCharIndex + commentEnd + 2,
								level,
								TokenType.Comment));
			
			MatchCollection matches;
			try
			{
				matches = regexHTML.Matches(c);	
			}
			catch(Exception ex)
			{
				continue;
			}
			
			foreach(Match m in matches)
			{	
				var isCloseTag = m.Value.Trim().StartsWith("</");
				if(isCloseTag == false)
					level++;

				foreach(var g in new[] { "start", "tagName", "attr", "end"})
				{
					var group = m.Groups[g];
					if(g == "attr")
					{
						foreach(Capture attr in m.Groups["attr"].Captures)
						{
							var equalIndex = attr.Value.IndexOf("=");
							string name = attr.Value, value = "";
							if(equalIndex > 0)
							{
								name = attr.Value.Substring(0, equalIndex);
								value = attr.Value.Substring(equalIndex + 1);
							}
							
							tokens.Add(new Token(name,
									currLineFirstCharIndex + attr.Index,
									currLineFirstCharIndex + attr.Index + name.Length - 1,
									level + 2,
									TokenType.HTMLAttributeName));
									
							if(equalIndex > 0)
								tokens.Add(new Token(value,
										currLineFirstCharIndex + attr.Index + name.Length + 1,
										currLineFirstCharIndex + attr.Index + name.Length + value.Length,
										level + 2,
										TokenType.HTMLAttributeValue));		
									
						}
					}
					else
					{
						var t = new Token(group.Value,
									currLineFirstCharIndex + group.Index,
									currLineFirstCharIndex + group.Index + group.Value.Length - 1,
									level,
									g == "tagName" ? TokenType.HTMLTagName : TokenType.HTMLTag);
						tokens.Add(t);
						
						if(g == "tagName" && group.Value.ToLower() == "a" && isCloseTag == false)
						{			
							if(outlineNodeCurrent != null)
								outlineNodeTop.Nodes.Add(outlineNodeCurrent);
						
							outlineNodeCurrent = new OutlineNode(m.Value, t.StartIndex);
						}
					}
				}				
											
				if(m.Value.Trim().StartsWith("</"))
					level--;
			}
		
			if(tokens.Any())
				lock(tokenizeTaskLock)
					lineTokens.Add(Tuple.Create(currLineFirstCharIndex, tokens.Max(x => x.EndIndex), tokens.ToList()));
					
			index += c.Length + 1; //+1 for the \n
		}
		
		outlineNodeTop.Nodes.Add(outlineNodeCurrent);
		
		//Console.Write("|Took" + sw.ElapsedMilliseconds + "|");
		TokenizeComplete(this, new TokenizeCompleteEventArgs{
			TimeElapsed = sw.ElapsedMilliseconds,
			Outline = outlineNodeTop
		});
	}
	
	private void tokenizeSQL(string text, CancellationToken ct)
	{
		var sw = new Stopwatch();
		sw.Start();
		
		var tokens = new List<Token>();
		lineTokens.Clear();
		
		outlineNodeTop.Nodes.Clear();
		outlineNodeCurrent = null;
		
		var splitLines = text.Split('\n');
		
		//Console.Write("|" + splitLines.Length);
		
		var index = 0;
		var level = 0;
		for(var line = 0; line < splitLines.Length; line++)
		{
			if(ct.IsCancellationRequested)
			{
				Console.WriteLine("Cancel request");
				return;
			}
			
			var currLineNum = line;
			var currLineFirstCharIndex = index;
			var c = splitLines[currLineNum];
			
			if(string.IsNullOrWhiteSpace(c))
			{
				//Console.WriteLine("Skip " + line + " " + index);
				index += c.Length + 1;	//+1 for the \n
				continue;
			}
		
			tokens.Clear();
			
			
			MatchCollection matches;
			try
			{
				matches = regexSQL.Matches(c);	
			}
			catch(Exception ex)
			{
				continue;
			}
			
			foreach(Match m in matches)
			{	
				var tt = TokenType.SQLKeyword;
				
				//Just use HTML stuff here so we don't have any additional coding
				if(m.Value.StartsWith("'") && m.Value.EndsWith("'"))
					tt = TokenType.HTMLAttributeValue;
				else if(m.Value == "*")
					tt = TokenType.HTMLTagName;
				else if(m.Value.StartsWith(" AS "))
					tt = TokenType.HTMLAttributeName;
				
				var t = new Token(m.Value,
							currLineFirstCharIndex + m.Index,
							currLineFirstCharIndex + m.Index + m.Value.Length - 1,
							0,
							tt);
				tokens.Add(t);
			}
		
			if(tokens.Any())
				lock(tokenizeTaskLock)
					lineTokens.Add(Tuple.Create(currLineFirstCharIndex, tokens.Max(x => x.EndIndex), tokens.ToList()));
					
			index += c.Length + 1; //+1 for the \n
		}
		
		
		//Console.Write("|Took" + sw.ElapsedMilliseconds + "|");
		TokenizeComplete(this, new TokenizeCompleteEventArgs{
			TimeElapsed = sw.ElapsedMilliseconds,
			Outline = outlineNodeTop
		});
	}
	
	
	private void updateReferences(string[] lines)
	{
		var usingLines = lines
				.Take(50)
				.Where(x => x.StartsWith("using ") && x.EndsWith(";"))
				.Select(x => x.Replace("using ", "")
						.TrimEnd(';'));

		var currHash = bastardHash(usingLines);

		//Check if we have added or removed "using" lines
		if(usingLinesHash == currHash)
			return;

		//Console.WriteLine("\n\n\n\n\nusing lines have changed... updating references  " + usingLines.Count());
		//Update the new count and run
		usingLinesHash = currHash;

		//var types = new SortedSet<string>();

		referencedAssemblies.Clear();
		acTypes.Clear();
		ReferencedTypes.Clear();

		var namespaceTypes = new Dictionary<string, Dictionary<string, Type>>();

		//This is not really correct... if we were to include any additional assemblies they would
		//not be loaded here, because myType is always IDE (not the code that is being developed)
		var assem = this.GetType().Assembly;
		foreach(var assName in assem.GetReferencedAssemblies()
			.Where(x => !x.Name.Contains("IDE"))
			.OrderBy(x => x.Name))
		{
			var ass = Assembly.Load(assName);

			var types = ass.GetTypes();
			foreach(var t in types
				.Where(x => !string.IsNullOrEmpty(x.Namespace) && x.IsPublic))
			{
				var typeName = t.Name;
				if(usingLines.Contains(t.Namespace) == false)
					continue;

				if(typeName.Contains("."))
					typeName = typeName.Substring(typeName.LastIndexOf(".") + 1);
				if(typeName.Contains("`"))
				{
					typeName = typeName.Substring(0, typeName.IndexOf("`"));
					if(ReferencedTypes.ContainsKey(typeName))
						continue;
				}
				acTypes.AddItem(typeName, t, MyAutoComplete.ItemType.Class);
				ReferencedTypes[typeName] = t;
			}
		}

		var baseTypes = new Dictionary<string, Type>();
		baseTypes["string"] = typeof(string);
		baseTypes["char"] = typeof(char);
		baseTypes["int"] = typeof(int);
		baseTypes["decimal"] = typeof(decimal);
		baseTypes["double"] = typeof(double);
		baseTypes["float"] = typeof(float);
		baseTypes["long"] = typeof(long);
		baseTypes["bool"] = typeof(bool);
		
		foreach(var t in baseTypes)
		{
			acTypes.AddItem(t.Key, t.Value, MyAutoComplete.ItemType.Class);
			ReferencedTypes[t.Key] = t.Value;
		}
	}
	
	private int bastardHash(IEnumerable<string> input)
	{
		var hash = 0;
		int lineCount = 0;
		foreach(var l in input)
		{
			for(int i = 0; i < l.Length; i++)
				hash += lineCount + (int)l[i] * i;
			lineCount++;
		}

		return hash;
	}

}


public class Token
{
	public int StartIndex;
	public int EndIndex;
	public string Name;
	public int Level;
	
	private Type type;
	private Brush brush;
	private TokenType tokenType;
	
	private string[] keywords = new[] { "public", "private", "protected", 
							"void", "new", "static", "class", "override",
							"using", "var", "break", "continue", "return", 
							"try", "catch", "finally", "throw", 
							"get", "set",
							"switch", "case", "default" };
							
	private string[] loopsAndIfKeywords = new[] { "for", "foreach", "do", "while", "if", "if else", "else" };
							
	private string[] baseTypeName = new[] { "char", "string", "int", "float", "decimal", "double", "long", "bool" };
	
	public Brush Color {
		get {
			return brush;
		}
	}
	
	public Token(string name, int startIndex, int endIndex, int level, TokenType tokenType)
	{
		
		for(var i = 0; i < name.Length; i++)
		{
			if(char.IsWhiteSpace(name[i]))
				startIndex++;
			else
				break;
		}
		Name = name.Trim();
		
		StartIndex = startIndex;
		EndIndex = endIndex;
		Level = level;
		TokenType = tokenType;
		Type = typeof(object);
		
		brush = new SolidBrush(System.Drawing.Color.FromArgb(220, 220, 220));
		
		setBrush();
	}
	
	public TokenType TokenType {
		get { return tokenType; }
		set {
			tokenType = value;
				
			setBrush();	
		}
	}
	
	public Type Type{
		get { return type; }
		set { 
			type = value;
			setBrush();
		}
	}
	
	public override string ToString()
	{
		try
		{
			var n = Name.Replace("\n", "~").Replace("\t", "_");
			if(n.Length > 40 - Level * 2)
				n = n.Substring(0, 36 - Level * 2) + "...";
			return "".PadRight(Level * 2) 
					+ n.PadRight(40 - (Level * 2))
					+ Level.ToString().PadRight(5) 
					+ (Type.ToString() == "System.Object" ? "" : Type.ToString()).PadRight(30) 
					+ TokenType.ToString().PadRight(20) 
					+ StartIndex.ToString().PadRight(6) + "-" + EndIndex.ToString().PadLeft(6);
		}
		catch(Exception) {			
			return "";
		}
	}
	
	private void setBrush()
	{
	
		if(tokenType == TokenType.Method)
			brush = new SolidBrush(System.Drawing.Color.FromArgb(220, 220, 170));
		else if(tokenType == TokenType.Class)
			brush = new SolidBrush(System.Drawing.Color.FromArgb(78, 201, 176));
		else if(tokenType == TokenType.Operation)
		{
			brush = new SolidBrush(ColorTranslator.FromHtml("#9B9B9B"));
			if(Name == "!")
				brush = Brushes.OrangeRed;
		}

		if((type == typeof(string) && (Name.StartsWith("\"") || Name.StartsWith("@\""))) || tokenType == TokenType.HTMLAttributeValue)
			brush = new SolidBrush(System.Drawing.Color.FromArgb(214, 157, 133));
	
		if(Name == "null" || tokenType == TokenType.HTMLAttributeName)
			brush = new SolidBrush(System.Drawing.Color.FromArgb(255, 128, 0));
		else if(loopsAndIfKeywords.Any(x => x == Name) || tokenType == TokenType.HTMLTagName)
			brush = new SolidBrush(ColorTranslator.FromHtml("#0CB1F5"));
		else if(keywords.Any(x => x == Name))
			brush = new SolidBrush(System.Drawing.Color.FromArgb(86, 156, 214));
		else if(baseTypeName.Any(x => x == Name))
			brush = new SolidBrush(ColorTranslator.FromHtml("#3CB1F0"));
		else if(Name == "true" || Name == "false")
			brush = new SolidBrush(System.Drawing.Color.FromArgb(0, 128, 255));
		
		
		if(tokenType == TokenType.Comment)
			brush = new SolidBrush(System.Drawing.Color.FromArgb(87, 166, 74));
			
		if(tokenType == TokenType.HTMLTag)
			brush = Brushes.BlueViolet;
			
		if(tokenType == TokenType.InterpolatedVariable)
			brush = Brushes.GreenYellow;
			
		if(tokenType == TokenType.SQLKeyword)
			brush = new SolidBrush(System.Drawing.Color.FromArgb(129, 211, 26));
	}
}

public enum TokenType { None, Enum, Property, Method, Class, Operation, Comment, SplitChar, InterpolatedVariable,
				HTMLTag, HTMLTagName, HTMLAttributeName, HTMLAttributeValue,
				SQLKeyword };

public class OutlineNode
{
	public string Name;
	public int Index;
	public List<OutlineNode> Nodes;	
		
	public OutlineNode() {
		Nodes = new List<OutlineNode>();
	}
	
	public OutlineNode(string name, int index) : this()
	{
		Name = name;
		Index = index;
	}
	
	public void AddNode(Token t)
	{
		Nodes.Add(new OutlineNode(t.Name + (t.TokenType == TokenType.Method ? "()" : ""), t.StartIndex));
	}
}

public class TokenizeCompleteEventArgs : EventArgs
{
	public OutlineNode Outline;
	public long TimeElapsed;
}

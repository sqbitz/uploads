using System;
using System.Reflection;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

	
public class CRAPeDebug
{
	public CRAPeDebug()
	{
		try
		{
			Guid clsid = new Guid("9280188D-0E8E-4867-B30C-7FA83884E8DE");
			Guid riid = new Guid("D332DB9E-B9B3-4125-8207-A14884F53216");
			ICLRMetaHost metahost = NativeMethods.CLRCreateInstance(ref clsid, ref riid);
			var runtimes = metahost.EnumerateInstalledRuntimes();
			var runtime = GetRuntime(runtimes, "v4.0");
	
			Object res;
			clsid = new Guid("DF8395B5-A4BA-450B-A77C-A9A47762C520");
			riid = new Guid("3D6F5F61-7538-11D3-8D5B-00104B35E7EF");
			//runtime.GetInterface(ref clsid2, ref riid2, out res);
			//var codedebugger = (ICorDebug)res;
		}
		catch(Exception c)
		{
			Console.WriteLine(c);
		}
	}
	
	private ICLRRuntimeInfo GetRuntime(IEnumUnknown runtimes, string version)
	{
		var temparr = new Object[3];
		UInt32 fetchedNum;
		do
		{
			runtimes.Next(Convert.ToUInt32(temparr.Length), temparr, out fetchedNum);
			for(var i = 0; i < fetchedNum; i++)
			{
				var t = (ICLRRuntimeInfo)temparr[i];
				if(string.IsNullOrEmpty(version))
					return t;
					
				var sb = new StringBuilder(16);
				UInt32 len = Convert.ToUInt32(sb.Capacity);
				t.GetVersionString(sb, ref len);
				if(sb.ToString().StartsWith(version, StringComparison.Ordinal))
					return t;
			}
		} while(fetchedNum == temparr.Length);
		
		return null;
		
	}
}

internal class NativeMethods
{
	[DllImport("mscoree", CharSet = CharSet.Unicode, PreserveSig = false)]
	public static extern ICLRMetaHost CLRCreateInstance(ref Guid clsid, ref Guid riid);
}

[ComImport, Guid("D332DB9E-B9B3-4125-8207-A14884F53216")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
internal interface ICLRMetaHost
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	IntPtr GetRuntime([In, MarshalAs(UnmanagedType.LPWStr)] string pwzVersion, [In] ref Guid riid);
	
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetVersionFromFile([In, MarshalAs(UnmanagedType.LPWStr)] string pwzFilePath, 
					[Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pwzBuffer, 
					[In, Out] ref uint pcchBuffer);
	
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	IEnumUnknown EnumerateInstalledRuntimes();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	IEnumUnknown EnumerateLoadedRuntimes([In] IntPtr hndProcess);
	
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RequestRuntimeLoadedNotification([In, MarshalAs(UnmanagedType.Interface)] ICLRMetaHost pCallbackFunction);
	
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	IntPtr QueryLegacyV2RuntimeBinding([In] ref Guid riid);
	
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void ExitProcess([In] int iExitCode);	
}

[ComImport, Guid("00000100-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
internal interface IEnumUnknown
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	int Next([In] uint celt, [Out, MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.IUnknown)] object[] rgelt, [Out] out uint pceltFetched);
	
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Skip([In] uint celt);
	
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Reset();
	
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Clone([MarshalAs(UnmanagedType.Interface)] out IEnumUnknown ppenum);
}

[ComImport, Guid("BD39D1D2-BA2F-486A-89B0-B4B0CB466891"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
internal interface ICLRRuntimeInfo
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	string GetVersionString([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pwzBuffer, [In, Out] ref uint pcchBuffer);
	
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetInterface([In] ref Guid rclsid, [In] ref Guid riid, [Out, MarshalAs(UnmanagedType.Interface)] out object ppObj);
}

[ComImport, Guid("3D6F5F61-7538-11D3-8D5B-00104B35E7EF"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
internal interface ICorDebug
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Initialize();
	
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Terminate();
	
	/*
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetManagedHandler([In, MarshalAs(UnmanagedType.Interface)] ICorDebugManagedCallback pCallback
	
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	CreateProcess([In, MarshalAs(UnmanagedType.LPWStr)] string lpApplicationName, [In, MarshalAs(UnmanagedType.LPWStr)] string lpCommandLine,
				[In] SECURITY_ATTRIBUTES lpProcessAttributes, [In] SECURITY_ATTRIBUTES lpThreadAttributes, [In] int bInteritHandles,
				[In] uint dwCreationFlags, [In] IntPtr lpEnvironment, [In, MarshalAs(UnmanagedType.LPWStr)] string lpCurrentDirectory,
				[In] STARTUP_INFO pStartupInfo, [In] PROCESS_INFORMATION pProcessInformation, [In] CorDebugCreateProcessFlags debuggingFlags,
				[MarshalAs(UnmanagedType.Interface)] out ICORDebugProcess ppProcess); */
}
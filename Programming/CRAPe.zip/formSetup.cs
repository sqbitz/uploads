﻿using System;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Drawing;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Runtime.Serialization.Json;
	
public class MyForm : Form
{
	private string Version;

	private StatusBar statusBar;
	private TableLayoutPanel layout;
	private MyEditor editor;
	private MyTabControl editorTabs;
	private MyTabControl tabControl;

	private StatusBarPanel saveStatus;
	private StatusBarPanel buildStatus;
	
	private SplitContainer splitter;
	
	private FindForm findForm;
	private GotoForm gotoForm;
	private ReflectionTree reflectionTree;
	
	public TreeView tvCodeOutline;
	public TreeView tvDirectoryView;

	bool isIDE = false;
	string projectType = "exe";
	
	bool loadSQLite = false;
	bool loadWeb = false;
	
	bool presentationMode = false;
	ToolStripMenuItem tsmiPresentationMode;
	
	private List<string> filesToLoad;
	
	private List<string> referenceDLLs;
	private List<string> resourceFiles;
	
	public EventHandler Save;
	
	private DebugConsole tabDebug;
	private CompilationErrors tabCompilationErrors;
	
	private Process runningProcess;

	public MyForm()
	{			
		Width = 1200;
		Height = 1000;
		
		Images.Setup();
		
		WindowState = FormWindowState.Maximized;
		
		Icon = Images.AppIcon;
		
		Version = this.GetType().Assembly.GetName().Version.ToString();
		Version = Version.Substring(0, Version.LastIndexOf("."));
		
		var currDirectory = Application.StartupPath.Replace("C:\\Users\\Character\\Documents\\Users", "");

		Text = Name = "C.R.A.P.e.  v" + Version + "    " + currDirectory;
		
		BackColor = Color.FromArgb(35, 35, 45);

		//var testCase = new myTest();
		var testCase = new test1();
		this.Resize += resizeHandler;

		filesToLoad = new List<string>();
	
		findForm = new FindForm();
		findForm.Search += findFormSearchHandler;

		gotoForm = new GotoForm();
		gotoForm.Goto += gotoFormGotoHandler;
		
		var pLoading = new Panel() {
			Width = 500,
			Height = 300,
			BorderStyle = BorderStyle.Fixed3D		
		};
		pLoading.Controls.Add(new Label() {
			Text = "C.R.A.P.e.   v" + Version,
			ForeColor = Color.White,
			Font = new Font("Eras Bold ITC", 30),
			Top = 50,
			Height = 50,
			Width = 500,
			TextAlign = ContentAlignment.MiddleCenter
		});
		pLoading.Controls.Add(new Label() { 
			Text = "Loading, Please Wait...",
			ForeColor = Color.White,
			Font = new Font("Consolas", 15),
			Top = 120,
			Width = 500,
			TextAlign = ContentAlignment.MiddleCenter
		});
		var pLoadingProgress = new ProgressBar() {
			Width = 400,
			Height = 40,
			Top = 200,
			Left = 50,
			ForeColor = Color.Red,
			Style = ProgressBarStyle.Blocks
		};
		pLoading.Controls.Add(pLoadingProgress);
		
		this.Controls.Add(pLoading);
		this.Load += (object o, EventArgs e) => { 
			pLoading.Top = Height / 2 - pLoading.Height;
			pLoading.Left = Width / 2 - pLoading.Width / 2;
			pLoading.Show();
		};
				
		referenceDLLs = new List<string>();
		resourceFiles = new List<string>();
		
		loadSQLite = File.Exists("System.Data.SQLite.dll") || File.Exists("bin\\System.Data.SQLite.dll");

		int level = 2;
		using(var rdr = new System.IO.StreamReader("config.txt"))
			while(!rdr.EndOfStream)
			{
				var line = rdr.ReadLine();
				var split = line.Split('=');
				if(split[0] == "file")
					filesToLoad.Add(split[1]);

				//Clean up old crap from the building the IDE
				else if(split[0] == "isIDE" && split[1] == "true")
				{
					var currDir = new DirectoryInfo(".");
					foreach(var f in currDir.EnumerateFiles("CRAPe_6*.exe"))
					{		
						try
						{				
							File.Delete(f.FullName);
						}
						catch(Exception) { }
					}
					isIDE = true;
					loadSQLite = true;
				}
				else if(split[0] == "level")				
					level = int.Parse(split[1]);
				else if(split[0] == "projectType")
					projectType = split[1];
				else if(split[0] == "reference")
					referenceDLLs.Add(split[1]);
				else if(split[0] == "resource")
					resourceFiles.Add(split[1]);
			}
			
		loadWeb = referenceDLLs.Any(x => x.Contains("Owin"));
			
		layout = new TableLayoutPanel()
		{
			Dock = DockStyle.Fill,
			BackColor = Color.FromArgb(47, 47, 51)
		};
		layout.CellPaint += layoutCellPaintHandler;
		

		var menu = new MenuStrip();
		menu.Items.Add(new ToolStripMenuItem("File", null, new ToolStripItem[] {
			new ToolStripMenuItem("New", null, newFile, Keys.Control | Keys.N),
			new ToolStripMenuItem("Save", null, save, Keys.Control | Keys.S),
			new ToolStripMenuItem("Close", null, (o,e) => {
				if(editorTabs.SelectedTab.Text.StartsWith("SQL"))
					return;
				editorTabs.TabPages.RemoveAt(editorTabs.SelectedIndex); 
				editorTabs.SelectTab(editorTabs.TabPages.Count - 1);
			}, Keys.Control | Keys.F4),
			new ToolStripSeparator(),			
			new ToolStripMenuItem("Exit", null, exit, Keys.Alt | Keys.F4)
		}));

		tsmiPresentationMode = new ToolStripMenuItem("Presentation Mode", null, togglePresentationMode, Keys.F11);
		menu.Items.Add(new ToolStripMenuItem("Edit", null, new[] {
			new ToolStripMenuItem("Cut", null, (o,e) => { ((MyEditorTab)editorTabs.TabPages[editorTabs.SelectedIndex]).Editor.Cut(); }),
			new ToolStripMenuItem("Copy", null, (o,e) => { ((MyEditorTab)editorTabs.TabPages[editorTabs.SelectedIndex]).Editor.Copy(); }),
			new ToolStripMenuItem("Paste", null, (o,e) => { ((MyEditorTab)editorTabs.TabPages[editorTabs.SelectedIndex]).Editor.Paste(); }),
			new ToolStripMenuItem("Find", null, showFind, Keys.Control | Keys.F),
			new ToolStripMenuItem("Goto Line", null, showGoto, Keys.Control | Keys.G),
			tsmiPresentationMode			
		}));

		menu.Items.Add(new ToolStripMenuItem("Project", null, new[] {
			new ToolStripMenuItem("Build", null, (o,e) => { runCompile(); }, Keys.Control | Keys.B),
			new ToolStripMenuItem("Run", null, run, Keys.F5)
		}));
		
		if(level > 4)
		{
			menu.Items.Add(new ToolStripMenuItem("Diagnostics", null, new[] {
				new ToolStripMenuItem("Show Types", null, diag_showTypes),
				new ToolStripMenuItem("Show Variables", null, diag_showVariables, Keys.F5),
				new ToolStripMenuItem("Show RTF", null, diag_showRTF),
				new ToolStripMenuItem("Show Line Tokens", null, diag_showLineTokens),
				new ToolStripMenuItem("Show Curr Line Tokens", null, diag_showCurrLineTokens, Keys.F6),
				new ToolStripMenuItem("Show RTB Lines", null, diag_showRTBLines),
				new ToolStripMenuItem("Run Tokenize", null, diag_runTokenize, Keys.F7),
				new ToolStripMenuItem("Invalidate", null, diag_runInvalidate, Keys.F8),
			}));

		}

		layout.Controls.Add(menu, 0, 0);
		layout.SetColumnSpan(menu, 3);


		statusBar = new StatusBar(){ ShowPanels = true };
		statusBar.Panels.Add(new StatusBarPanel() { Text = "None", Width = 579 });
		statusBar.Panels.Add(new StatusBarPanel() { Text = "Status", Width = 200 });
		statusBar.Panels.Add(new StatusBarPanel() { Text = "LineCount", Width = 100 });
		
		saveStatus = new StatusBarPanel(){ Text = "", Width = 200 };
		statusBar.Panels.Add(saveStatus);

		buildStatus = new StatusBarPanel(){ Text = "", Width = 250 };
		statusBar.Panels.Add(buildStatus);
		
		statusBar.Panels.Add(new StatusBarPanel() { Text = "Total Lines", Width = 150 });
		layout.Controls.Add(statusBar, 0, 2);
		layout.SetColumnSpan(statusBar, 3);

		tvCodeOutline = new TreeView() {			
			ShowNodeToolTips = true,
			Dock = DockStyle.Fill,
			Indent = 10,
			ShowPlusMinus = false,
			LineColor = Color.Red,
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = Color.White,
			ShowRootLines = false,
			Margin = new Padding(0, 25, 0, 0),
			BorderStyle = BorderStyle.None
		};
		tvCodeOutline.NodeMouseClick += (object o, TreeNodeMouseClickEventArgs e) => { editor.tvCodeOutlineClicked(o, e); };
		
		tvDirectoryView = new TreeView() {
			ShowNodeToolTips = true,
			Dock = DockStyle.Fill,
			LineColor = Color.Red,
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = Color.White,
			ShowRootLines = false,
			Margin = new Padding(0, 10, 0, 0),
			BorderStyle = BorderStyle.None
		};
		tvDirectoryView.Nodes.Add(new TreeNode(currDirectory) { Name = ".", Tag = "directory" });
		buildDirectoryTree();
		
		
		var tlpLeft = new TableLayoutPanel() {
			Dock = DockStyle.Fill
		};
		tlpLeft.CellPaint += (o,e) => {
			if(e.CellBounds.Y > 10)
				e.Graphics.DrawLine(Pens.DarkRed, e.CellBounds.X + 4, e.CellBounds.Y, e.CellBounds.X + e.CellBounds.Width - 4, e.CellBounds.Y);
		};		
		
		tlpLeft.Controls.Add(tvCodeOutline, 0, 0);
		tlpLeft.Controls.Add(tvDirectoryView, 0, 1);
		
		tlpLeft.RowStyles.Add(new RowStyle {
			SizeType = SizeType.Percent, 
			Height = 60
		});
		tlpLeft.RowStyles.Add(new RowStyle {
			SizeType = SizeType.Percent, 
			Height = 40
		});
		
		layout.Controls.Add(tlpLeft, 1, 1);
		
		splitter = new SplitContainer() {
			Dock = DockStyle.Fill,
			Orientation = Orientation.Horizontal,
			SplitterDistance = 900,
			Margin = new Padding(3, 6, 3, 6),
			BackColor = Color.FromArgb(47, 47, 51),
		};
		splitter.Panel1.BackColor = Color.FromArgb(47, 47, 51);
		splitter.Panel2.BackColor = Color.FromArgb(47, 47, 51);
		layout.Controls.Add(splitter, 2, 1);

		editorTabs = new MyTabControl(true);
		editorTabs.SelectedIndexChanged += (object o, EventArgs e) => {
			saveStatus.Text = "";
			if(editorTabs.SelectedIndex == 0 || editorTabs.SelectedTab.GetType() != typeof(MyEditorTab))
				return;
				
			var tab = (MyEditorTab)editorTabs.SelectedTab;
			editor = tab.Editor;
			try
			{
				var errors = tabCompilationErrors.GetFileErrors(tab.Text);
				editor.HighlightErrors(errors);
			}
			catch(Exception){}
			
			editor.tokenizer.Tokenize(editor.Text, editor.Lines, tab.Text, -1, "", false);
			tab.RefreshOutlineTree();
		};
		splitter.Panel1.Controls.Add(editorTabs);
		
		tabControl = new MyTabControl();
		tabDebug = new DebugConsole();
		tabControl.TabPages.Add(tabDebug);		
		
		tabCompilationErrors = new CompilationErrors();
		tabControl.TabPages.Add(tabCompilationErrors);
		tabCompilationErrors.ErrorSelected += compilationErrorSelectedHandler;
		tabControl.SelectedIndex = 1;
		splitter.Panel2.Controls.Add(tabControl);

		layout.RowStyles.Add(new RowStyle {
			SizeType = SizeType.Absolute,
			Height = 25
		});
		layout.RowStyles.Add(new RowStyle {
			SizeType = SizeType.Percent, 
			Height = 100
		});
		layout.RowStyles.Add(new RowStyle {
			SizeType = SizeType.Absolute,
			Height = 25
		});
		
		layout.ColumnStyles.Add(new ColumnStyle {
			SizeType = SizeType.Absolute,
			Width = 370
		});
		
		layout.ColumnStyles.Add(new ColumnStyle {
			SizeType = SizeType.Absolute,
			Width = 210
		});

		this.Controls.Add(layout);
		
		Console.WriteLine("Welcome to C.R.A.P.e.  v" + Version);
		
		double totalProgressItems = 0;
			
		reflectionTree = new ReflectionTree(statusBar.Panels[0]){ Margin = new Padding(3, 6, 3, 6) };
		reflectionTree.Loaded += (object o, EventArgs e) => { 
			pLoading.Hide(); 
			this.Invalidate(true); 
			this.editor.Invalidate(true);
			//tabDebug.Clear();
			Console.WriteLine(".");
			foreach(var t in editorTabs.TabPages)
			{
				if(t is MyEditorTab == false)
					continue;
					
				var met = (MyEditorTab)t;
				met.Editor.tokenizer.Tokenize(met.Editor.Text, met.Editor.Lines, met.Filename, 0, "", false);
			}
		};
		reflectionTree.LoadStart += (object o, EventArgs e) => { 
			totalProgressItems = (int)o;
			Console.Write(".");
		};
		reflectionTree.LoadProgress += (object o, EventArgs e) => { 
			var percent = ((int)o / totalProgressItems);
			pLoadingProgress.Value = (int)(percent * 100);
			if(pLoadingProgress.Value % 5 == 0)
				Console.Write(".");
		};

		loadFiles(filesToLoad);
		
		if(loadSQLite)
		{
			var tcLeft = new MyTabControl() {
				Margin = new Padding(0, 6, 0, 0)
			};
			tcLeft.TabPages.Add(new ReflectionTreeTab(reflectionTree));
	
			var sqlConsoleTab = new SQLConsole() {};
			tcLeft.TabPages.Add(sqlConsoleTab);
			tcLeft.SelectedIndex = 1;
			layout.Controls.Add(tcLeft, 0, 1);	
				
			var sqlEditorTab = new SQLEditor(statusBar.Panels[1], statusBar.Panels[2]);
			editorTabs.TabPages.Add(sqlEditorTab);
			
			var sqlQueryResults = new SQLQueryResults(saveStatus);
			tabControl.TabPages.Add(sqlQueryResults);
			
			sqlEditorTab.ExecuteSQL += (o, s) => {
				var cmd = (string)o;
				var numRows = sqlQueryResults.ExecuteSQL(cmd);
				if(numRows > 0)
					tabControl.SelectTab(sqlQueryResults);
					
				if(cmd.Trim().StartsWith("CREATE"))
					sqlConsoleTab.Refresh();
			};
			
			sqlConsoleTab.AddCommand += (o, s) => {
				sqlEditorTab.AddCommand((string)o);
				editorTabs.SelectTab(sqlEditorTab);
			};
		}
		else
			layout.Controls.Add(reflectionTree, 0, 1);
			
		if(loadWeb)
		{
			var webConsole = new WebConsole();
			tabControl.TabPages.Add(webConsole);
		}
		
		try
		{
		//var tpPP101 = new TabPage("Programming 101");
		//var webBrowser101 = new WebBrowser(){
		//	Dock = DockStyle.Fill,
		//	//Url = new Uri("file:///C:/Users/Character/Documents/Users/382847/Programming 101.pptx")
		//};
		//tpPP101.Controls.Add(webBrowser101);
		//tabControl.TabPages.Add(tpPP101);
		}
		catch(Exception c)
		{
			Console.WriteLine("Error: " + c);
		}
		
		var firstTab = ((MyEditorTab)editorTabs.TabPages[1]);
		firstTab.Editor.tokenizer.Tokenize(firstTab.Editor.Text, firstTab.Editor.Lines, filesToLoad[0], -1, "", false);
		
		var timerCalcTotalLines = new Timer() {
			Enabled = true,
			Interval = 5000
		};
		
		//This is broken for the time being since we are not loading all files.
		timerCalcTotalLines.Tick += (object o, EventArgs e) => {
			int lineCount = 0;
			foreach(var met in editorTabs.TabPages)
				if(met is MyEditorTab)
					lineCount += ((MyEditorTab)met).Editor.Lines.Count(x => string.IsNullOrWhiteSpace(x) == false);
			statusBar.Panels[5].Text = "Total Lines: " + lineCount.ToString("n0");
		};
	}
	
	private void loadFiles(List<string> filesToLoad)
	{
		var pages = new ConcurrentBag<MyEditorTab>();
		foreach(var f in filesToLoad)
		{
			var editorTab = new MyEditorTab(f, statusBar.Panels[1], statusBar.Panels[2], tvCodeOutline, reflectionTree);
			editorTabs.TabPages.Add(editorTab);
		}	
			
		var firstTab = ((MyEditorTab)editorTabs.TabPages[1]);
		//firstTab.Editor.tokenizer.Tokenize(firstTab.Editor.Text, filesToLoad[0]);
		firstTab.Editor.tokenizer.CompileProject(referenceDLLs, tabCompilationErrors, projectType);
		editor = firstTab.Editor;
		editorTabs.SelectedIndex = 1;
	}
	
	private void newFile(object sender, EventArgs e)
	{
		var fd = new SaveFileDialog(){
			DefaultExt = "cs",
			Title = "Create File",
			InitialDirectory = Application.StartupPath
		};
		var result = fd.ShowDialog();
		if(result == DialogResult.OK)
		{
			File.Create(fd.FileName);
			
			buildDirectoryTree();
		}
		
	}

	private void save(object sender, EventArgs e)
	{
		var filename = ((MyEditorTab)editorTabs.TabPages[editorTabs.SelectedIndex]).Filename;
		editor.SaveFile(filename);

		var f = new FileInfo(filename);
		if(Directory.Exists(Path.Combine(".", "backups")))
			editor.SaveFile(Path.Combine(".", "backups", f.Name.Replace(f.Extension, "") + DateTime.Now.ToString(".MMddyyyy.hhmmss") + f.Extension));
			
		saveStatus.Text = "Last Save: " + DateTime.Now;
		
		editor.tokenizer.CompileProject(referenceDLLs, tabCompilationErrors, projectType);
	}

	private bool runCompile()
	{
		Console.WriteLine("Compiling...");
		buildStatus.Text = "Building...";	
		
		var compileErrorRegex = new Regex(@"(?<filename>(\w+\\)*\w+\.\w\w)\((?<sLine>\d+),(?<sColumn>\d+),(?<eLine>\d+),(?<eColumn>\d+)\): error \w+: (?<error>.*)");
		
		//168 unused variable
		//219 variable unassigned
		//618 obsolete
		var sb = new StringBuilder("/debug+ /errorendlocation /nologo /nowarn:168 /nowarn:219 /nowarn:618 /lib:bin /r:System.Web.dll /r:System.Web.Extensions.dll ");
		foreach(var f in referenceDLLs)
			sb.AppendFormat("/r:{0} ", f);
		foreach(var f in resourceFiles)
			sb.AppendFormat("/res:{0} ", f);
			
		sb.AppendFormat("/t:{0} ", projectType);
		
		if(isIDE)
			sb.Append("/win32icon:appIcon.ico ");
			
		var currDir = Directory.GetCurrentDirectory();
		foreach(var f in Directory.EnumerateFiles(currDir, "*.cs", SearchOption.AllDirectories).Where(x => x.Contains("\\backups") == false))
			sb.Append("\"").Append(f).Append("\" " );
			
		var psi = new ProcessStartInfo(@"c:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe", sb.ToString())
		{
			WindowStyle = ProcessWindowStyle.Hidden,
			RedirectStandardError = true,
			RedirectStandardOutput = true,
			UseShellExecute = false,
			CreateNoWindow = true
		};
		
		using(var p = Process.Start(psi))
		{
			tabCompilationErrors.Clear();
			while(!p.StandardOutput.EndOfStream)
			{
				var line = p.StandardOutput.ReadLine();
				var m = compileErrorRegex.Match(line);
				if(m.Success)
				{
					tabCompilationErrors.Add(m.Groups["filename"].Value, 
									m.Groups["sLine"].Value, m.Groups["sColumn"].Value, 
									m.Groups["eLine"].Value, m.Groups["eColumn"].Value,
									m.Groups["error"].Value);
				}
				else if(!line.Contains("warning CS") && !line.Contains("c:\\Windows\\Microsoft"))
					Console.WriteLine(line);
			}
			p.WaitForExit();

			if(p.ExitCode == 0)
				buildStatus.Text = "Build Success " + DateTime.Now;
			else
				buildStatus.Text = "Build Failed";
				
			Console.WriteLine(buildStatus.Text);
				
			if(tabCompilationErrors.ErrorCount > 0)
			{
				var tabControl = tabCompilationErrors.Parent as TabControl;
				tabControl.SelectTab(tabCompilationErrors);
				editor.HighlightErrors(tabCompilationErrors.GetFileErrors(editorTabs.TabPages[editorTabs.SelectedIndex].Text));
			}

			return p.ExitCode == 0;					
		}		
	}

	private void run(object sender, EventArgs e)
	{	
		if(runningProcess != null)
		{
			try
			{
				Console.WriteLine("Currently running... Stopping running process.");
				runningProcess.Kill();
			}
			catch(Exception c)
			{
				runningProcess = null;
			}
		}
			
		Console.WriteLine("Compile and Reload");
		bool success = runCompile();		
		if(!success)
			return;
	
		if(isIDE)
		{
			var filename = "CRAPe_" + DateTime.Now.Ticks + ".exe";
			File.Copy("CRAPe.exe", filename);
			this.Close();
			Process.Start(filename);
			return;
		}
		
		var executable = new DirectoryInfo(".").EnumerateFiles("*.exe").Where(x => !x.ToString().Contains("CRAPe")).First();
		var psi = new ProcessStartInfo(executable.FullName)
		{
			RedirectStandardError = projectType == "winexe",
			RedirectStandardOutput = projectType == "winexe",
			UseShellExecute = false
		};
	
		runningProcess = Process.Start(psi);
		if(projectType != "winexe")
			return;
			
		Task.Run(() => {
			while(!runningProcess.StandardOutput.EndOfStream)
			{
				var line = runningProcess.StandardOutput.ReadLine();
				Console.WriteLine(line);
			}
			runningProcess.Dispose();
			runningProcess = null;
			Console.WriteLine("Exiting...");
		});
	}
	
	private void resizeHandler(object sender, EventArgs e)
	{
		layout.ColumnStyles[0].Width = 370;
		statusBar.Panels[0].Width = 579;
		if(this.Width < 1000)
		{
			layout.ColumnStyles[0].Width = 0;
			statusBar.Panels[0].Width = 209;
			statusBar.Panels[0].Text = "";
		}
	}
	
	private void buildDirectoryTree()
	{
		var root = tvDirectoryView.Nodes[0];
		root.ContextMenu = new ContextMenu(new MenuItem[] {
			new MenuItem("Refresh", (s,e) => { buildDirectoryTree(); }),
		});
		root.Nodes.Clear();
		var currDir = new DirectoryInfo(".");
		recurseDirectoryTree(currDir.FullName, "", root);
		
		tvDirectoryView.NodeMouseDoubleClick += (o,e) => { 
			if(e.Node.Tag.ToString() != "directory")
				openFile(e.Node.Name); 
		};
		tvDirectoryView.Nodes[0].Expand();
	}
	
	private void recurseDirectoryTree(string fullPath, string relativePath, TreeNode root)
	{
		var currDir = new DirectoryInfo(fullPath);
		foreach(var d in currDir.EnumerateDirectories())
		{
			var dirNode = new TreeNode(d.Name) { Name = d.Name, Tag = "directory" };
			root.Nodes.Add(dirNode);
			recurseDirectoryTree(d.FullName, relativePath + "\\" + d.Name, dirNode);
		}
			
		foreach(var f in currDir.EnumerateFiles("*.*")
			.Where(x => new[] { "cs", "html", "js", "css", "txt", "config" }
					.Any(y => x.Extension.EndsWith(y))
			)
		)
		{
			var path = relativePath + "\\" + f.Name;
			var n = new TreeNode(f.Name){ 
				Name = path.TrimStart('\\'),
				Tag = f.Extension
			};
			
				
			n.ContextMenu = new ContextMenu(new MenuItem[] {
				new MenuItem("Open", (s,e) => { openFile(((MenuItem)s).Tag.ToString()); }) { Tag = path.TrimStart('\\') },
				new MenuItem("Delete", (s,e) => { 
					var filename = ((MenuItem)s).Tag.ToString();
					var mbr = MessageBox.Show("Deleting file: " + filename + "\nAre you sure?", "Delete File", 
										MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
					if(mbr != DialogResult.OK)
						return;

					File.Delete(filename);
					buildDirectoryTree();
					
				}) { Tag = f.Name },
			});
			root.Nodes.Add(n);
		}
		
	}
	
	private void openFile(string filename)
	{
		if(editorTabs.SelectTab(filename) == false)
		{
			var editorTab = new MyEditorTab(filename, statusBar.Panels[1], statusBar.Panels[2], tvCodeOutline, reflectionTree);
			editorTabs.TabPages.Add(editorTab);
			editorTabs.SelectTab(editorTab);
			
			editorTab.Editor.tokenizer.Tokenize(editorTab.Editor.Text, editorTab.Editor.Lines, filename, -1, "", false);
			editorTab.Editor.tokenizer.CompileProject(referenceDLLs, tabCompilationErrors, projectType);
		}	
	}
	
	private void compilationErrorSelectedHandler(object sender, EventArgs e)
	{
		var errorItem = (CompilationErrors.Item)sender;
		
		if(editorTabs.SelectTab(errorItem.Filename) == false)
		{
			var editorTab = new MyEditorTab(errorItem.Filename, statusBar.Panels[1], statusBar.Panels[2], tvCodeOutline, reflectionTree);
			editorTabs.TabPages.Add(editorTab);
			editorTabs.SelectTab(editorTab);
		}
		
		editor = ((MyEditorTab)editorTabs.SelectedTab).Editor;
		editor.SelectionStart = editor.GetFirstCharIndexFromLine(errorItem.StartLine - 1) + errorItem.StartColumn - 1;
		editor.ScrollToCaret();
		editor.Focus();
	}
	
	private void layoutCellPaintHandler(object o, TableLayoutCellPaintEventArgs e)
	{
		if(e.CellBounds.X < 10)
			return;
			
		e.Graphics.DrawLine(Pens.DarkRed, e.CellBounds.X, e.CellBounds.Y + 7, e.CellBounds.X, e.CellBounds.Y + e.CellBounds.Height - 7);
	}

	private void showFind(object sender, EventArgs e)
	{		
		findForm.Show();
	}

	private void findFormSearchHandler(object sender, EventArgs e)
	{
		var start = 0;
		if(editor.SelectionLength > 1)
			start = editor.SelectionStart + editor.SelectionLength + 1;

		editor.Find(findForm.SearchValue, start, new RichTextBoxFinds());
		editor.Focus();
	}

	private void showGoto(object sender, EventArgs e)
	{		
		gotoForm.Show();
	}

	private void gotoFormGotoHandler(object sender, EventArgs e)
	{	
		editor.SelectionStart = editor.GetFirstCharIndexFromLine(gotoForm.GotoValue);
		editor.ScrollToCaret();
		gotoForm.Hide();
	}
	
	private void exit(object sender, EventArgs e)
	{
		this.Close();
	}
	
	private void togglePresentationMode(object sender, EventArgs e)
	{
		presentationMode = !presentationMode;
		tsmiPresentationMode.Checked = presentationMode;
		
		layout.ColumnStyles[0].Width = 370;
		layout.ColumnStyles[1].Width = 210;
		statusBar.Panels[0].Width = 579;
		
		//splitter.Panel2Collapsed = presentationMode;
		var zoom = 0;
		if(presentationMode)
		{
			layout.ColumnStyles[0].Width = 0;
			layout.ColumnStyles[1].Width = 0;
			statusBar.Panels[0].Width = statusBar.Panels[0].MinWidth;
			statusBar.Panels[0].Text = "";
			zoom = 10;
		}
		foreach(var t in editorTabs.TabPages)
		{
			if(t is MyEditorTab == false)
				continue;
					
			var met = (MyEditorTab)t;
			met.Editor.SetZoom(zoom);
			met.Padding = new Padding(zoom, zoom, 0, 0);
		}
		
		var fontNormal = new Font(this.Font.FontFamily, 10);
		var fontZoom = new Font(this.Font.FontFamily, 20);
		foreach(TabPage t in tabControl.TabPages)
		{
			t.Font = presentationMode ? fontZoom : fontNormal;
		}
	}

	/* Diagnostic Stuff */
	private void diag_showTypes(object sender, EventArgs e)
	{
		editor.Diag_ShowTypes();
	}

	private void diag_showVariables(object sender, EventArgs e)
	{
		editor.Diag_ShowVariables();
	}

	private void diag_showRTF(object sender, EventArgs e)
	{
		Console.Clear();
		Console.WriteLine(editor.Rtf);
	}
	private void diag_showLineTokens(object sender, EventArgs e)
	{
		editor.Diag_ShowLineTokens();
	}
	private void diag_showCurrLineTokens(object sender, EventArgs e)
	{
		editor.Diag_ShowCurrLineTokens();
	}
	
	private void diag_showRTBLines(object sender, EventArgs e)
	{
		for(int i = 0; i < editor.Lines.Length; i++)
			Console.WriteLine(i.ToString().PadRight(5) + editor.Lines[i].Length.ToString().PadRight(5) + "|" + editor.Lines[i].Replace("\n", "\\n") + "|");
	}
	
	private void diag_runTokenize(object sender, EventArgs e)
	{
		editor.Diag_RunTokenize();
		this.Invalidate();
		editor.Invalidate();
	}
	
	private void diag_runInvalidate(object sender, EventArgs e)
	{
		editor.Invalidate();
	}
	

}		

public class GotoForm : Form
{
	private TextBox txtLine;
	public EventHandler Goto;

	public int GotoValue {
		get {
			int i = 0;
			if(!int.TryParse(txtLine.Text, out i))
				i = 1;
	
			// to handle the 0 index scheme RTB uses
			return i - 1;
		}
	}


	public GotoForm()
	{
		Width = 300;
		Height = 120;

		TopMost = true;

		Text = "Goto Line";
		
		this.Controls.Add(new Label()
		{		
			Top = 23,
			Left = 20,
			Text = "Goto: ",
			Width = 33,
		});

		txtLine = new TextBox()
		{
			Top = 20,
			Left = 60,
			Width = 100
		};
		this.Controls.Add(txtLine);

		var btnGoto = new Button(){
			Top = 20,
			Left = 190,
			Text = "Goto Line"
		};
		btnGoto.Click += btnGotoClick;
		this.Controls.Add(btnGoto);
		AcceptButton = btnGoto;

		this.Closing += closingHandler;
		this.VisibleChanged += visibleChangedHandler;
	}

	private void btnGotoClick(object sender, EventArgs e)
	{
		Goto(sender, e);
		txtLine.Text = "";
	}

	private void keyDownHandler(object o, KeyEventArgs args)
	{		
		if(args.KeyData == Keys.Escape)
			this.Close();
	}

	private void closingHandler(object sender, System.ComponentModel.CancelEventArgs args)
	{
		args.Cancel = true;
		txtLine.Text = "";
		this.Hide();
	}
	
	private void visibleChangedHandler(object sender, EventArgs e)
	{
		txtLine.Focus();
	}

}

public class FindForm : Form
{
	private TextBox txtSearch;
	public EventHandler Search;

	public string SearchValue {
		get {
			return txtSearch.Text;
		}
	}

	public FindForm()
	{	
		Width = 400;
		Height = 120;

		TopMost = true;

		Text = "Find";
		
		this.Controls.Add(new Label()
		{		
			Top = 23,
			Left = 20,
			Text = "Find: ",
			Width = 30,
		});

		txtSearch = new TextBox()
		{
			Top = 20,
			Left = 60,
			Width = 150
		};
		this.Controls.Add(txtSearch);

		var btnSearch = new Button(){
			Top = 20,
			Left = 240,
			Text = "Find Next"
		};
		btnSearch.Click += btnSearchClick;
		this.Controls.Add(btnSearch);
		AcceptButton = btnSearch;

		this.KeyDown += keyDownHandler;
		this.Closing += closingHandler;
	}

	private void btnSearchClick(object sender, EventArgs e)
	{
		Search(sender, e);
	}

	private void keyDownHandler(object o, KeyEventArgs args)
	{		
		if(args.KeyData == Keys.Escape)
			this.Close();
	}

	private void closingHandler(object sender, System.ComponentModel.CancelEventArgs args)
	{
		args.Cancel = true;
		txtSearch.Text = "";
		txtSearch.Focus();
		this.Hide();
	}
}

public static class Images
{	
	public static Image Property;
	public static Image Enum;
	public static Image Method;
	public static Image Class;
	public static Image Event;
	public static Image Variable;
	
	public static Image Folder;
	
	public static Icon AppIcon;
	
	public static void Setup()
	{
		string base64_enum = @"/9j/4AAQSkZJRgABAQEAYABgAAD/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAEAAAAAAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAPABQDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9vP2g/ibqvw40fQYdFXT11HxFqv8AZyXN9C88Fkq2txdSSNErxl/ktmQZliVS4dnCo2fmX4if8FHfGnw5+E/xa8Wpb2esf8KZ0e/1nVdMvvh1r/hqPWPsUd08kFnfXjmKUObG6UTwR3Cxr5UjIVMgi+lv2lfg9rXxh8F6fH4Z1/S/DPijQdTj1TSr/U9Jk1axikEckMgmto7i2lcGCeYKY7iJ45DHIGOza3ybP/wR98Y634b8f+H7zxl+z/oOifGC0n03x5deDvgpLoWua/a3PmC5cXZ1qaMXRFxdPHNPbzpHLPv8pxHEiAH3tRRRQB//2Q==";

		string base64_property = @"/9j/4AAQSkZJRgABAQEAYABgAAD/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAEAAAAAAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAPABQDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD6o/4K4ftrfEv4qfGeD4E/DvR7zSfEGn/EKLSNFu9A+Ier6XrniVoNA03Ub4Pp9jDaGe0ii8QWqiMazbYnjiup2jsbW8kj+bfAX7at9a+KNLt/Gnij9paP4qeIvF8egaTd6N441v7HLrd094bOCfTrq4h0q1ma8s5bVba6s4bKSRHSS1tBbapp2l+zftUf8FZvAv7C/wC39+0B4P1r4yf8K41a88V3WrXWn7Lhftf2n4f+G7bSrjKeG9XVtl9bynImg8nZvkt79CLc8f8A8E9f+ClPg39rP9u34PeFbf4tWHxE8Zar8SpvFUkNsplkkS38D+JrC4u5pl8I+H0MmxtMhBka6dkhjVRCkJ3uLs7gfc3/AAQP8UeOfF//AASl+Gl38TNQ8Wap48iu9dstam8T3FxNq6XFvruoW5huWuCZhJEIhFtflBGFwNuAV9kfKtFa4zGKtXnWso8zbstld3svQzVHQ//Z";

		string base64_method = @"/9j/4AAQSkZJRgABAQEAYABgAAD/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAEAAAAAAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAPABQDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD95Nb8cWWgarBZ3EOsSTXEsEKNbaTdXMQaYyBC0kcbIqgxNvZiFjBQuVEiFvyt1X/gv/8AF7wr4gk+ImvfBrUdD+CK67JpZ0ifRrSTxDbxpdCyMd1fR62y2eoLKJGktbnTYkhuDb2Elwr3Md3X6TfFj9mXw38W7qW4urezsbq6RluriLRdMu5bwkwYaQ3drNuKrbxqO2AMglIynlX7R/8AwS68K/tFa/dat/wmnjjwdqniDT49O8VzaJb6LND42WOEQJLqNrfafc2rzCDfA0kUMTSwSeRL5kMcUUfzfE1HPKlCm8hqQjUjOLkqidpw+1HmSk4NrVSUZbW0vzLzcyp42cYrBTjF31ur6eW/zVtdk47nt3wO+OPhP9pP4T6H458Da5aeIvCviKD7RY31uGUOAxR0dHAeKWORXjkikVZIpI3R1V1ZQUfA74HeE/2bPhPofgbwNodp4d8K+HYPs9jY2+5ggLF3d3cl5ZZJGeSSWRmklkkd3ZnZmJX0Ub297c9CPNyrm3P/2Q==";

		string base64_class = @"Qk1iBQAAAAAAADYEAAAoAAAAFAAAAA8AAAABAAgAAAAAACwBAADEDgAAxA4AAAAAAAAAAAAAAAAAAAAAgAAAgAAAAICAAIAAAACAAIAAgIAAAMDAwADA3MAA8MqmAAAgQAAAIGAAACCAAAAgoAAAIMAAACDgAABAAAAAQCAAAEBAAABAYAAAQIAAAECgAABAwAAAQOAAAGAAAABgIAAAYEAAAGBgAABggAAAYKAAAGDAAABg4AAAgAAAAIAgAACAQAAAgGAAAICAAACAoAAAgMAAAIDgAACgAAAAoCAAAKBAAACgYAAAoIAAAKCgAACgwAAAoOAAAMAAAADAIAAAwEAAAMBgAADAgAAAwKAAAMDAAADA4AAA4AAAAOAgAADgQAAA4GAAAOCAAADgoAAA4MAAAODgAEAAAABAACAAQABAAEAAYABAAIAAQACgAEAAwABAAOAAQCAAAEAgIABAIEAAQCBgAEAggABAIKAAQCDAAEAg4ABAQAAAQEAgAEBAQABAQGAAQECAAEBAoABAQMAAQEDgAEBgAABAYCAAQGBAAEBgYABAYIAAQGCgAEBgwABAYOAAQIAAAECAIABAgEAAQIBgAECAgABAgKAAQIDAAECA4ABAoAAAQKAgAECgQABAoGAAQKCAAECgoABAoMAAQKDgAEDAAABAwCAAQMBAAEDAYABAwIAAQMCgAEDAwABAwOAAQOAAAEDgIABA4EAAQOBgAEDggABA4KAAQODAAEDg4ACAAAAAgAAgAIAAQACAAGAAgACAAIAAoACAAMAAgADgAIAgAACAICAAgCBAAIAgYACAIIAAgCCgAIAgwACAIOAAgEAAAIBAIACAQEAAgEBgAIBAgACAQKAAgEDAAIBA4ACAYAAAgGAgAIBgQACAYGAAgGCAAIBgoACAYMAAgGDgAICAAACAgCAAgIBAAICAYACAgIAAgICgAICAwACAgOAAgKAAAICgIACAoEAAgKBgAICggACAoKAAgKDAAICg4ACAwAAAgMAgAIDAQACAwGAAgMCAAIDAoACAwMAAgMDgAIDgAACA4CAAgOBAAIDgYACA4IAAgOCgAIDgwACA4OAAwAAAAMAAIADAAEAAwABgAMAAgADAAKAAwADAAMAA4ADAIAAAwCAgAMAgQADAIGAAwCCAAMAgoADAIMAAwCDgAMBAAADAQCAAwEBAAMBAYADAQIAAwECgAMBAwADAQOAAwGAAAMBgIADAYEAAwGBgAMBggADAYKAAwGDAAMBg4ADAgAAAwIAgAMCAQADAgGAAwICAAMCAoADAgMAAwIDgAMCgAADAoCAAwKBAAMCgYADAoIAAwKCgAMCgwADAoOAAwMAAAMDAIADAwEAAwMBgAMDAgADAwKAA8Pv/AKSgoACAgIAAAAD/AAD/AAAA//8A/wAAAP8A/wD//wAA////AP////////////////////////////////////////////8AAAD/////////AP//////////AP4A/gD//////wD5AP//AAAA/wD+AP4A//////8A+QAA/wACAAIA/wAAAP///////wAA+QAAAgACAP///wD/////////APkA//8AAAD/AP8A////////////AP8A////////AP////////////////8A//8A/wD/AP8A//////////////8AAPsA////APkA//////////////8AAPsA/wD5AAD//////////////wD7AAD/AAD5AP///////////////wD7AP8A+QD//////////////////wD///8A/////////////////////////////////w==";

		string base64_folder = @"Qk0GAwAAAAAAADYAAAAoAAAADwAAAA8AAAABABgAAAAAANACAADEDgAAxA4AAAAAAAAAAAAA////////////////////////////////////////////////////////////AAAA////Kb3nScvwSMrwRsrwRsnvRcjvRMjuQ8fuQ8ftQsbtJbbiQsbtLrnj////AAAA////Scfrmev/l+r/lur/lOr/kur/kOn/j+n/jej/jOj/RsHmjOj/RMHm////AAAA////SMjrkeb/kOf/jub/jeX/i+b/iuX/iOT/h+T/heP/RcHnheP/RcHn////AAAA////SMjtlOj/keb/keb/j+f/juX/jOX/i+b/ieT/iOX/RMLnjOf/QsLn////AAAA////Ssrtluf/lOj/kuf/keb/j+f/jub/jOX/i+b/ieX/RMLoedz5QMLo////AAAA////Scvul+j/luf/lOj/kuf/keb/j+f/jub/jOX/i+b/bNb1QsHnq+T1////AAAA////Ssvumej/mOj/luf/lej/k+f/keb/kOf/jub/jeX/kOj/RcPp////////AAAA////S8zvm+n/mej/mOj/luf/lej/k+f/keb/kOf/jub/jeX/R8Xq////////AAAA////SszunOr/m+r/mej/mOn/luf/luj/k+j/keb/kOf/juf/SMXp////////AAAA////TM7wn+r/nen/nOr/mun/men/l+j/luf/lOj/kuf/keb/SMfr////////AAAA////TM/woOv/n+r/nen/nOr/mun/men/l+j/luf/lOj/kuf/Scjr////////AAAA////S8/wse//r+//ru//rO7/qu//qe7/p+7/pe3/pOz/ou3/Q8br////////AAAA////J8fvOczxOcvxOcvwOcnwN8jvN8nvNsfvNcbuNcbuNcXtRMfr////////AAAA///////////+///+///+///+///+///+///+///+///+///+////////////AAAA";
		
		string base64_event = @"/9j/4AAQSkZJRgABAQEAYABgAAD/4QAiRXhpZgAATU0AKgAAAAgAAQESAAMAAAABAAEAAAAAAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAPABQDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD7o/4KqeEvC+qftQabeeMv2g/2kPhNb3Wi6Nomh6H8OPH9v4cttZvrm71YlmjuMRzXLCKKMBG81wqgKwQlfnP9nf8AZ6sPjr8V7zwveftFf8FAvDCx30djYahdftAaJNFrBkmMQlgjU+aY/utsZFnIkQLCx3hP0r+O/wCznffFL4pXmrP4a8N+JNLutLsLOMXfie+0O6tJraa+ZiHtbeRmjdbtcqXAzECVJCkPsPhx430c6f5fhvT2/s67N5D53xd8QTb3Pl5Em+0Pmx/ul/dyboxl8L877vqMLxNWw+DjQpXcrWu+Wy7WVrvfW7eq00Pj8RlmeVs2deWKhTwsXHlhGF5zTS5lUlJtRs01H2aXuyfNeSTXWfsfQ3Vv+yT8LY77VdW16+j8I6StxqWqXJur7UZBZxbp55W5kmc5Z3PLMxPeitv4JeC7r4b/AAZ8I+HL6S2mvvD+i2Wm3DwEtE0kMCRsULAEqSpIJAOD0HSivmZycpOUt2fYH//Z";
		
		string base64_variable = @"Qk1iBQAAAAAAADYEAAAoAAAAFAAAAA8AAAABAAgAAAAAACwBAADEDgAAxA4AAAAAAAAAAAAAAAAAAAAAgAAAgAAAAICAAIAAAACAAIAAgIAAAMDAwADA3MAA8MqmAAAgQAAAIGAAACCAAAAgoAAAIMAAACDgAABAAAAAQCAAAEBAAABAYAAAQIAAAECgAABAwAAAQOAAAGAAAABgIAAAYEAAAGBgAABggAAAYKAAAGDAAABg4AAAgAAAAIAgAACAQAAAgGAAAICAAACAoAAAgMAAAIDgAACgAAAAoCAAAKBAAACgYAAAoIAAAKCgAACgwAAAoOAAAMAAAADAIAAAwEAAAMBgAADAgAAAwKAAAMDAAADA4AAA4AAAAOAgAADgQAAA4GAAAOCAAADgoAAA4MAAAODgAEAAAABAACAAQABAAEAAYABAAIAAQACgAEAAwABAAOAAQCAAAEAgIABAIEAAQCBgAEAggABAIKAAQCDAAEAg4ABAQAAAQEAgAEBAQABAQGAAQECAAEBAoABAQMAAQEDgAEBgAABAYCAAQGBAAEBgYABAYIAAQGCgAEBgwABAYOAAQIAAAECAIABAgEAAQIBgAECAgABAgKAAQIDAAECA4ABAoAAAQKAgAECgQABAoGAAQKCAAECgoABAoMAAQKDgAEDAAABAwCAAQMBAAEDAYABAwIAAQMCgAEDAwABAwOAAQOAAAEDgIABA4EAAQOBgAEDggABA4KAAQODAAEDg4ACAAAAAgAAgAIAAQACAAGAAgACAAIAAoACAAMAAgADgAIAgAACAICAAgCBAAIAgYACAIIAAgCCgAIAgwACAIOAAgEAAAIBAIACAQEAAgEBgAIBAgACAQKAAgEDAAIBA4ACAYAAAgGAgAIBgQACAYGAAgGCAAIBgoACAYMAAgGDgAICAAACAgCAAgIBAAICAYACAgIAAgICgAICAwACAgOAAgKAAAICgIACAoEAAgKBgAICggACAoKAAgKDAAICg4ACAwAAAgMAgAIDAQACAwGAAgMCAAIDAoACAwMAAgMDgAIDgAACA4CAAgOBAAIDgYACA4IAAgOCgAIDgwACA4OAAwAAAAMAAIADAAEAAwABgAMAAgADAAKAAwADAAMAA4ADAIAAAwCAgAMAgQADAIGAAwCCAAMAgoADAIMAAwCDgAMBAAADAQCAAwEBAAMBAYADAQIAAwECgAMBAwADAQOAAwGAAAMBgIADAYEAAwGBgAMBggADAYKAAwGDAAMBg4ADAgAAAwIAgAMCAQADAgGAAwICAAMCAoADAgMAAwIDgAMCgAADAoCAAwKBAAMCgYADAoIAAwKCgAMCgwADAoOAAwMAAAMDAIADAwEAAwMBgAMDAgADAwKAA8Pv/AKSgoACAgIAAAAD/AAD/AAAA//8A/wAAAP8A/wD//wAA////AP/2///////////////2//////////////8A/////////wD///////////8AAAYAAAAAAAAAAwAA/////////wAG/v4A////APv7AwD///////8ABv7+AKSkpKSkAPv7AwD///////8A/gAHBwcHBwcHAPsA/////////6QApAcHBwcHBwekAAD/////////pP+kBwcHpAcHB6T/AP////////+k/6QHB6QApAcHpP8A/////////6T/pAekAAEApAek/wD/////////pP+kpAD5+QEApKT/AP////////+k/////wD5+QEA//8A/////////6SkpKSkpAD5AKSkpKT//////////////////wD//////////////////////////////////////w==";;
		
		string base64_appIcon = @"AAABAAEAICAQAAAAAADoAgAAFgAAACgAAAAgAAAAQAAAAAEABAAAAAAAgAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAACAAAAAgIAAgAAAAIAAgACAgAAAgICAAMDAwAAAAP8AAP8AAAD//wD/AAAA/wD/AP//AAD///8AB3d3d3d3d3d3d3d3d3d3AHd7u7u7u7u7u7u7u7u7d3B3u7u7u7u7u7u7u7u7u7dwe7u7u7u7u7t3d3ZmZmu7cHu7d3d2ZmZoj4iIiIhru3B7u4+IiIiIaI///4iIa7twe7uP//+IiGiP9vb2iHu7cHu4j/b29oh4j/////h7u3B7iI/////4eI/29vb4e7tweIiP9vb2+HiP////+Hi7cHiIj/////h4j/b29vh4i3B4iI/29vb4eI//////eIhweIiP/////3iP/////3iIcHiIj/////94j///+IiIiHB4iI////iIiI////+IiIhweIiI////iIiIiIiIiIiIcHiIiIiIiIiP/4iIiIiIiHCIiIiIj///////iIiIiIhwiIiIiIaP/////4aIiIiIcIiIiIhnaP////hnaIiIiHCIiIiGd3aP//+Gd3aIiIhwiIiIeId2aP/4eId2aIiIcIiIiIeHdmb4+IeHdmaIiICIiIj/eG//////eGiIiIiAiIiIj3hvj///j3hoiIiIgIiIiI+If/////+IeIiIiICIh4iPiH//9///iHiIh4iAiIiIiIiP/////4iIiIiIgIiIiHiIj3+IiHiIiHiIiIAAAAAAiGAAAAAAiGAAAAAAAAbwAAbwAAbwAAbwAAbwAAAAAAAAAAAAAAAAAAAAAACAAAADAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAQAAAAEAAAABAAAAAf8f8f/nnnnn/////w==";
		
		using(var ms = new MemoryStream(Convert.FromBase64String(base64_property)))		
			Property = Image.FromStream(ms);		

		using(var ms = new MemoryStream(Convert.FromBase64String(base64_enum)))		
			Enum = Image.FromStream(ms);		

		using(var ms = new MemoryStream(Convert.FromBase64String(base64_method)))		
			Method = Image.FromStream(ms);

		using(var ms = new MemoryStream(Convert.FromBase64String(base64_class)))		
			Class = Image.FromStream(ms);		
					
		using(var ms = new MemoryStream(Convert.FromBase64String(base64_folder)))		
			Folder = Image.FromStream(ms);
			
		using(var ms = new MemoryStream(Convert.FromBase64String(base64_event)))		
			Event = Image.FromStream(ms);			
		
		using(var ms = new MemoryStream(Convert.FromBase64String(base64_variable)))		
			Variable = Image.FromStream(ms);

		using(var ms = new MemoryStream(Convert.FromBase64String(base64_appIcon)))
			AppIcon = new Icon(ms);
	
	}

}

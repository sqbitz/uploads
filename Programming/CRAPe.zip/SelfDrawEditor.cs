﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class SelfDrawEditor : RichTextBox
{
	public IEnumerable<CompilationErrors.Item> compilationErrors;
	
	public Tokenizer tokenizer;	
		
	protected string currFileName;
	
	protected StatusBarPanel lblLineCount;
	protected StatusBarPanel lblStatus;
	
	protected SizeF fontSize = SizeF.Empty;
	protected float baseFontSize = 11f;
	protected int zoom = 0;
	
	private Timer invalidateTimer;
	private bool keyDownReturn = !false;
	
	public EventHandler ContentChanged;
	public EventHandler BuildTree;
	
	protected DateTime lastOutlineRefresh = DateTime.MinValue;
	private int invalidateTimerCountdown;
	
	public SelfDrawEditor(StatusBarPanel status, StatusBarPanel lineCount)
	{
		BackColor = Color.FromArgb(47, 47, 51);
		Dock = DockStyle.Fill;
		BorderStyle = BorderStyle.None;
		Padding = new Padding(50);
		
		this.lblLineCount = lineCount;
		this.lblStatus = status;
		
		this.Focus();

		this.KeyUp += keyUpHandler;
		this.KeyDown += keyDownHandler;
		this.Paint += onPaintHandler;
		this.SelectionChanged += selectionChangedHandler;

		
		ForeColor = Color.White;

		ZoomFactor = 1.0f;
		
		WordWrap = false;
		ShortcutsEnabled = true;
		RichTextShortcutsEnabled = true;
		HideSelection = true;
		AcceptsTab = true;
		TabStop = false;
		
		invalidateTimer = new Timer{
			Interval = 200,
			Enabled = false
		};		
		invalidateTimer.Tick += (o,e) => {
			this.Invalidate();
			
			//Run another tokenize just for good measure 
			var currLineNum = GetLineFromCharIndex(SelectionStart);
			var currLine = "";
			if(currLineNum > 0 && currLineNum < this.Lines.Length) 
				currLine = this.Lines[currLineNum];

			tokenizer.Tokenize(Text, Lines, currFileName, currLineNum, currLine, false);

			invalidateTimer.Enabled = false;
			invalidateTimer.Stop();
		};
		
		tokenizer = new Tokenizer(null, null);
		tokenizer.TokenizeComplete += tokenizeCompleteHandler;		
	}
	
	protected override void OnCreateControl()
	{
		//Must run SetStyle here to have .Net render RichTextBox correctly
		SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
		
		calculateFont();
		
		//Console.WriteLine("Height: " + FontHeight);
		//Console.WriteLine("Zoom:   " + ZoomFactor);
		//Console.WriteLine("Letter: " + fontSize);
	}
	
	protected void calculateFont()
	{
		//Sets font and font size	
		if(baseFontSize + zoom < 1)
			zoom = 0;
				
		Font = new Font("Consolas", baseFontSize + zoom);
		var sz1 = TextRenderer.MeasureText("<M>", Font);
		var sz2 = TextRenderer.MeasureText("<>", Font);
		fontSize = new SizeF(sz1.Width - sz2.Width, Font.Height);
	}
	
	public void SetFileName(string filename)
	{
		currFileName = filename;
		calculateFont();
	}
	
	protected void selectionChangedHandler(object o, EventArgs a)
	{		
		var currLineNum = GetLineFromCharIndex(SelectionStart);
		if(this.Lines.Length == 0 || currLineNum >= this.Lines.Length)
			return;

		lblLineCount.Text = "Lines: " + this.Lines.Length;

		var firstCharIndex = GetFirstCharIndexFromLine(currLineNum);
		lblStatus.Text = "Ln " + (currLineNum + 1) + ", Col " + (SelectionStart - firstCharIndex + 1) + ", Char " + SelectionStart;
		if(zoom != 0)
			lblStatus.Text += "     Zoom " + zoom.ToString("n0");
	}
	
	private void keyUpHandler(object o, KeyEventArgs args)
	{	
		if(args.KeyData == Keys.Home)
		{
			while(Text[SelectionStart] == '\t')
				SelectionStart++;
		}
		
		var currLineNum = GetLineFromCharIndex(SelectionStart);
		var currLine = "";
		if(currLineNum > 0 && currLineNum < this.Lines.Length) 
			currLine = this.Lines[currLineNum];
			
		//Handle auto tab in
		if(args.KeyData == Keys.Return && keyDownReturn)
		{
			keyDownReturn = false;
			var isHTMLBetweenTags = currFileName.Trim().EndsWith(".html") 
							&& SelectionStart > 3 
							&& SelectionStart < Text.Length - 3
							&& Text[SelectionStart - 2] == '>' 
							&& Text[SelectionStart] == '<';
			
			//We are already on the next line down which would have 0 tabs so go back up one line				
			var numTabs = this.Lines[currLineNum - 1].Where(x => x == '\t').Count();
			var numTabsNext = 0;
			if(currLineNum + 1 < this.Lines.Length)
				numTabsNext = this.Lines[currLineNum + 1].Where(x => x == '\t').Count();
		
			var isCurlyBracket = SelectionStart > 3 
							&& SelectionStart < Text.Length - 2
							&& Text[SelectionStart - 2] == '{';
							
			var isNextLineCurlyBracket = currLineNum + 1 < this.Lines.Length
								&& this.Lines[currLineNum + 1].Trim() == "}";
								
			var addCurlyBracket = isCurlyBracket && numTabs >= numTabsNext && isNextLineCurlyBracket == false;
			//Console.WriteLine("Prev: {0}  Next: {1}   Is:{2} Next:{3} Add:{4}", numTabs, numTabsNext, isCurlyBracket, isNextLineCurlyBracket, addCurlyBracket);
			
			try
			{
				if(currLineNum == 0)
					return;
				
				var sb = new StringBuilder();
				for(var i = 0; i < numTabs; i++)
					sb.Append('\t');
					
				 //Tab in another spot
				if(isCurlyBracket && !addCurlyBracket)
					sb.Append("\t");
					
				//Tab in another when <enter> after { and when between ><
				if(isHTMLBetweenTags || addCurlyBracket)
				{
					sb.Append("\t\n");
					for(var i = 0; i < numTabs; i++)
						sb.Append('\t');
				}
				
				if(addCurlyBracket)
					sb.Append('}');
					
				SelectedText = sb.ToString();
				
				if(isHTMLBetweenTags || addCurlyBracket)
					SelectionStart = SelectionStart - numTabs - 1;
					
				//Go back one more to account for the added }
				if(addCurlyBracket)
					SelectionStart--;
			}
			catch(Exception c)
			{
				Console.WriteLine("Return Tab Error: " + currLineNum);
				Console.WriteLine(c);
			}
		}
		
		/*
		try
		{
			var isAltCtrlShift = args.Alt == false && args.Control == false && args.Shift == false;
			var shouldIgnore = (args.KeyData == Keys.Up || args.KeyData == Keys.Down || args.KeyData == Keys.Left || args.KeyData == Keys.Right 
						|| args.KeyData == Keys.Home || args.KeyData == Keys.End || args.KeyData == Keys.PageDown || args.KeyData == Keys.PageUp);
			if(isAltCtrlShift == false 
				//&& shouldIgnore == false
				&& args.KeyData != (Keys.Control | Keys.S) 
				&& args.KeyData != (Keys.Shift | Keys.Delete)
				&& args.KeyData != (Keys.Control | Keys.Space))
				ContentChanged(null, null);
		}
		catch(Exception) {} 
		*/
		
		tokenizer.Tokenize(Text, Lines, currFileName, currLineNum, currLine, true);
		invalidateTimer.Enabled = true;
		invalidateTimer.Stop();
		invalidateTimer.Start();
	}
	
	private void keyDownHandler(object sender, KeyEventArgs args)
	{
		//When debugging console apps a "KeyUp" event occurs with <return> but no accompanying "KeyDown"
		//Do this to prevent the editor from handling the "KeyUp"
		keyDownReturn = false;
		if(args.KeyData == Keys.Return)
			keyDownReturn = true;
			
		if(args.Control && args.KeyCode == Keys.V)
		{
			this.Paste(DataFormats.GetFormat("Text"));
			args.Handled = true;
			return;
		}
	}
	
	private void tokenizeCompleteHandler(object e, TokenizeCompleteEventArgs args)
	{		
		//Console.WriteLine("- " + args.TimeElapsed);
	
		this.Invalidate(true);
		
		if((DateTime.Now - lastOutlineRefresh).TotalSeconds <= 5)
			return;		
		try
		{
			this.BeginInvoke(new Action<OutlineNode>(buildOutlineTree), new object[] { args.Outline });
		}
		catch(Exception ex) { 
			Console.WriteLine("Error with Outline " + ex);
		}
		
	}
	
	public void buildOutlineTree(OutlineNode on)
	{	
		try
		{	
			var first = populateOutlineTreeNode(on);	
			first.Text = currFileName;
	
			BuildTree(first, new EventArgs());
			lastOutlineRefresh = DateTime.Now;
		}
		catch(Exception ex) { 
			//Console.WriteLine("Error building tree " + ex);
		}
	}
	
	private TreeNode populateOutlineTreeNode(OutlineNode on)
	{
		var n = new TreeNode(on.Name) { Tag = on.Index };
		foreach(var onNode in on.Nodes)
			n.Nodes.Add(populateOutlineTreeNode(onNode));

		return n;
	}
	
	public void tvCodeOutlineClicked(object o, TreeNodeMouseClickEventArgs e)
	{
		int index = (int)(e.Node).Tag;
		SelectionStart = index;
		ScrollToCaret();
	}
	
	private void onPaintHandler(object sender, PaintEventArgs e)
	{
		int numLines = (int)Math.Ceiling(e.ClipRectangle.Height / fontSize.Height);
		int startLine = GetLineFromCharIndex(GetCharIndexFromPosition(e.ClipRectangle.Location));
		int endLine = startLine + numLines;
		if(endLine >= Lines.Length)
			endLine = Lines.Length - 1;
			
		//Console.WriteLine("Draw Lines: " + startLine + "-" + endLine);
			
		using(var bgc = new BufferedGraphicsContext())
		using(var bg = bgc.Allocate(e.Graphics, e.ClipRectangle))
		using(var g = bg.Graphics)
		{
			g.FillRectangle(new SolidBrush(Color.FromArgb(47, 47, 51)), e.ClipRectangle);
		
			if(SelectionLength > 0)
			{
				var selStartLine = GetLineFromCharIndex(SelectionStart);
				var selEndLine = GetLineFromCharIndex(SelectionStart + SelectionLength);
				//Console.WriteLine("Selection: " + SelectionStart.ToString() + " " + SelectionLength + " " + selStartLine + "-" + selEndLine + "   " + SelectedText + "|");
				var selectedSplit = SelectedText.Split('\n');
				int splitLine = 0;
				
				var selPosition = SelectionStart;
				int selectionRemaining = SelectionLength;
				var selectionBrush = new SolidBrush(Color.FromArgb(90, Color.FromKnownColor(KnownColor.Highlight)));
				for(var line = selStartLine; line <= selEndLine; line++)
				{
					var lineFirstChar = GetFirstCharIndexFromLine(line);
					var lineLastChar = lineFirstChar + Lines[line].Length;
					//var length = lineLastChar - selPosition;
					//if(line == selStartLine && line == selEndLine)
					//	length = SelectionLength;
					//else if(line == selEndLine)
					//	length = selectionRemaining - 1;
					var length = selectedSplit[splitLine].Length;

					try
					{
						var tabCount = Text.Substring(selPosition, length).Count(x => x == '\t');
						var drawWidth = (int)(fontSize.Width * (length + (tabCount * 5)));
						var posStart = GetPositionFromCharIndex(selPosition);
						//Console.WriteLine("  " + line + ": " + selPosition.ToString().PadRight(3) + " " + length.ToString().PadRight(3) + " " + posStart + " tabs: " + tabCount);
						g.FillRectangle(selectionBrush, posStart.X, posStart.Y, drawWidth, (int)fontSize.Height);
	
						selPosition = selPosition + length + 1;
						//selectionRemaining -= length;
					}
					catch(Exception) { }
					splitLine++;
				}
			}
			
			drawLines(startLine, endLine, g);
			
			try
			{
				g.SmoothingMode = SmoothingMode.AntiAlias;
				if(compilationErrors != null)
					foreach(var c in compilationErrors)
					{
						var startIndex = GetFirstCharIndexFromLine(c.StartLine - 1) + c.StartColumn;
						var endIndex = GetFirstCharIndexFromLine(c.EndLine - 1) + c.EndColumn - 1;
	
						var startPt = GetPositionFromCharIndex(startIndex - 1);
						var endPt = GetPositionFromCharIndex(endIndex);
	
						g.DrawLine(Pens.Red, startPt.X, startPt.Y + fontSize.Height - 2, endPt.X, startPt.Y + fontSize.Height - 2);
	
						var pt = GetPositionFromCharIndex(GetFirstCharIndexFromLine(c.StartLine - 1));
						g.FillEllipse(Brushes.Red, pt.X - (fontSize.Height / 2) + 1, pt.Y+2, fontSize.Height - 3, fontSize.Height - 3);
					}
			}
			catch(Exception c)
			{
				Console.WriteLine("CompErrors: " + c);
			}
					
			bg.Render();
		}
	}
	
	protected void drawLines(int startLine, int endLine, Graphics g, bool drawVisualScroll = false)
	{
		var brackets = new [] { 
			'(', ')',
			'[', ']'
		};
		
		var font = this.Font;
		var dlFontSize = fontSize;
		var pos = new Point(5,10); //5,10 for visual scroll
		if(drawVisualScroll)
		{
			font = new Font(this.Font.FontFamily, 2);
			var sz1 = TextRenderer.MeasureText("<M>", font);
			var sz2 = TextRenderer.MeasureText("<>", font);
			dlFontSize = new SizeF(sz1.Width - sz2.Width, font.Height);
		}
		
	
		for(var i = startLine; i <= endLine; i++)
		{
			var lineFirstCharIndex = GetFirstCharIndexFromLine(i);
			if(drawVisualScroll == false)
			{
				pos = GetPositionFromCharIndex(lineFirstCharIndex);
				pos.X -= 3; //-3,+1 to account for how the Position gets returned
				pos.Y += 1;
			}

			var l = Lines[i];
			var tokens = tokenizer.GetLineTokens(lineFirstCharIndex);
	
			var defaultBrush = new SolidBrush(ColorTranslator.FromHtml("#F6F2F3"));
			var commentBrush = new SolidBrush(ColorTranslator.FromHtml("#57A64A"));
			Brush color = defaultBrush;

			for(var j = 0; j < l.Length; j++)
			{
				font = this.Font;
				if(tokens != null)
				{
					var t = tokens.LastOrDefault(x => lineFirstCharIndex + j >= x.StartIndex && lineFirstCharIndex + j < x.StartIndex + x.Name.Length);
					if(t != null)
						color = t.Color;

					if(brackets.Any(x => x == l[j]) && (t == null || t.TokenType != TokenType.Comment))
						color = Brushes.BlueViolet;
				}
				if(l[j] == '`')
				{
					color = Brushes.GreenYellow;
					font = new Font(this.Font, FontStyle.Bold);
				}

				g.DrawString(l[j].ToString(), font, color, pos.X, pos.Y);

				pos.X += (int)dlFontSize.Width;
				if(l[j] == '\t')
					pos.X = GetPositionFromCharIndex(lineFirstCharIndex + j + 1).X - 3;
					
				color = defaultBrush;
			}
			
			if(drawVisualScroll)
			{
				pos.Y += (int)dlFontSize.Height;
				pos.X = 5;
			}
		}
	}
	
	protected override void WndProc(ref Message m)
	{
		//Disable native Ctrl + mouse wheel zoom
		if((m.Msg == 0x115 || m.Msg == 0x20a) && (Control.ModifierKeys & Keys.Control) != 0)
		{
			var change = m.WParam.ToString().StartsWith("7") ? 1 : -1;
			zoom += change;
			calculateFont();
			Invalidate();
			
			return;
		}
			
		base.WndProc(ref m);
	}
	
	
	public void Diag_ShowLineTokens()
	{
		foreach(var lt in tokenizer.GetTokens())
		{
			Console.WriteLine(lt.Item1.ToString().PadRight(7) + lt.Item2.ToString().PadRight(7) + "Tokens: " + lt.Item3.Count);
			foreach(var t in lt.Item3)
				Console.WriteLine("\t" + t);
		}
	}
	
	public void Diag_ShowCurrLineTokens()
	{		
		var tokens = tokenizer.GetLineTokens(this.GetFirstCharIndexOfCurrentLine());
		foreach(var t in tokens)
			Console.WriteLine("\t" + t);
	}
}

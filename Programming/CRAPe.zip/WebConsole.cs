﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.Drawing;
using System.Text;
using System.Data;
using System.Data.SQLite;
using System.Collections.Generic;
using System.Net;
using System.IO;
using Newtonsoft.Json;

	
public class WebConsole : TabPage
{
	TextBox txtURL;
	Button btnRun;
	ComboBox drpVerb;
	ComboBox drpContentType;
	ComboBox drpAccept;
	TextBox txtPostContent;
	
	Label lblStatusCode;
	DataGridView dgvRespHeaders;
	
	RichTextBox txtResponse;
	
	public WebConsole() : base("Web Console    ")
	{
		BackColor = Color.FromArgb(47, 47, 51);
		ForeColor = Color.White;
		Dock = DockStyle.Fill;
		Font = new Font(this.Font.FontFamily, 10);
		
		var tlpMain = new TableLayoutPanel(){
			Dock = DockStyle.Fill
		};
		tlpMain.CellPaint += (o,e) => {
			if(e.CellBounds.X < 10)
				return;
			
			e.Graphics.DrawLine(Pens.DarkRed, e.CellBounds.X, e.CellBounds.Y + 7, e.CellBounds.X, e.CellBounds.Y + e.CellBounds.Height - 7);
		};
		var ltlp = new TableLayoutPanel() {
			Dock = DockStyle.Fill,
			Width = 450,
			Padding = new Padding(5)
		};
		tlpMain.Controls.Add(ltlp, 0, 0);
					
		var lblURL = new Label() { Text = "URL", TextAlign = ContentAlignment.MiddleRight };
		ltlp.Controls.Add(lblURL, 0, 0);
		
		txtURL = new TextBox() { 
			Width = 250,
			Text = "http://localhost:12345/"
		};
		ltlp.Controls.Add(txtURL, 1, 0);
		
		btnRun = new Button() { Text = "Execute"  };
		btnRun.Click += executeRequest;
		ltlp.Controls.Add(btnRun, 2, 0);
		
		var lblVerb = new Label() { Text = "Verb", TextAlign = ContentAlignment.MiddleRight };
		ltlp.Controls.Add(lblVerb, 0, 1);
		
		drpVerb = new ComboBox(){
			AutoCompleteMode = AutoCompleteMode.None,
			DropDownStyle = ComboBoxStyle.DropDownList
		};
		drpVerb.Items.AddRange(new [] { "GET", "POST", "DELETE" });
		drpVerb.SelectedIndex = 0;
		ltlp.Controls.Add(drpVerb, 1, 1);
		
		var lblContentType = new Label() { Text = "Content Type", TextAlign = ContentAlignment.MiddleRight };
		ltlp.Controls.Add(lblContentType, 0, 2);
		
		drpContentType = new ComboBox() {
			AutoCompleteMode = AutoCompleteMode.None,
			DropDownStyle = ComboBoxStyle.DropDownList
		};
		drpContentType.Items.AddRange(new [] { "application/json", "text/plain", "text/html", "text/xml"});
		drpContentType.SelectedIndex = 0;
		ltlp.Controls.Add(drpContentType, 1, 2);
		
		var lblAcceptType = new Label() { Text = "Accept", TextAlign = ContentAlignment.MiddleRight };
		ltlp.Controls.Add(lblAcceptType, 0, 3);
		
		drpAccept = new ComboBox() {
			AutoCompleteMode = AutoCompleteMode.None,
			DropDownStyle = ComboBoxStyle.DropDownList
		};
		drpAccept.Items.AddRange(new [] { "application/json", "text/xml"});
		drpAccept.SelectedIndex = 0;
		ltlp.Controls.Add(drpAccept, 1, 3);
		
		
		var lblPostContent = new Label() { Text = "POST Content", TextAlign = ContentAlignment.MiddleRight };
		ltlp.Controls.Add(lblPostContent , 0, 4);
		
		txtPostContent = new TextBox() {
			Multiline = true,
			Height = 120,
			Width = 300,
			AcceptsTab = true,
			Font = new Font("Consolas", 10)
		};
		ltlp.Controls.Add(txtPostContent, 1, 4);
		ltlp.SetColumnSpan(txtPostContent, 2);
		
		txtResponse = new RichTextBox() {
			Multiline = true,
			Dock = DockStyle.Fill,
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = ColorTranslator.FromHtml("#F6F2F3"),
			BorderStyle = BorderStyle.None,
			Font = new Font("Consolas", 13),
			Margin = new Padding(10),
			Width = 500,
		};
		tlpMain.Controls.Add(txtResponse, 1, 0);
		
		dgvRespHeaders = new DataGridView() {
			Dock = DockStyle.Fill,
			AutoGenerateColumns = true,
			BorderStyle = BorderStyle.None,
			AutoSize = true,
			AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
			GridColor = Color.FromArgb(30, 30, 34),
			BackColor = Color.FromArgb(47, 47, 51),
			BackgroundColor = Color.FromArgb(47, 47, 51),
			EditMode = DataGridViewEditMode.EditProgrammatically,
			ForeColor = Color.White,
			SelectionMode = DataGridViewSelectionMode.FullRowSelect,
			AllowUserToAddRows = false,
			AllowUserToDeleteRows = false,
			AllowUserToOrderColumns = false,
			AllowUserToResizeRows = false,
			ShowCellErrors = false,
			ShowEditingIcon = false,
			RowHeadersVisible = false
		};
		
		dgvRespHeaders.AdvancedCellBorderStyle.All = DataGridViewAdvancedCellBorderStyle.Single;
		dgvRespHeaders.RowsDefaultCellStyle = new DataGridViewCellStyle{
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = Color.White
		};
		dgvRespHeaders.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle {
			BackColor = Color.FromArgb(37, 37, 41),
			ForeColor = Color.White
		};
		
		lblStatusCode = new Label() {
			Font = new Font(this.Font, FontStyle.Bold)
		};
		
		var tlpHeaders = new TableLayoutPanel() {
			Dock = DockStyle.Fill,
			Margin = new Padding(10),
		};
		//tlpHeaders.Controls.Add(lblStatusCode, 0, 0);
		tlpHeaders.Controls.Add(dgvRespHeaders, 0, 0);
		
		tlpMain.Controls.Add(tlpHeaders, 2, 0);
		Controls.Add(tlpMain);
	}
	
	private void executeRequest(object sender, EventArgs e)
	{
		try
		{
			var wc = new WebClient();
			var url = txtURL.Text;
		
			var selectedText = drpVerb.Items[drpVerb.SelectedIndex];
			var response = "";
			wc.Headers[HttpRequestHeader.Accept] = drpAccept.Items[drpAccept.SelectedIndex].ToString();
			
			if(selectedText == "GET")
				response = wc.DownloadString(url);
			else if(selectedText == "POST")
			{
				wc.Headers[HttpRequestHeader.ContentType] = drpContentType.Items[drpContentType.SelectedIndex].ToString();
				response = wc.UploadString(url, txtPostContent.Text);
			}
			
			var contentTypeHeaderValues = wc.ResponseHeaders.GetValues("Content-Type");
			if(contentTypeHeaderValues != null && contentTypeHeaderValues.Length > 0 && contentTypeHeaderValues[0] != null && contentTypeHeaderValues[0].Contains("json"))
			{
				var obj = Newtonsoft.Json.JsonConvert.DeserializeObject(response);
				response = Newtonsoft.Json.JsonConvert.SerializeObject(obj, Formatting.Indented);
			}
			txtResponse.Text = response;
					
			var dt = new DataTable();
			dt.Columns.Add("Header");
			dt.Columns.Add("Value");
			foreach(var hk in wc.ResponseHeaders.AllKeys)
				dt.Rows.Add(new[] { hk, wc.ResponseHeaders.GetValues(hk)[0] });
			foreach(var hk in wc.Headers.AllKeys)
				dt.Rows.Add(new[] { "Req: " + hk, wc.Headers.GetValues(hk)[0] });
				
			dgvRespHeaders.DataSource = dt;
		}
		catch(Exception c)
		{
			txtResponse.Text = "Error in Request\n" + c.Message + "\n" + c.StackTrace;
		}
	}
	
	
	
	
	
	
	
	
}

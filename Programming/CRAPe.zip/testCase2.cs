﻿using System;
using System.Reflection;
using System.Collections.Generic;
using Microsoft.JScript;

public class test1
{
	public test1()
	{
		//Console.WriteLine("Hello!");
		//var strVal = Console.ReadLine();
		//var l = new List<IAppBuilder>();	
			
		//var t = System.Web.UI.HtmlTextWriterStyle.Padding;
	}
}

﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Data.SQLite;
using System.Collections.Generic;

	
public class SQLConsole : TabPage
{
	private TreeView tree;
	
	public EventHandler AddCommand;
	
	public SQLConsole() : base("Database     ")
	{
		BackColor = Color.FromArgb(47, 47, 51);
		ForeColor = Color.White;
		Dock = DockStyle.Fill;
		
		tree = new TreeView() {
			Dock = DockStyle.Fill,
			ShowNodeToolTips = true,
			LineColor = Color.Red,
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = Color.White,
			Margin = new Padding(0),
			BorderStyle = BorderStyle.None,
			Font = new Font(this.Font.FontFamily, 9)
		};
		
		refresh(null, null);
		this.Controls.Add(tree);
	}
	
	public void Refresh()
	{
		refresh(null, null);
	}
	
	private void refresh(object sender, EventArgs eventArgs)
	{
		tree.Nodes.Clear();
		
		var main = tree.Nodes.Add("Database");
		main.ContextMenu = new ContextMenu(new MenuItem[] {
			new MenuItem("Refresh", refresh)
		});
		
		var tNode = main.Nodes.Add("Tables");
		tNode.ContextMenu = new ContextMenu(new MenuItem[] {
			new MenuItem("Create Table", (o,e) => {
				AddCommand(@"
CREATE TABLE [TableName] (
	[ColumnName1] type,
    	[ColumnName2] type
)", null);
			})
		});
		var vNode = main.Nodes.Add("Views");
		vNode.ContextMenu = new ContextMenu(new MenuItem[] {
			new MenuItem("Create View", (o,e) => {
				AddCommand(@"
CREATE VIEW [vName] AS
   SELECT * FROM [Table]", null);
			})
		});
		var tableNodes = new Dictionary<string, TreeNode>();
		
		using(var conn = new SQLiteConnection("Data Source=app.db;Pooling=true;FailIfMissing=false"))
		using(var conn2 = new SQLiteConnection("Data Source=app.db;Pooling=true;FailIfMissing=false"))
		{
			conn.Open();
			conn2.Open();
			using(var cmd = new SQLiteCommand(@"SELECT * 
									FROM sqlite_master 
									WHERE name NOT LIKE 'sqlite%' 
									ORDER BY type DESC, tbl_name", conn))
			using(var rdr = cmd.ExecuteReader())
			{
				while(rdr.Read())
				{
					var name = rdr["name"].ToString();
					var n = new TreeNode(name) {
						Tag = rdr["sql"].ToString()
					};
					n.ContextMenu = new ContextMenu();
					
					var itemType = rdr["type"].ToString();
					
					var sqlDef = rdr["sql"];
					string definition = null; 
					if(sqlDef != DBNull.Value && sqlDef.ToString() != "")
						definition = sqlDef.ToString();
					
					if(itemType == "table" || itemType == "view")
					{
						n.ContextMenu.MenuItems.Add(new MenuItem("SELECT All Rows", (o,e) => { AddCommand("SELECT * FROM " + name, null); }));
						
						if(itemType == "table")
						{
							tNode.Nodes.Add(n);
							n.ForeColor = Color.CornflowerBlue;
							tableNodes[name] = n;
							n.ContextMenu.MenuItems.Add(new MenuItem("Create Index", (o,e) => { AddCommand(@"
CREATE INDEX [IX_IndexName] ON [" + name + @"] 
(
	[Column1] ASC,
	[Column2] DESC
)", null); }));
						}
						else if(itemType == "view")
							vNode.Nodes.Add(n);
						
						var columnsNode = n.Nodes.Add("Columns");
						columnsNode.Name = "Columns";
						
						var autoincrementCols = new Dictionary<string, bool>();
						var primaryKeyCols = new Dictionary<string, bool>();
						var notNullCols = new Dictionary<string, bool>();
						if(definition != null)
						{
							var colDefRegex = new Regex(@"(?<colName>\[\w+\]) (?<dataType>\w+(\(\d+\))?).*\n");
							var matches = colDefRegex.Matches(definition);
							foreach(Match m in matches)
							{
								var colName = m.Groups["colName"].Value.Trim('[', ']', '.', ' ');
								primaryKeyCols[colName] = m.Value.ToLower().Contains("primary key");
								autoincrementCols[colName] = m.Value.ToLower().Contains("autoincrement");
								notNullCols[colName] = m.Value.ToLower().Contains("not null");
							}
							var pkConstraintRegex = new Regex(@"PRIMARY KEY\s*\n\s*\(\n(\s*(?<colName>\[\w+\]) (A|DE)SC,?\n)+\s*\)");
							matches = pkConstraintRegex.Matches(definition);
							foreach(Match m in matches)
								foreach(Capture c in m.Groups["colName"].Captures)
									primaryKeyCols[c.Value.Trim('[', ']', '.', ' ')] = true;
						}
						
						using(var cmd2 = new SQLiteCommand("SELECT * FROM " + name + " LIMIT 1", conn2))
						using(var rdr2 = cmd2.ExecuteReader())
						{
							for(var i = 0; i < rdr2.FieldCount; i++)
							{
								var colName = rdr2.GetName(i);
								var colNode = new TreeNode(colName + " " + rdr2.GetDataTypeName(i));
								var sb = new StringBuilder();

								if(primaryKeyCols.ContainsKey(colName) && primaryKeyCols[colName])
								{
									colNode.ForeColor = Color.Green;
									colNode.NodeFont = new Font(tree.Font, FontStyle.Bold);
									sb.Append("Primary Key\n");
								}
								if(autoincrementCols.ContainsKey(colName) && autoincrementCols[colName])
									sb.Append("Auto Increment\n");
								if(notNullCols.ContainsKey(colName) && notNullCols[colName])
									sb.Append("Not Null\n");

								colNode.ToolTipText = sb.ToString().Trim();
								columnsNode.Nodes.Add(colNode);
							}
						}
						columnsNode.Expand();
					}
					else if(itemType == "index")
					{
						var tn = tableNodes[rdr["tbl_name"].ToString()];
						
						var i = tn.Nodes.IndexOfKey("Indexes");
						if(i < 0)
						{
							tn.Nodes.Add(new TreeNode("Indexes") { Name = "Indexes" });
							i = tn.Nodes.IndexOfKey("Indexes");
						}
							
						var indexNode = tn.Nodes[i];
							
						indexNode.Nodes.Add(n);
					}
					
					if(definition != null)
						n.ContextMenu.MenuItems.Add(new MenuItem("View Definition", (o,e) => { AddCommand(definition, null); }));
				}
					
			}
		}
		
		tree.Nodes[0].Expand();
		tree.Nodes[0].Nodes[0].Expand();
	}
}

public class SQLEditor : TabPage
{
	private SelfDrawEditor editor;
	public SQLEditor(StatusBarPanel status, StatusBarPanel lineCount) : base("SQL Editor        ")
	{
		BackColor = Color.FromArgb(47, 47, 51);
		ForeColor = Color.White;
		Dock = DockStyle.Fill;
		Padding = new Padding(10);
		
		editor = new SelfDrawEditor(status, lineCount);
		editor.SetFileName("SQL Editor");
		
		editor.KeyDown += keyDownHandler;
		this.Controls.Add(editor);
	}
	
	public void AddCommand(string cmd)
	{
		editor.AppendText("\n\n" + cmd);
		if(cmd.StartsWith("SELECT "))
			ExecuteSQL(cmd, null);
	}
	
	private void keyDownHandler(object o, KeyEventArgs args)
	{
		if(args.KeyData == Keys.F9)
		{
			var text = editor.Text;
			if(editor.SelectedText.Length > 1)
				text = editor.SelectedText;
				
			ExecuteSQL(text, null);
		}
	}
	
	public EventHandler ExecuteSQL;
}

public class SQLQueryResults : TabPage
{
	private DataGridView dgv;
	private Label lblNoResults;
	private StatusBarPanel status;
	public SQLQueryResults(StatusBarPanel status) : base("Query Results        ")
	{
		BackColor = Color.FromArgb(47, 47, 51);
		ForeColor = Color.White;
		Dock = DockStyle.Fill;
		
		this.status = status;
		
		lblNoResults = new Label() {
			Padding = new Padding(10),
			BackColor = Color.Gray,
			ForeColor = Color.Black,
			Width = 200,
			Height = 100,
			Font = new Font("Consolas", 14),
			Top = 50,
			TextAlign = ContentAlignment.MiddleCenter,
			Visible = false
		};
		lblNoResults.Text = "No results";
		
		dgv = new DataGridView(){
			Dock = DockStyle.Fill,
			AutoGenerateColumns = true,
			
			AutoSize = true,
			RowHeadersVisible = false,
			GridColor = Color.FromArgb(30, 30, 34),
			BackColor = Color.FromArgb(47, 47, 51),
			BackgroundColor = Color.FromArgb(47, 47, 51),
			EditMode = DataGridViewEditMode.EditProgrammatically,
			ForeColor = Color.White,
			BorderStyle = BorderStyle.None,
			SelectionMode = DataGridViewSelectionMode.FullRowSelect,
			AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
			AllowUserToAddRows = false,
			AllowUserToDeleteRows = false,
			AllowUserToOrderColumns = false,
			AllowUserToResizeRows = false,
			ShowCellErrors = false,
			ShowEditingIcon = false,
		};
		
		dgv.AdvancedCellBorderStyle.All = DataGridViewAdvancedCellBorderStyle.Single;
		dgv.RowsDefaultCellStyle = new DataGridViewCellStyle{
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = Color.White
		};
		dgv.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle {
			BackColor = Color.FromArgb(37, 37, 41),
			ForeColor = Color.White
		};
		
		dgv.DefaultCellStyle.NullValue = "NULL";
		
		dgv.FontChanged += (o,e) => {
			dgv.AutoResizeColumns();
			dgv.RowTemplate.Height = (int)dgv.Font.Size + 10;
			dgv.AutoResizeColumnHeadersHeight();
			dgv.Refresh();
		};
				
		this.Controls.Add(dgv);
		this.Controls.Add(lblNoResults);
	}
	
	public int ExecuteSQL(string command)
	{
		Console.WriteLine("Executing " + command);
		status.Text = "Executing...";
		var dt = new DataTable();
		lblNoResults.Visible = false;
		try
		{
			dgv.DataSource = null;
			dgv.Columns.Clear();
			var sw = new System.Diagnostics.Stopwatch();
			sw.Start();
			using(var conn = new SQLiteConnection("Data Source=app.db;Pooling=true;FailIfMissing=false"))
			{
				conn.Open();
				using(var da = new SQLiteDataAdapter(command, conn))
				{		
					var numRows = da.Fill(dt);
					sw.Stop();
					dgv.DataSource = dt.DefaultView;
					Console.WriteLine(numRows + " rows returned.");
					status.Text = numRows + " rows returned in " + sw.ElapsedMilliseconds.ToString("n0") + "ms";
				}
			}
		}
		catch(Exception c)
		{
			Console.WriteLine("Error: " + c.Message);
			status.Text = "Error: " + c.Message;
			MessageBox.Show("Error executing SQL\n" + c.Message);
		}
		
		if(dt.DefaultView.Count <= 0)
		{
			lblNoResults.Visible = true;
			lblNoResults.Left = this.Width / 2 - lblNoResults.Width / 2;
			lblNoResults.BringToFront();
		}
		
		return dt.DefaultView.Count;
	}
}

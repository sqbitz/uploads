﻿using System;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Drawing.Drawing2D;

public class MyTabControl : TabControl
{
	private Point mouseLocation;
	private bool showClose;
	public MyTabControl(bool showCloseButton = false)
	{
		Dock = DockStyle.Fill;
		Padding = new Point(0,0);
		Margin = new Padding(0);
		//Font = new Font(this.Font.FontFamily, 9);
		
		//First blank tab for spacing
		TabPages.Add(new TabPage("") {
			Enabled = false,
		});
		
		this.Paint += onPaintHandler;
		this.MouseMove += (object o, MouseEventArgs e) => { mouseLocation = e.Location; };
		this.MouseLeave += (object o, EventArgs e) => { mouseLocation = new Point(-1, -1); };
		this.Selecting += (object o, TabControlCancelEventArgs e) => {
			if(e.Action == TabControlAction.Selecting && e.TabPageIndex == 0)
				e.Cancel = true;
		};
		this.MouseClick += (object o, MouseEventArgs e) => {
			for(var i = 0; i < this.TabPages.Count; i++)
			{
				var text = this.TabPages[i].Text;
				var rect = this.GetTabRect(i);
				if(text.StartsWith("SQL") == false 
					&& text.StartsWith("Database") == false
					&& showClose == true
					&& rect.Contains(e.Location) 
					&& e.Location.X >= rect.X + rect.Width - 13 && e.Location.X <= rect.X + rect.Width - 5)
				{
					this.TabPages.RemoveAt(i);
					this.SelectTab(this.TabPages.Count - 1);
					break;
				}
			}	
		};
		
		showClose = showCloseButton;
	}
	
	protected override void OnCreateControl()
	{
		//Must run SetStyle here to have .Net render correctly
		SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
	}
	
	public bool SelectTab(string name)
	{
		for(var i = 0; i < this.TabPages.Count; i++)
		{
			if(TabPages[i].Text.StartsWith(name) == false)
				continue;
			
			this.SelectTab(i);
			return true;
		}
		
		return false;
	}
	
	private void onPaintHandler(object sender, PaintEventArgs e)
	{
		//Console.WriteLine(e.ClipRectangle + " " + mouseLocation);
		e.Graphics.FillRectangle(new SolidBrush(this.Parent.BackColor), e.ClipRectangle);
		
		e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
		e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
		var firstTabRect = GetTabRect(0);
		
		//Bit before tab
		//e.Graphics.DrawLine(Pens.DarkRed, , firstTabRect.Y + firstTabRect.Height + 1, firstTabRect.X + 9, firstTabRect.Y + firstTabRect.Height);
		
		
		//Left side border
		//e.Graphics.DrawLine(Pens.Black, 2, firstTabRect.Y + firstTabRect.Height + 1, 2, this.Bounds.AliceBlueHeight - 4);
		
		//Bottom border
		e.Graphics.DrawLine(Pens.DarkRed, 4, this.Bottom - 4, this.Bounds.Width - 4, this.Bottom - 4);

		for(var i = TabPages.Count - 1; i > 0; i--)
		{
			var rect = this.GetTabRect(i);
			var p = new GraphicsPath();
			
			var top = rect.Y + 1; //lower top by a bit;
			var bottom = rect.Y + rect.Height + 3;
			if(i == SelectedIndex)
			{
				top = rect.Y - 2; //Raise top
				bottom = rect.Y + rect.Height + 5; //lower bottom
			}
		
			
			p.AddLine(rect.X + 9, top, rect.X + rect.Width, top); //Top
			p.AddLine(rect.X + rect.Width, top, rect.X + rect.Width, bottom); //Right
			p.AddLine(rect.X + rect.Width, bottom, rect.X, bottom); //Bottom
			p.AddLine(rect.X, bottom, rect.X, top + 13); //Left
			p.AddLine(rect.X, top + 13, rect.X + 9, top); //Angle
			
			var b = new LinearGradientBrush(rect, Color.FromArgb(47, 47, 51), Color.FromArgb(20, 20, 29), LinearGradientMode.Vertical);
			if(rect.Contains(mouseLocation))
				b = new LinearGradientBrush(rect, Color.FromArgb(70, 60, 60), Color.FromArgb(40, 30, 30), LinearGradientMode.Vertical);

			if(i == SelectedIndex)
				//e.Graphics.FillPath(new SolidBrush(Color.FromArgb(47, 47, 51)), p);
				e.Graphics.FillPath(new LinearGradientBrush(rect, Color.FromArgb(20, 20, 29), Color.FromArgb(47, 47, 51), LinearGradientMode.Vertical), p);
			else
				e.Graphics.FillPath(b, p);
			
			e.Graphics.DrawPath(Pens.Black, p);
			
			var text = TabPages[i].Text;
			if(text.TrimEnd().EndsWith("*"))
			{
				text = text.TrimEnd(new[] {'*', ' '});
				e.Graphics.DrawString("!", new Font("Britannic Bold", 14), Brushes.Yellow, rect.X + rect.Width - 26, top);
			}

			e.Graphics.DrawString(text, Font, Brushes.White, rect.X + 12, top + 3);
			
			if(showClose && TabPages[i].Text.StartsWith("SQL Editor") == false)
			{
				e.Graphics.DrawLine(Pens.Red, rect.X + rect.Width - 13, top + 5, rect.X + rect.Width - 5, top + 13);
				e.Graphics.DrawLine(Pens.Red, rect.X + rect.Width - 13, top + 13, rect.X + rect.Width - 5, top + 5);
			}
		}
		
		//Line under tabs
		e.Graphics.DrawLine(Pens.DarkRed, 4, firstTabRect.Y + firstTabRect.Height + 1, 
								this.Bounds.Width, firstTabRect.Y + firstTabRect.Height + 1);
		
		//Had to add this due to tabs being removed now with the close box
		try
		{
			var str = this.GetTabRect(SelectedIndex);
			e.Graphics.DrawLine(new Pen(Color.FromArgb(47, 47, 51)), str.X + 1,  str.Y + str.Height + 1,
													str.X + str.Width - 1, str.Y + str.Height + 1);	
		}
		catch(Exception c)
		{}
	}
	
	private void onDrawItemHandler(object sender, DrawItemEventArgs e)
	{
		e.DrawBackground();
		e.Graphics.FillRectangle(Brushes.Blue, e.Bounds.X - 4, e.Bounds.Y - 4, e.Bounds.Width + 6, e.Bounds.Height + 6);
	}
}

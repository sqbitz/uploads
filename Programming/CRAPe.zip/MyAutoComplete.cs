﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using System.Data;

public class MyAutoComplete : Panel
{	
	public string CurrentValue {
		get {
			
			return dt.DefaultView[selectedIndex]["Name"].ToString() 
				+ ((ItemType)dt.DefaultView[selectedIndex]["ItemType"] == ItemType.Method ? "(" : "");
		}
	}
	public Type CurrentType {
		get {			
			return (Type)dt.DefaultView[selectedIndex]["Type"];
		}

	}
	
	private int selectedIndex;
	public int SelectedIndex {
		get
		{
			return selectedIndex;
		}
		set
		{
			try
			{
				if(value < 0)
					value = dgv.Rows.Count - 1;
				if(value >= dgv.Rows.Count)
					value = 0;
	
				dgv.Rows[selectedIndex].Selected = false;
	
				selectedIndex = value;	
							
				dgv.Rows[selectedIndex].Selected = true;

				//Scrolls to selected row
				dgv.CurrentCell = dgv.Rows[selectedIndex].Cells[0];
			}
			catch(Exception e)
			{
				selectedIndex = 0;
				return;
			}
		}
	}

	public KeyEventHandler MyKeyPress;
	public EventHandler ItemSelected;

	private DataGridView dgv;
	private DataTable dt;
	
	public MyAutoComplete()
	{
		Width = 400;
		Height = 140;
		this.BringToFront();
		this.Hide();
		BackColor = Color.DarkRed;
		ForeColor = Color.White;
		Padding = new Padding(2);
				
		Font = new Font(FontFamily.GenericSansSerif, 8);

		dt = new DataTable();
		dt.Columns.Add(new DataColumn("Name"));
		dt.Columns.Add(new DataColumn("Type", typeof(Type)));
		dt.Columns.Add(new DataColumn("ItemType", typeof(ItemType)));
		dt.Columns.Add(new DataColumn("Icon", typeof(Image)));
		dt.Columns.Add(new DataColumn("Overrides", typeof(int)));
		dt.DefaultView.Sort = "Name";

		dgv = new DataGridView(){
			Dock = DockStyle.Fill,
			DataSource = dt.DefaultView,
			AutoSize = true,
			ColumnHeadersVisible = false,
			RowHeadersVisible = false,
			BorderStyle = BorderStyle.None,
			CellBorderStyle = DataGridViewCellBorderStyle.None,
			GridColor = Color.FromArgb(47, 47, 51),
			BackColor = Color.FromArgb(47, 47, 51),
			BackgroundColor = Color.FromArgb(47, 47, 51),
			EditMode = DataGridViewEditMode.EditProgrammatically,
			ForeColor = Color.White,
			SelectionMode = DataGridViewSelectionMode.FullRowSelect,
			AutoGenerateColumns = false,
			AllowUserToAddRows = false,
			AllowUserToDeleteRows = false,
			AllowUserToOrderColumns = false,
			AllowUserToResizeColumns = false,
			AllowUserToResizeRows = false,
			ShowCellErrors = false,
			ShowEditingIcon = false,
		};
		
		dgv.AdvancedCellBorderStyle.All = DataGridViewAdvancedCellBorderStyle.None;
		dgv.RowsDefaultCellStyle = new DataGridViewCellStyle{
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = Color.White
		};
					
		dgv.Columns.Add(new DataGridViewImageColumn() { 
			DataPropertyName = "Icon",
			Width = 25		
		});
		dgv.Columns.Add(new DataGridViewColumn() { 
			DataPropertyName = "Name",
			CellTemplate = new DataGridViewTextBoxCell(),
			MinimumWidth = 180,
			AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
		});
		dgv.Columns.Add(new DataGridViewColumn() { 
			DataPropertyName = "Type",
			CellTemplate = new DataGridViewTextBoxCell(),
			AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
			DividerWidth = 0
		});

		this.Controls.Add(dgv);	
		dgv.KeyUp += keyPressHandler;
		
		//BorderStyle = BorderStyle.FixedSingle;		
	}

	public void Open()
	{
		SelectedIndex = 0;
		dt.DefaultView.RowFilter = null;
		BringToFront();
		dgv.Refresh();
		dgv.Update();
		
		if(dt.DefaultView.Count == 0)
			return;

		this.Show();
	}

	public void AddItem(string name, Type t, ItemType itemType)
	{
		if(string.IsNullOrEmpty(name))
			return;

		if(itemType == ItemType.Method)
		{
			var rows = dt.Select("[Name] = '" + name + "'");
			if(rows != null && rows.Length > 0)
			{			
				//rows[0]["Overrides"] = (int)rows[0]["Overrides"] + 1;
				//dt.AcceptChanges();
				return;
			}
		}
		else
		{
			var rows = dt.Select("[Name] = '" + name + "'");
			if(rows != null && rows.Length > 0)
				return;
		}

		var img = Images.Class;
		if(itemType == ItemType.Property)
			img = Images.Property;
		else if(itemType == ItemType.Method)
			img = Images.Method;
		else if(itemType == ItemType.Enum)
			img = Images.Enum;
		else if(itemType == ItemType.Event)
			img = Images.Event;
		else if(itemType == ItemType.Variable)
			img = Images.Variable;
			
		dt.Rows.Add(name, t, itemType, img, 0);
	}

	public void Clear()
	{
		try
		{
			dt.DefaultView.RowFilter = null;
			dt.Rows.Clear();
		}
		catch(Exception c)
		{
			Console.WriteLine(c);
		}
	}

	public void Down()
	{
		try
		{
			SelectedIndex++;
		}
		catch(Exception){	}
	}
	public void Up()
	{
		try
		{
			SelectedIndex--;
		}
		catch(Exception){}
	}
	public void Goto(string filter)
	{
		try
		{
			dt.DefaultView.RowFilter = "[Name] LIKE '" + filter + "%'";
			//Console.WriteLine("RowFilter: " + dt.DefaultView.RowFilter);
			
			if(dt.DefaultView.Count == 0)
				dt.DefaultView.RowFilter = null;
				
			//var firstMatchIndex = items.FindIndex(x => x.Name.StartsWith(filter));
			//Console.WriteLine("AC Match = " + firstMatchIndex);
			//SelectedIndex = firstMatchIndex;
		}
		catch(Exception) {	 }
	}


	private void keyPressHandler(object o, KeyEventArgs args)
	{			
		bool isArrow = (args.KeyData == Keys.Up || args.KeyData == Keys.Down || args.KeyData == Keys.Left || args.KeyData == Keys.Right);
						
		if(Visible)
		{
			if(args.KeyData == Keys.Return)
			{
				//Console.WriteLine("Replace with " + SelectedItem);
				ItemSelected(this, new EventArgs());
				Hide();
				
			}
			if(args.KeyData == Keys.Escape)
				Hide();
		}		
	}

	public enum ItemType { Enum, Property, Method, Class, Event, Variable };	
	public class Item
	{
		public Item(string name, Type t, ItemType it)
		{
			Name = name;
			Type = t;
			ItemType = it;
		}
		public string Name;
		public Type Type;
		public ItemType ItemType;
	}
}

﻿using System;
using System.Linq;

public class TestInDir
{
	public TestInDir()
	{
	}
}

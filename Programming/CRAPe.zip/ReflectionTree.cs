﻿using System;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Drawing;
using System.Collections.Generic;

public class ReflectionTreeTab : TabPage
{
	public ReflectionTreeTab(ReflectionTree rt) : base("Class Reference       ")
	{
		BackColor = Color.FromArgb(47, 47, 51);
		ForeColor = Color.White;
		
		Padding = new Padding(0);
		
		Dock = DockStyle.Fill;
		BorderStyle = BorderStyle.None;
		this.Controls.Add(rt);
	}
}

public class ReflectionTree : Panel
{
	private TextBox txtSearch;
	private Button btnSearch;
	private SplitContainer splitter;
	private TreeView tree;
	private ListBox lbResults;
	private StatusBarPanel sbpLocation;
			
	private List<TreeNode> foundNodes;
	
	public EventHandler LoadStart;
	public EventHandler LoadProgress;
	public EventHandler Loaded;

	public int namespaceNodes = 0;	

	public ReflectionTree(StatusBarPanel locationPanel)
	{		
		BackColor = Color.FromArgb(47, 47, 51);
		ForeColor = Color.White;
		
		Padding = new Padding(0);
		
		Dock = DockStyle.Fill;
		BorderStyle = BorderStyle.None;
		
		var layout = new TableLayoutPanel() {
			Dock = DockStyle.Fill
		};
		layout.RowStyles.Add(new RowStyle {
			SizeType = SizeType.Absolute,
			Height = 40
		});
		layout.RowStyles.Add(new RowStyle{ 
			SizeType = SizeType.Percent, 
			Height = 60 
		});

		var layoutSearch = new FlowLayoutPanel(){
			Dock = DockStyle.Fill,
			Height = 30
		};
				
		txtSearch = new TextBox();
		layoutSearch.Controls.Add(txtSearch);

		btnSearch = new Button() {
			Text = "Search"
		};
		btnSearch.Click += btnSearchClickHandler;
		layoutSearch.Controls.Add(btnSearch);
		
		layout.Controls.Add(layoutSearch, 0 , 0);

		splitter = new SplitContainer() {
			Dock = DockStyle.Fill,
			Orientation = Orientation.Horizontal,
			Padding = new Padding(0),
			Margin = new Padding(0)
		};
		splitter.Panel1.Margin = new Padding(0);
		splitter.Panel2.Margin = new Padding(0);
		splitter.Panel1.Padding = new Padding(0);
		splitter.Panel2.Padding = new Padding(0);

		layout.Controls.Add(splitter, 0, 1);

		tree = new TreeView() {
			Dock = DockStyle.Fill,
			ShowNodeToolTips = true,
			LineColor = Color.Red,
			//ImageList = new ImageList(),
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = Color.White,
			Margin = new Padding(0),
			BorderStyle = BorderStyle.None,
			Font = new Font(this.Font.FontFamily, 9)
		};
		tree.AfterSelect += treeAfterSelectHandler;
		
		//tree.ImageList.Images.Add(Images.Folder);
		//tree.ImageList.Images.Add(Images.Property);
		//tree.ImageList.Images.Add(Images.Class);
		//tree.ImageList.Images.Add(Images.Enum);
		//tree.ImageList.Images.Add(Images.Method);
		
		splitter.Panel1.Controls.Add(tree);
		
		lbResults = new ListBox() {
			Dock = DockStyle.Fill,
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = Color.White,
			HorizontalScrollbar = true
		};
		lbResults.SelectedValueChanged += lbItemClickHandler;
		splitter.Panel2.Controls.Add(lbResults);
		splitter.Panel2Collapsed = true;
		
		this.Controls.Add(layout);
		
		sbpLocation = locationPanel;
		
		tree.Nodes.Add(new TreeNode("Loading...") { Name = "loading" });
		Task.Delay(1000).ContinueWith(new Action<Task>(StartBuild));				
	}
	
	private void StartBuild(Task t)
	{
		Console.Write(".");
		tree.BeginUpdate();
		Task.Run(() => Build()).ContinueWith(new Action<Task>(FinishBuild));		
	}
	private void FinishBuild(Task t)
	{
		tree.Nodes.RemoveByKey("loading");
		tree.Nodes[tree.Nodes.IndexOfKey("System")].Expand();
		tree.EndUpdate();
		Loaded(this, null);
	}
	
	private void Build() 
	{	
		var myType = this.GetType();
		
		var assem = myType.Assembly;
		try
		{
			var developmentDLLPath = "development.dll";
			var binPath = Path.Combine(Application.StartupPath, "bin");
			if(Directory.Exists(binPath))
				developmentDLLPath = Path.Combine(binPath, developmentDLLPath );		
		
			assem = Assembly.LoadFile(Path.Combine(Application.StartupPath, developmentDLLPath));
		}
		catch(Exception c)
		{
			//Console.WriteLine(c);
		}
		
		var namespaces = new Dictionary<string, HashSet<Type>>();
		
		var refAssemblies = assem.GetReferencedAssemblies().ToList();
		//Console.WriteLine("RefAssem: " + refAssemblies.Count());
		
		//Uncomment the following lines to add an assembly by hand to the tree
		//Useful for when you are trying to figure out how to instantiate a type first
		//refAssemblies.Add(new AssemblyName(Assembly.Load("Microsoft.JScript").FullName));
		
		
		foreach(var assName in refAssemblies
			.Where(x => !x.Name.Contains("IDE"))
			.OrderBy(x => x.Name))
		{
			//Console.WriteLine("RefAss: " + assName);
			try
			{
				var ass = Assembly.Load(assName);
			
				var types = ass.GetTypes();
				foreach(var t in types
					.Where(x => !string.IsNullOrEmpty(x.Namespace) && x.IsPublic))
				{
					if(!namespaces.ContainsKey(t.Namespace))
						namespaces[t.Namespace] = new HashSet<Type>();
					
					namespaces[t.Namespace].Add(t);
				}			
			}
			//Some assemblies may not load if the files aren't in the directory like Newtonsoft and SQLite
			catch(Exception){}
		}
		Console.Write(".");
		LoadStart(namespaces.Count(), new EventArgs());
		
		foreach(var ns in namespaces.OrderBy(x => x.Key))
		{
			var nsName = ns.Key.Substring(ns.Key.LastIndexOf(".") + 1);
			var nsNode = new TreeNode(nsName, new[] { new TreeNode("Types") { Name = "Types", NodeFont = new Font(tree.Font, FontStyle.Italic) } }) 
			{ 
				Name = ns.Key,
			};
			nsNode.Nodes[0].Expand();
			
			//Console.WriteLine(ns.Key);
			
			foreach(var t in ns.Value.OrderBy(x => x.Name.Replace(ns.Key, "").TrimStart('.')))
				nsNode.Nodes[0].Nodes.Add(buildType(t));
			
			tree.BeginInvoke(new Action<TreeNode, string>(addNamespaceNode), new object[] { nsNode, ns.Key });
		}
	}
	
	private void addNamespaceNode(TreeNode node, string ns)
	{
		namespaceNodes++;
		LoadProgress(namespaceNodes, null);
		
		var nsParent = ns.Substring(0, ns.LastIndexOf(".") < 0 ? ns.Length : ns.LastIndexOf("."));
			
		var parentNode = tree.Nodes.Find(nsParent, true);
	
		if(parentNode.Length == 0)
		{
			node.Text = ns;
			tree.Nodes.Add(node);

		}
		else
			parentNode[0].Nodes.Insert(parentNode[0].Nodes.IndexOfKey("Types") - 1, node);
	}
	
	private TreeNode buildInheritance(Type t)
	{
		var tn = new TreeNode(t.ToString());
		tn.Expand();
		if(t.BaseType == null)
			return tn;
			
		tn.Nodes.Add(buildInheritance(t.BaseType));
		return tn;
	}
	
	private TreeNode buildType(Type t)
	{
		var tName = t.ToString().Replace(t.Namespace, "").TrimStart('.');
		if(tName.IndexOf("+") > 0)
			tName = tName.Substring(tName.IndexOf("+") + 1);
			
		var tNode = new TreeNode(tName) {
			Name = t.ToString(),
			ContextMenu = new ContextMenu(new[] {
				new MenuItem("Find References", findReferences) { Tag = t },
			})
		};
					
		if(t.IsEnum)
		{
			foreach(var e in t.GetEnumNames().OrderBy(x => x))
				tNode.Nodes.Add(new TreeNode(e));
			
			return tNode;
		}
	
		if(t.BaseType != null)
		{
			var inheritance = new TreeNode("Inherits");
			inheritance.Nodes.Add(buildInheritance(t.BaseType));
			tNode.Nodes.Add(inheritance);
		}
	
		var constructorsNode = new TreeNode("Constructors");
		foreach(var tc in t.GetConstructors().OrderBy(x => x.Name))
		{
			var cNode = new TreeNode(tc.Name) { Tag = tc };
			foreach(var tcm in tc.GetParameters())
				cNode.Nodes.Add(new TreeNode(tcm.Name + " " + tcm.ParameterType.ToString()){ Tag = tcm });

			constructorsNode.Nodes.Add(cNode);

		}
		if(constructorsNode .Nodes.Count > 0)
			tNode.Nodes.Add(constructorsNode);
	
		var nestedTypesNode = new TreeNode("Nested Types");
		foreach(var nt in t.GetNestedTypes().OrderBy(x => x.Name))
			nestedTypesNode.Nodes.Add(buildType(nt));		
		if(nestedTypesNode.Nodes.Count > 0)
			tNode.Nodes.Add(nestedTypesNode);
	
		var methodNode = new TreeNode("Methods");
		foreach(var m in t.GetMethods(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)
					.Where(x => !x.Name.StartsWith("add_")
						&& !x.Name.StartsWith("set_")
						&& !x.Name.StartsWith("get_")
						&& !x.Name.StartsWith("remove_"))
					.OrderBy(x => x.Name))
		{
			var mNode = new TreeNode(m.Name + " " + m.ReturnType) { 
				Tag = m
			};
			if(m.ReturnType != typeof(void) && m.ReturnType != typeof(object))
				mNode.ContextMenu = new ContextMenu(new[] {
					new MenuItem("Goto " + m.ReturnType, gotoType) { Tag = m.ReturnType }
				});
			
			var sb = new StringBuilder();
			if(m.IsStatic)
			{
				mNode.ForeColor = Color.CornflowerBlue;
				sb.Append("Static ");
			}
			
			if(m.IsFamily)
			{
				mNode.ForeColor = Color.Aqua;
				sb.Append("Protected ");
			}
			else if(!m.IsPublic)
			{
				//Exclude private (apparently) methods for the time being
				continue;
				//mNode.ForeColor = Color.DarkOrange;
				//sb.Append("Not Public ");
			}
			
			mNode.ToolTipText = sb.ToString().Trim();
	
			foreach(var tpm in m.GetParameters())
			{
				var ntpm = new TreeNode(tpm.Name + " " + tpm.ParameterType.ToString()) { 
					Tag = tpm
				};
				if(tpm.ParameterType != typeof(void) && tpm.ParameterType != typeof(object))
					ntpm.ContextMenu = new ContextMenu(new[] {
						new MenuItem("Goto " + tpm.ParameterType, gotoType) { Tag = tpm.ParameterType}
					});
					
				mNode.Nodes.Add(ntpm);
			}
	
			methodNode.Nodes.Add(mNode);
		}
		if(methodNode.Nodes.Count > 0)
			tNode.Nodes.Add(methodNode);
	
		var propertyNode = new TreeNode("Properties");
		foreach(var tp in t.GetProperties(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic).OrderBy(x => x.Name))
		{
			var n = new TreeNode(tp.Name + " " + tp.PropertyType.ToString()){ 
				Tag = tp
			};
			if(tp.PropertyType != typeof(object))
				n.ContextMenu = new ContextMenu(new[] {
					new MenuItem("Goto " + tp.PropertyType, gotoType) { Tag = tp.PropertyType }
				});
				
			if(tp.CanWrite == false)
			{
				n.ForeColor = Color.DarkGoldenrod;
				n.ToolTipText = "Read Only";
			}
			
			propertyNode.Nodes.Add(n);
		}
		
		foreach(var tf in t.GetFields(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)
			.OrderBy(x => x.Name))
		{
			var n = new TreeNode(tf.Name + " " + tf.FieldType.ToString()){ Tag = tf };
			if(tf.FieldType != typeof(object))
				n.ContextMenu = new ContextMenu(new[] {
					new MenuItem("Goto " + tf.FieldType, gotoType) { Tag = tf.FieldType }
				});

			
			n.ForeColor = Color.LimeGreen;
			
			var sb = new StringBuilder("Field - ");
			if(tf.IsStatic)
			{
				n.ForeColor = Color.CornflowerBlue;
				sb.Append("Static ");
			}
			
			if(tf.IsFamily || tf.IsFamilyOrAssembly)
			{
				n.ForeColor = Color.Aqua;
				sb.Append("Protected ");
			}
			else if(!tf.IsPublic)
			{
				//Exclude private (apparently) fields for the time being
				continue;
				//n.ForeColor = Color.DarkOrange;
				//sb.Append("Not Public ");
			}
			
			n.ToolTipText = sb.ToString().Trim();
	
			propertyNode.Nodes.Add(n);
		}
		if(propertyNode.Nodes.Count > 0)
			tNode.Nodes.Add(propertyNode);
	
		var eventsNode = new TreeNode("Events");
		foreach(var te in t.GetEvents(BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic).OrderBy(x => x.Name))
		{
			var n = new TreeNode(te.Name + " " + te.EventHandlerType.ToString()){ Tag = te };
			eventsNode.Nodes.Add(n);
		}
		if(eventsNode.Nodes.Count > 0)
			tNode.Nodes.Add(eventsNode);
			
		return tNode;
	}	
	
	private void btnSearchClickHandler(object o, EventArgs e)
	{
		foundNodes = new List<TreeNode>();
		foreach(TreeNode n in tree.Nodes)
			foundNodes.AddRange(searchTree(n, txtSearch.Text));
		
		lbResults.Items.Clear();
		if(foundNodes.Any() == false)
		{
			splitter.Panel2Collapsed = true;
			return;
		}

		
		foreach(var i in foundNodes)
			lbResults.Items.Add(i.FullPath.Replace(@"\Types\", @"\"));
			
		splitter.Panel2Collapsed = false;
		splitter.SplitterDistance = 650;
		tree.SelectedNode = foundNodes.First();
		tree.SelectedNode.Expand();
		tree.Focus();
	}
	
	private void findReferences(object o, EventArgs e)
	{
		txtSearch.Text = ((MenuItem)o).Tag.ToString();
		btnSearchClickHandler(o, e);
	}
	
	public void GotoType(string type)
	{
		var nodes = tree.Nodes.Find(type, true);
		if(nodes.Length == 0)
		{
			lbResults.Items.Clear();
			splitter.Panel2Collapsed = true;
			return;
		}
		tree.SelectedNode = nodes[0];
		tree.SelectedNode.Expand();
		tree.Focus();
	}
	
	private void gotoType(object o, EventArgs e)
	{
		GotoType(((MenuItem)o).Tag.ToString());
	}
	
	private void lbItemClickHandler(object o, EventArgs e)
	{
		tree.SelectedNode = foundNodes[lbResults.SelectedIndex];
		
		tree.Focus();
	}
	
	private void treeAfterSelectHandler(object o, TreeViewEventArgs args)
	{
		sbpLocation.Text = tree.SelectedNode.FullPath.Replace(@"\Types\", ".").Replace(@"\", ".");
		//panelDetails.Text = tree.SelectedNode.Tag == null ? "plark" : tree.SelectedNode.Tag.ToString();
	}
	
	private List<TreeNode> searchTree(TreeNode node, string value)
	{
		var found = new List<TreeNode>();
		foreach(TreeNode n in node.Nodes)
		{
			if(n.Text.ToLower().Contains(value.ToLower()))
				found.Add(n);
				
			found.AddRange(searchTree(n, value));
		}

		return found;
	}
}

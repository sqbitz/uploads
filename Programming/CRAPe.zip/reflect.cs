using System;
using System.Linq;
using System.Reflection;

public static class My
{
	public static void Reflect(object o)
	{
		var t = o.GetType();
		Reflect(t);
	}
	public static void Reflect(Type t)
	{
		Console.WriteLine(t);
		Console.WriteLine("---" + t.BaseType);

		if(t.IsEnum)
		{
			Console.WriteLine("---------------------ENUM VALUES-----------------");	
			foreach(var e in t.GetEnumNames())
			{
				Console.WriteLine("\t" + e);
			}
		}

		Console.WriteLine("---------------------CONSTUCTORS-----------------");	
		foreach(var tm in t.GetConstructors().Where(x => x.IsPrivate == false).OrderBy(x => x.Name))
		{
			Console.WriteLine("\t" + tm.Name);
			foreach(var tpm in tm.GetParameters())
			{
				Console.WriteLine("\t    ├" + tpm.Name.PadRight(20) + "\t\t" + tpm.ParameterType);
			}
		}
		Console.ReadLine();


		Console.WriteLine("---------------------EVENTS----------------------");	
		foreach(var tm in t.GetEvents().OrderBy(x => x.Name))
		{
			Console.WriteLine("\t" + tm.Name.PadRight(30) + "\t\t" + tm.EventHandlerType);
		}
		Console.ReadLine();


		Console.WriteLine("---------------------METHODS--------------------");	
		foreach(var tm in t.GetMethods()
			.Where(x => x.IsPrivate == false)
			.Where(x => !x.Name.StartsWith("add_")
					&& !x.Name.StartsWith("set_")
					&& !x.Name.StartsWith("get_")
					&& !x.Name.StartsWith("remove_"))
			.OrderBy(x => x.Name))
		{
			Console.WriteLine("\t" + tm.Name.PadRight(30) + "\t\t" + tm.ReturnType);
			foreach(var tpm in tm.GetParameters())
			{
				Console.WriteLine("\t    ├" + tpm.Name.PadRight(20) + "\t\t" + tpm.ParameterType);
			}
			
		}
		Console.ReadLine();

			
		Console.WriteLine("---------------------PROPERTIES------------------");		
		foreach(var tp in t.GetProperties().OrderBy(x => x.Name))
		{
			Console.WriteLine("\t" + tp.Name.PadRight(30) + "\t\t" + tp.PropertyType);
		}
		Console.ReadLine();
	}

}


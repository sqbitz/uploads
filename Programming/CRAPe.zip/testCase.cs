﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.Script.Serialization;


public class myTest
{
	private string plark;
	public double b;
	public myTest() //AnotherTest
	{		
		Regex regexLines = new Regex(".*", RegexOptions.Compiled);
		
		var serializer = new JavaScriptSerializer();
		//var result = serializer.Serialize(ab);
		
		Console.WriteLine("".PadRight(Console.WindowWidth - 10, '-'));
		
		var compiler = new Microsoft.CSharp.CSharpCodeProvider();
		//var compParam = new System.CodeDom.Compiler.CompilerParameters(usingLibraries.ToHashSet().ToArray(), "development.dll" , true){
		//GenerateInMemory = true
		//};
		var compParam = new System.CodeDom.Compiler.CompilerParameters(new string[0], "development.dll" , true){
			GenerateInMemory = true
		};
		//var results = compiler.CompileAssemblyFromFile(compParam, filesToLoad.ToArray());
		
		var a = Console.ReadLine();
		a.Clone();
		a.ToString();
		
		int i = 0;
		switch(i)
		{
			case 1:
				Console.WriteLine("i is 1");
				break;
			case 2:
			case 3:
				Console.WriteLine("i is 2 or 3");
				break;
			default:
				Console.WriteLine("i is " + i);
				break;
		}
	}	
}

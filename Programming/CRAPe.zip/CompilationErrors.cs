﻿using System;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Text;
using System.IO;
using System.Drawing;
using System.Collections.Generic;
using System.Diagnostics;

	
public class CompilationErrors : TabPage
{
	private ListBox lb;
	private List<Item> items;
	public CompilationErrors() : base("Compilation        ") 
	{
		Dock = DockStyle.Fill;
		BackColor = Color.FromArgb(47, 47, 51);
		AutoScroll = true;
		lb = new ListBox() {
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = Color.WhiteSmoke,
			Dock = DockStyle.Fill,
			BorderStyle = BorderStyle.None,
			HorizontalScrollbar = true,
			ScrollAlwaysVisible = true
		};
		lb.MouseDoubleClick += doubleClickHandler;
		items = new List<Item>();
		
		Font = new Font("Consolas", 11);
		
		Controls.Add(lb);
	}
	
	public EventHandler ErrorSelected;
		
	public void Clear()
	{
		lb.Items.Clear();
		items.Clear();
		Text = "Compilation        ";
	}
	
	public int ErrorCount { get { return lb.Items.Count; }}
	
	public IEnumerable<Item> GetFileErrors(string filename)
	{
		if(items == null)
			return new List<Item>();
			
		return items.Where(x => {
			if(x == null || x.Filename == null || filename == null)
				return false;
				
			return x.Filename == filename.Trim();
		}); 
	}
	
	public void Add(string filename, string startLine, string startColumn, string endLine, string endColumn, string error)
	{
		var i = new Item(filename, startLine, startColumn, endLine, endColumn, error);
		lb.Items.Add(i);
		items.Add(i);
		Text = "Compilation (" + lb.Items.Count + ")       ";
	}
	
	private void doubleClickHandler(object sender, MouseEventArgs e)
	{
		var index = lb.IndexFromPoint(e.Location);
		if(index < 0)
			return;
			
		var item = (Item)lb.SelectedItem;
		ErrorSelected(item, e);			
	}
	
	public class Item
	{
		public string Filename;
		
		public int StartLine;
		public int StartColumn;
		public int EndLine;
		public int EndColumn;
		
		public string Error;
		public Item(string file, string startLine, string startCol, string endLine, string endCol, string error)
		{
			Filename = file;
			StartLine = int.Parse(startLine);
			StartColumn = int.Parse(startCol);
			EndLine = int.Parse(endLine);
			EndColumn = int.Parse(endCol );
			Error = error;
		}
		public override string ToString() 
		{
			return Filename.PadRight(25) + "Line: " + StartLine.ToString().PadRight(7) + "Col: " + StartColumn.ToString().PadRight(10) + Error;
		}	
	}
}

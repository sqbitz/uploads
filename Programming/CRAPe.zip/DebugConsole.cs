﻿using System;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Text;
using System.IO;
using System.Drawing;
using System.Collections.Generic;
using System.Diagnostics;

	
public class DebugConsole : TabPage
{
	private TextBox tb;
	public DebugConsole() : base("Debug        ") {
		Dock = DockStyle.Fill;
		BackColor = Color.Black;
		ForeColor = Color.White;
		AutoScroll = true;
		Padding = new Padding(5);
		
		tb = new TextBox() { 
			Dock = DockStyle.Fill,
			BackColor = Color.Black,
			ForeColor = Color.White,
			ReadOnly = true,
			Multiline = true,
			WordWrap = false,
			BorderStyle = BorderStyle.None,
			ScrollBars = ScrollBars.Vertical,
			Font = new Font("Consolas", 11, FontStyle.Regular)
		};
		Controls.Add(tb);
		
		var writer = new Writer(tb);
		
		Console.SetOut(writer);
	}
	
	public void Clear()
	{
		tb.Clear();
	}
	
	private class Writer : StringWriter
	{
		private TextBox tb;
		public Writer(TextBox textBox)
		{
			tb = textBox;
		}
		public override void Write(string value)
		{		
			tb.AppendText(value);
		}
		public override void WriteLine(string value)
		{
			tb.AppendText(value);
			tb.AppendText("\n");
		}
		
		
	}
}

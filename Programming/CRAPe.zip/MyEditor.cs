﻿using System;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;

public class MyEditor : SelfDrawEditor
{
	private StringBuilder currentLine;
	
	private MyAutoComplete typesAutoComplete;
	private MyAutoComplete propsAutoComplete;
	private ListBox lbMethodInfo;
	
	private PictureBox pbScroll;

	private Regex regexFindVariables;
	
	public EventHandler GotoType;

	public EventHandler Saved; 
	
	public MyEditor(StatusBarPanel status, StatusBarPanel lineCount) : base(status, lineCount)
	{
		this.KeyDown += keyDownHandler;
		
		this.VScroll += scrollHandler;
		this.MouseDown += mouseDownHandler;
		
		currentLine = new StringBuilder();
			
		typesAutoComplete = new MyAutoComplete();
		this.Controls.Add(typesAutoComplete);

		propsAutoComplete = new MyAutoComplete();
		this.Controls.Add(propsAutoComplete);
		
		lbMethodInfo = new ListBox() {
			Font = (Font)propsAutoComplete.Font.Clone(),
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = Color.White,
			BorderStyle = BorderStyle.FixedSingle,
			AutoSize = true,
			Padding = new Padding(5)
		};
		
		this.Controls.Add(lbMethodInfo);

		regexFindVariables = new Regex(@"((private|public|protected)? ?(?<type>([\w\.\,<>])+) (?<varName>\w+);)|((\w+) (?<varName>\w+) ?= ?new (?<type>([\w\.\,<>])+)|((?<type>\w+) (?<varName>\w+) = (?<value>.*);))");
				
		tokenizer = new Tokenizer(typesAutoComplete, propsAutoComplete);
		tokenizer.TokenizeComplete += tokenizeCompleteHandler;
		tokenizer.CompileErrors += tokenizeCompileErrorsHandler;
		
		pbScroll = new PictureBox() {
			Width = 60,
			Top = 0,
		};
		//this.Controls.Add(pbScroll);
		this.Resize += (object o, EventArgs e) => {
			pbScroll.Left = this.Right - 80;
			pbScroll.Height = this.Height;
		};
		//Task.Run(() => drawVisualScroll());
	}
	
	public void SetZoom(int zoomValue)
	{
		zoom = zoomValue;
		calculateFont();
	}
	
	private new void calculateFont()
	{
		base.calculateFont();
		
		var popupFont = new Font("Consolas", 8 + zoom);
		lbMethodInfo.Font = popupFont;
		propsAutoComplete.Font = popupFont;
		typesAutoComplete.Font = popupFont;
		
		propsAutoComplete.Width = 400 + (zoom * 20);
		typesAutoComplete.Width = 400 + (zoom * 20);
		
		propsAutoComplete.Refresh();
		typesAutoComplete.Refresh();
		
		var currLineNum = GetLineFromCharIndex(SelectionStart);
		var firstCharIndex = GetFirstCharIndexFromLine(currLineNum);
		lblStatus.Text = "Ln " + (currLineNum + 1) + ", Col " + (SelectionStart - firstCharIndex + 1) + ", Char " + SelectionStart;
		if(zoom != 0)
			lblStatus.Text += "     Zoom " + zoom.ToString("n0");
			
		scrollHandler(null, null);
	}

	public void LoadFile(string fileName)
	{		
		tokenizer.Clear();
		
		using(var rdr = new System.IO.StreamReader(fileName))		
			Text = rdr.ReadToEnd().TrimEnd();
			
		if(string.IsNullOrWhiteSpace(Text))
			Text = "\n\n";
			
		calculateFont();
			
		SelectionStart = 0;
		ScrollToCaret();

		propsAutoComplete.Hide();
		typesAutoComplete.Hide();
		lbMethodInfo.Hide();
		
		lastOutlineRefresh = DateTime.MinValue;

		selectionChangedHandler(null, null);
		this.Focus();
		
		currFileName = fileName;
		
		//tokenizer.Tokenize(Text, fileName);
		this.Invalidate();
	}
	
	public new void SaveFile(string filename)
	{
		//base.SaveFile(filename);	
			
		using(var sw = new StreamWriter(filename, false, System.Text.Encoding.UTF8))
			foreach(var l in Lines)
				sw.WriteLine(l);
		
		Saved(this, null);
	} 
	
	private void mouseDownHandler(object o, MouseEventArgs a)
	{
		if(a.Button == MouseButtons.Right)
		{
			var cm = new ContextMenu();
			
			var charIndex = this.GetCharIndexFromPosition(a.Location);
			var tokens = tokenizer.GetLineTokens(charIndex);
			if(tokens == null)
				return;
			var token = tokens.LastOrDefault(x => (charIndex >= x.StartIndex && charIndex <= x.EndIndex));			
			if(token != null)
			{ 
				if(token.Type != typeof(object))
					cm.MenuItems.Add(new MenuItem("Goto " + token.Type, (object s, EventArgs e) => { GotoType(token.Type, e); }));
				
				if(tokenizer.Definitions.ContainsKey(token.Name))
				{
					var location = tokenizer.Definitions[token.Name];
					var currLine = this.GetLineFromCharIndex(charIndex);
					var locationLine = this.GetLineFromCharIndex(location.Item2);
					
					if(currLine != locationLine)
						cm.MenuItems.Add(new MenuItem("Goto Definition", (object s, EventArgs e) => {
							if(currFileName != location.Item1)
								LoadFile(location.Item1);

							SelectionStart = location.Item2; 
						}));
				}
			}
				
			if(cm.MenuItems.Count > 0)
				cm.Show(this, a.Location);
		}
	}
		
	private void keyDownHandler(object o, KeyEventArgs args)
	{
		//When debugging console apps a "KeyUp" event occurs with <return> but no accompanying "KeyDown"
		//Do this to prevent the editor from handling the "KeyUp"
		//keyDownReturn = false;
		//if(args.KeyData == Keys.Return)
		//	keyDownReturn = true;
		
		if(args.KeyData == Keys.Escape || args.KeyData == Keys.Back || args.KeyData == (Keys.Back | Keys.Control))
		{
			typesAutoComplete.Hide();
			propsAutoComplete.Hide();
			lbMethodInfo.Hide();
			return;
		}
				
		if((typesAutoComplete.Visible || propsAutoComplete.Visible) 
			&& (
				args.KeyData == (Keys.D9 | Keys.Shift) 
				|| args.KeyData == (Keys.D0 | Keys.Shift) 
				|| args.KeyData == Keys.OemPeriod
				|| args.KeyData == Keys.Oemcomma
				|| args.KeyData == Keys.OemSemicolon)
			)
		{
			typesAutoComplete.Hide();
			propsAutoComplete.Hide();
		}
		
		if(lbMethodInfo.Visible 
			&& (
				args.KeyData == (Keys.D0 | Keys.Shift)
				|| args.KeyData == Keys.OemSemicolon
			))
			lbMethodInfo.Hide();
		
		string typedChar = ((char)args.KeyValue).ToString().ToLower();
		if(args.KeyData == Keys.OemPeriod)
			typedChar = ".";

		var typedIsLetterDigitPeriod = char.IsLetterOrDigit((char)args.KeyValue) || args.KeyData == Keys.OemPeriod;

		//This was having problems but appears to be working correctly now.
		var currLineNum = GetLineFromCharIndex(SelectionStart);
		if(currLineNum < 0 || this.Lines.Length == 0 ||  currLineNum >= this.Lines.Length)
			return;
		var c = this.Lines[currLineNum];
		//Console.WriteLine(currLineNum + " " + c.PadRight(100));

		var tokens = c.Trim().TrimEnd(new[] {')', '}', ';' }).Split(new[] { ' ', '(', '=', '{' });
		if(tokens.Length == 0)
		{
			Console.WriteLine("No Tokens");
			return;
		}

		bool isArrow = (args.KeyData == Keys.Up || args.KeyData == Keys.Down || args.KeyData == Keys.Left || args.KeyData == Keys.Right);

		if(typesAutoComplete.Visible)
		{						
			if(args.KeyData == Keys.Up)
			{
				typesAutoComplete.Up();
				args.SuppressKeyPress = true;							
				return;
			}
			else if(args.KeyData == Keys.Down)
			{
				typesAutoComplete.Down();
				args.SuppressKeyPress = true;
				return;
			}
			else if(args.KeyData == Keys.Return || args.KeyData == Keys.Tab)
			{
				var typedValue = tokens[tokens.Length - 1].Trim();
				var selectedValue = typesAutoComplete.CurrentValue;
				
				var type = typesAutoComplete.CurrentType;
				
				SelectionStart = SelectionStart - typedValue.Length;
				SelectionLength = selectedValue.ToLower().StartsWith(typedValue.ToLower()) ? typedValue.Length : 0;
				
				//Console.WriteLine("Got return: " + selectedValue + " TV:" + typedValue + " SS:" + SelectionStart + "SL: " + SelectionLength + " Type:" + type);
				
				SelectedText = selectedValue;
				args.SuppressKeyPress = true;
				typesAutoComplete.Hide();
				
				showMethodInfo(type, selectedValue);

				return;
			}
			
			if(typedIsLetterDigitPeriod)
			{
				var indexOfNew = c.IndexOf(" new ");
				string typeName = tokens[tokens.Length - 1] + typedChar;
				if(indexOfNew >= 0)
					typeName = c.Substring(indexOfNew + 5).Trim().TrimEnd(';','(', ')') + typedChar;
					
				//Console.WriteLine("typeName: " + typeName);
				typesAutoComplete.Goto(typeName);
			}
		}	
		
		if(propsAutoComplete.Visible)
		{	
			var lineFirstChar = GetFirstCharIndexOfCurrentLine();
			
			//Find last period before current cursor position
			var cCursorIndex = SelectionStart - lineFirstChar;
			var periodIndex = c.Substring(0, cCursorIndex).LastIndexOf(".");
			
			if(args.KeyData == Keys.Up)
			{
				propsAutoComplete.Up();
				args.SuppressKeyPress = true;							
				return;
			}
			else if(args.KeyData == Keys.Down)
			{
				propsAutoComplete.Down();
				args.SuppressKeyPress = true;
				return;
			}
			else if(args.KeyData == Keys.Return || args.KeyData == Keys.Tab)
			{
				var typedValue = c.Substring(periodIndex + 1).TrimEnd(new[] { ')', '}', ']', ';' }).Split(new char[] { '.', '(', })[0];
				var selectedValue = propsAutoComplete.CurrentValue;
				
				showMethodInfo(selectedValue.TrimEnd(';','(', ')'));
				
				//Console.WriteLine("Got return: " + selectedValue + " " + typedValue + "  " + typedValue.Length + " cursorIndex" + cCursorIndex + " .Index" + periodIndex);

				SelectionStart = lineFirstChar + periodIndex + 1;
				//SelectionLength = selectedValue.ToLower().StartsWith(typedValue.ToLower()) ? typedValue.Length : 0;
				SelectionLength = typedValue.Length;
				SelectedText = selectedValue;			
				args.SuppressKeyPress = true;
				propsAutoComplete.Hide();

				return;
			}

			if(typedIsLetterDigitPeriod)
			{
				var typeName = c.Substring(periodIndex + 1).Trim().TrimEnd(';', '(', ')') + typedChar;
				//Console.WriteLine("period " + typeName);
				propsAutoComplete.Goto(typeName.Trim());
			}
		}
	
		lblLineCount.Text = "Lines: " + this.Lines.Length;
		var firstCharIndex = GetFirstCharIndexFromLine(currLineNum);
		lblStatus.Text = "Ln " + (currLineNum + 1) + ", Col " + (SelectionStart - firstCharIndex + 1) + ", Char " + SelectionStart;
		if(zoom != 0)
			lblStatus.Text += "     Zoom " + zoom.ToString("n0");
		
		//Any "non-typing" characters should reset us back to Moving
		if(isArrow || args.KeyData == Keys.Delete || args.KeyData == Keys.Back || args.KeyData == Keys.Home || args.KeyData == Keys.End)
			return;
			
		if(c.StartsWith("using "))
			return;				

		//Handle shifting text back and forth with Tab
		if(SelectionLength > 3 && (args.KeyData == Keys.Tab || args.KeyData == (Keys.Tab | Keys.Shift)))
		{
			var startLine = GetLineFromCharIndex(SelectionStart);
			var endLine = GetLineFromCharIndex(SelectionStart + SelectionLength);
			
			var lines = SelectedText.Split('\n');
			
			for(int j = 0; j < lines.Length; j++)
			{
				if(args.Shift && lines[j].StartsWith("\t"))
					lines[j] = lines[j].Substring(1).TrimEnd();
				else
					lines[j] = "\t" + lines[j].TrimEnd();
			}
			
			SelectedText = string.Join("\n", lines);
			SelectionStart = GetFirstCharIndexFromLine(startLine);
			SelectionLength = GetFirstCharIndexFromLine(endLine) - SelectionStart + Lines[endLine].Length - 1;
			
			args.SuppressKeyPress = true;
			return;			
		}
		
		//Delete the whole line when the users presses  Shift+Delete
		if(args.KeyData == (Keys.Delete | Keys.Shift))
		{
			var line = GetLineFromCharIndex(SelectionStart);
			var lineStartIndex = GetFirstCharIndexFromLine(line);
			var lineEndIndex = lineStartIndex + Lines[line].Length;
			SelectionStart = lineStartIndex;
			SelectionLength = lineEndIndex - lineStartIndex + 1;
			SelectedText = "";
		}

		//AutoComplete Stuff
		if (c.EndsWith(" new") && args.KeyData == Keys.Space)
		{				
			var point = GetPositionFromCharIndex(SelectionStart);
			point.Y += (int)fontSize.Height;
			typesAutoComplete.Top = point.Y;
			typesAutoComplete.Left = point.X + (int)fontSize.Width;
			
			if(typesAutoComplete.Visible == false)			
				typesAutoComplete.Open();		
		}
		else if(args.KeyData == Keys.OemPeriod && typesAutoComplete.Visible == false)
		{
			var point = GetPositionFromCharIndex(SelectionStart);
			point.Y += (int)fontSize.Height;
			propsAutoComplete.Top = point.Y;
			propsAutoComplete.Left = point.X + (int)fontSize.Width;
			
			var name = tokens[tokens.Length - 1].TrimEnd('.').Trim();
						
			tokenizer.ShowACProps(SelectionStart, name);						
		}
		//Handle when user presses "("
		else if(args.KeyData == (Keys.D9 | Keys.Shift))
			showMethodInfo();
		else if(args.KeyData == (Keys.Control | Keys.Space))
		{			
			var point = GetPositionFromCharIndex(SelectionStart);
			point.Y += (int)fontSize.Height;
			typesAutoComplete.Top = point.Y;
			typesAutoComplete.Left = point.X;
			
			if(typesAutoComplete.Visible == false)
			{
				typesAutoComplete.Open();
				var typeName = tokens[tokens.Length - 1].Trim();
				//Console.WriteLine("typeName: " + typeName);
				typesAutoComplete.Goto(typeName);
			}			
			
			args.Handled = true;
			args.SuppressKeyPress = true;
			return;
		}
		//User types the > of an HTML tag
		else if(args.KeyData == (Keys.Shift | Keys.OemPeriod) && currFileName.Trim().EndsWith(".html"))
		{
			try
			{
				var matches = Tokenizer.regexHTML.Matches(c + ">");
				if(matches.Count > 0)
				{
					var lastMatch = matches[matches.Count - 1];
					var tagName = lastMatch.Groups["tagName"].Value;
					var start = SelectionStart;
					SelectedText = "</" + tagName + ">";
					SelectionStart = start;
				}
			}
			catch(Exception){}
	
		}
		
		lblStatus.Text = "Ln " + (currLineNum + 1) + ", Col " + (SelectionStart - firstCharIndex + 1) + ", Char " + SelectionStart;
		if(zoom != 0)
			lblStatus.Text += "     Zoom " + zoom.ToString("n0");
	}
	
	private void showMethodInfo(string methodName = "")
	{	
		var lt = tokenizer.GetLineTokens(SelectionStart);
		if(lt == null)
			return;
		//Console.WriteLine("CharIndex: " + SelectionStart);
		//foreach(var t in lt)
		//	Console.WriteLine(t);
			
		var isConstructor = lt.Any(x => x.Name == "new");		

		var lastTypedToken = lt.LastOrDefault(x => (x.Type != null && x.Type != typeof(object)) && x.StartIndex <= SelectionStart);
		if(lastTypedToken == null)
			return;
			
		var lttIndex = lt.IndexOf(lastTypedToken);
		//Console.WriteLine("First: " + lastTypedToken + " " + lttIndex);
		if(lttIndex +1 >= lt.Count)
			return;
			
		var thisMethodToken = lt[lttIndex + 1];
		var token = thisMethodToken.Name.Split(new[] { ' ', '\t' })[0];

		//Console.WriteLine("Me: " + token + "|" + methodName + "|");

		showMethodInfo(lastTypedToken.Type, methodName, token);
	}
	
	private void showMethodInfo(Type t, string methodName, string methodTokenName = "")
	{
		//Console.WriteLine("{0:20} {1:20} {2:20}", t, methodName, methodTokenName);
	
		var point = GetPositionFromCharIndex(SelectionStart);
		point.Y += (int)fontSize.Height;
		lbMethodInfo.Top = point.Y;
		lbMethodInfo.Left = point.X;
		lbMethodInfo.Items.Clear();	
			
		var methods = t.GetMethods().Where(x => x.Name == methodTokenName || x.Name == methodName);
		foreach(var m in methods)
		{
			var sb = new StringBuilder(m.ReturnParameter.ToString());
			sb.Append(" ").Append(m.Name).Append("(");
			foreach(var p in m.GetParameters())
				sb.Append(p.ParameterType.ToString().Replace("System.", "")).Append(" ").Append(p.Name).Append(", ");
	
			lbMethodInfo.Items.Add(sb.ToString().TrimEnd(new[] {',', ' '}) + ")");
		}
		
		if(t.Name.EndsWith(methodName))
			foreach(var c in t.GetConstructors())
			{
				var sb = new StringBuilder(methodName).Append("(");
				foreach(var p in c.GetParameters())
					sb.Append(p.ParameterType.ToString().Replace("System.", "")).Append(" ").Append(p.Name).Append(", ");
	
				lbMethodInfo.Items.Add(sb.ToString().TrimEnd(new[] {',', ' '}) + ")");
	
			}
				
		if(lbMethodInfo.Items.Count == 0)
			return;
	
		lbMethodInfo.Show();
		lbMethodInfo.BringToFront();
	}

	private void scrollHandler(object o, EventArgs args)
	{
		var point = GetPositionFromCharIndex(SelectionStart);
		point.Y += (int)fontSize.Height;

		if(typesAutoComplete.Visible)
			typesAutoComplete.Top = point.Y;
		if(propsAutoComplete.Visible)				
			propsAutoComplete.Top = point.Y;
		if(lbMethodInfo.Visible)
			lbMethodInfo.Top = point.Y;
	}
	
	private void tokenizeCompleteHandler(object e, TokenizeCompleteEventArgs args)
	{	
		this.Invalidate(true);	
		if((DateTime.Now - lastOutlineRefresh).TotalSeconds <= 5)
			return;		
		try
		{
			this.BeginInvoke(new Action<OutlineNode>(buildOutlineTree), new object[] { args.Outline });
		}
		catch(Exception ex) { 
			Console.WriteLine("Error with Outline " + ex);
		}
	}
	
	private void tokenizeCompileErrorsHandler(object e, EventArgs args)
	{
		var errors = (IEnumerable<CompilationErrors.Item>)e;
		HighlightErrors(errors);
	}
	
	
	private void drawVisualScroll()
	{
		Console.WriteLine("VisualScroll");
		using(var bgc = new BufferedGraphicsContext())
		using(var bg = bgc.Allocate(pbScroll.CreateGraphics(), pbScroll.ClientRectangle))
		using(var g = bg.Graphics)
		{
			g.FillRectangle(new SolidBrush(Color.FromArgb(47, 47, 51)), pbScroll.ClientRectangle);
			g.DrawLine(Pens.DarkRed, 0, 5, 0, pbScroll.Bottom - 5);
			drawLines(0, Lines.Length - 1, g, true);
			bg.Render();
		}
	}
	
	public void HighlightErrors(IEnumerable<CompilationErrors.Item> errors)
	{
		try
		{
			//Console.WriteLine("Highlight Errors: " + currFileName + " " + errors.Count());
			compilationErrors = errors;
			Invalidate(true);
		}
		catch(Exception){}
	}

	private int bastardHash(IEnumerable<string> input)
	{
		var hash = 0;
		int lineCount = 0;
		foreach(var l in input)
		{
			for(int i = 0; i < l.Length; i++)
				hash += lineCount + (int)l[i] * i;
			lineCount++;		
		}

		return hash;
	}	

	/*  Diagnostic Stuff */
	public void Diag_ShowTypes()
	{
		Console.WriteLine("Printing Types\n-----------------------");
		foreach(var t in tokenizer.ReferencedTypes)
		{
			Console.WriteLine(t);
		}	
	}

	public void Diag_ShowVariables()
	{
		Console.WriteLine("Printing Variables\n-------------------------------");
		foreach(var v in tokenizer.Variables)
		{
			Console.WriteLine(v.Key.PadRight(40) + (v.Value.Type == null ? "null" : v.Value.Type.ToString()).PadRight(40) + v.Value.StartIndex);
		}
	}
	
	public void Diag_RunTokenize()
	{
		tokenizer.Tokenize(Text, Lines, currFileName, -1, "", false);
	}
}

public class MyEditorTab : TabPage
{
	public MyEditor Editor;
	public string Filename;
	
	private TreeNode tvCodeOutlineTopNode = null;
	private TreeView tvCodeOutline;
	
	public MyEditorTab(string filename, StatusBarPanel status, StatusBarPanel lineCount, TreeView tvCodeOutline, ReflectionTree rt)
	{
		this.Text = filename + "            ";
		this.Filename = filename;
		this.tvCodeOutline = tvCodeOutline;		
		//Padding = new Padding(10);
		BackColor = Color.FromArgb(47, 47, 51);
		
		Editor = new MyEditor(status, lineCount);
		Editor.LoadFile(filename);
		var editorHash = Editor.Text.GetHashCode();
		Editor.TextChanged += (object o, EventArgs e) => {
			if(this.Text.EndsWith("   *        ") == false && editorHash != Editor.Text.GetHashCode())
				this.Text = filename + "   *        ";
				
			editorHash = Editor.Text.GetHashCode();
		};
		Editor.Saved += (object o, EventArgs e) => {
			this.Text = filename + "            ";
		};
		
		Editor.GotoType = (object o, EventArgs e) => { rt.GotoType(o.ToString()); };
		Editor.BuildTree = (object o, EventArgs e) => {
		
			tvCodeOutlineTopNode = (TreeNode)o;
			if(Visible)
				RefreshOutlineTree();
		};
		this.Controls.Add(Editor);
	}
	
	public void RefreshOutlineTree()
	{
		tvCodeOutline.Nodes.Clear();
		if(tvCodeOutlineTopNode == null)
		{
			tvCodeOutline.Nodes.Add("Loading...");
			return;
		}
		
		tvCodeOutline.Nodes.Add(tvCodeOutlineTopNode);
		tvCodeOutline.ExpandAll();
	}
}

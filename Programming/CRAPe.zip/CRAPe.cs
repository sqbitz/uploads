﻿using System;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Text;
using System.IO;
using System.Drawing;
using System.Diagnostics;

[assembly: AssemblyVersion("1.8.9")]
[assembly: AssemblyFileVersion("1.8.9")]

public class CRAPe
{
	[STAThread]
	public static void Main()
	{
		try
		{
			bool tryUpdate = true;
			using(var rdr = new System.IO.StreamReader("config.txt"))
				while(!rdr.EndOfStream)
				{
					var line = rdr.ReadLine();
					var split = line.Split('=');
					
					if(split[0] == "isIDE" && split[1] == "true")
					{
						tryUpdate = false;
						break;
					}
				}
			
			string s = null;
				
			var tp = Process.GetCurrentProcess();
			string me = tp.MainModule.FileName;
			
			var meVersion = FileVersionInfo.GetVersionInfo(me);
			var f = @"C:\Users\Character\Documents\Class Projects\Programming 101\Lesson1\CRAPe.exe";
			
			var bak = me + ".bak";
			try
			{
				if(File.Exists(bak))
					File.Delete(bak);
			}
			catch(Exception c) {}
			
			if(tryUpdate && File.Exists(f))
			{
				var updateVersion = FileVersionInfo.GetVersionInfo(f);
				var updateVersionInt = updateVersion.FileMajorPart * 10000 + updateVersion.FileMinorPart * 1000 + updateVersion.FileBuildPart;
				var myVersionInt = meVersion.FileMajorPart * 10000 + meVersion.FileMinorPart * 1000 + meVersion.FileBuildPart;
				
				if(updateVersionInt > myVersionInt)
				{
					MessageBox.Show("Updating\nC.R.A.P.e\nv" + meVersion.FileVersion + "\nto\nv" + updateVersion.FileVersion);

					try
					{
						File.Move(me, bak);
					}
					catch(Exception c){}
					
					File.Copy(f, me);
	
					var spawn = Process.Start(me);
					tp.CloseMainWindow();
					tp.Close();
					try
					{
						tp.Kill();
						Process.GetCurrentProcess().Kill();
					}
					catch{}
					finally
					{
						tp.Dispose();
					}
					return;
				}
			}
			
			//Load DLLs from bin directory if they exist
			var ad = System.Threading.Thread.GetDomain();
			ad.AssemblyResolve += (o,e) => {

				var dllName = new AssemblyName(e.Name).Name + ".dll";
				var testPath = Path.Combine(Application.StartupPath, "bin", dllName);
				if(!File.Exists(testPath))
					return null;
				
				var ass = Assembly.LoadFile(testPath);
				return ass;
			};
							
			Application.SetCompatibleTextRenderingDefault(true);
			Application.EnableVisualStyles();
			Application.Run(new ApplicationContext(new MyForm()));		
		}
		catch(Exception c)
		{
			var sb = new StringBuilder();
			sb.AppendLine(c.Message);
			sb.AppendLine(c.StackTrace);
			MessageBox.Show(sb.ToString(), "Error Loading C.R.A.P.e.", 
				MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly, false);
		}
	}
}

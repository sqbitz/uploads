﻿using System;
using System.Web.Http;

[RoutePrefix("games/minesweeper")]
public class MinesweeperController : ApiController
{
	[Route(""), HttpGet]
	public int[,] GenBoard()
	{	
		var rnd = new Random();
		var board = new int[10,10];
		for(var x = 0; x < 10; x++)
			for(var y = 0; y < 10; y++)
			{
				if(rnd.Next(2) == 1)
					board[x,y] = -1;
			}
				
		return board;
	}
}

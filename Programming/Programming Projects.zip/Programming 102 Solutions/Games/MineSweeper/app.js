﻿$(document).ready(function() {
	$.get("/games/minesweeper", function(data) {
		for(var x = 0; x < data.length; x++)
		{
			var row = $("<div class='row'></div>");
			 $("#game").append(row);
			for(var y = 0; y < data[x].length; y++)
			{
				row.append("<div class='col'><button type='button' class='btn btn-block btn-light'>X</button></div>");
			}
		}		
		
	});

});

﻿var dudeImg = 0;
var hadukenCount = 0;
$(document).ready(function() {	
	$(document).keydown(function(e) {
		var dude = $("#dude");
		dude.removeClass("img" + dudeImg);
		var dudeLeft = dude.css("left").replace("px", "") * 1;
		var dudeBottom = dude.css("bottom").replace("px", "") * 1;
		switch(e.keyCode)
		{
			case 39: //right
				dudeImg++;
				dude.css("left", (dudeLeft + 5) + "px");
				break;
			case 37: //left
				dudeImg++;
				dude.css("left", (dudeLeft - 5) + "px");
				break;
			case 40: //down
				dudeImg++;
				dude.css("bottom", (dudeBottom - 5) + "px");
				break;
			case 38: //up
				dudeImg++;
				dude.css("bottom", (dudeBottom + 5) + "px");
				break;
			case 32: //space
				var hadukenBottom = dudeBottom;
				var hadukenLeft = dudeLeft + 33;
				$("#wrap").append(`<div class='haduken haduken${hadukenCount} img0'>`);
				$(".haduken" + hadukenCount).css("bottom", hadukenBottom + "px");
				moveHaduken(hadukenCount, 0, hadukenLeft);
				hadukenCount++;
				break;
		}
		if(dudeImg > 2)
			dudeImg = 0;
		
		dude.addClass("img" + dudeImg);		
	});
});

function moveHaduken(count, img, left)
{
	var haduken = $(".haduken" + count);
	haduken.removeClass("img" + img);
	img++;
	if(img > 2)
		img = 0;
		
	left += 20;
	if(left + 170 > $(document).width())
	{
		haduken.fadeOut();
		return;
	}
	haduken.css("left", left + "px").addClass("img" + img);
	setTimeout(function() { moveHaduken(count, img, left); }, 100);
}

﻿var squaresHigh;
var squaresWide;

var intervalDrawTetra;
var intervalMoveTetra;

var score = 0;
var moveSpeed = 501;
var moveAmount = 1;

var l1Tetra = {
	rotations: [
		[[0,0],[0,1],[0,2],[1,0]],
		[[0,0],[0,1],[1,1],[2,1]],
		[[0,2],[1,0],[1,1],[1,2]],
		[[0,0],[1,0],[2,0],[2,1]]
	],
	name: "L1"
}

var l2Tetra = {
	rotations: [
		[[0,0],[0,1],[0,2],[1,2]],
		[[0,1],[1,1],[2,0],[2,1]],
		[[1,0],[2,0],[2,1],[2,2]],
		[[0,0],[0,1],[1,0],[2,0]]
	],
	name: "L2"
}
	
var tTetra = {
	rotations: [
		[[0,1],[1,0],[1,1],[1,2]],
		[[0,1],[1,1],[1,2],[2,1]],
		[[0,0],[0,1],[0,2],[1,1]],
		[[0,1],[1,0],[1,1],[2,1]]
	],
	name: "T"
};

var iTetra = {
	rotations: [
		[[0,0],[0,1],[0,2],[0,3]],
		[[0,0],[1,0],[2,0],[3,0]]
	],
	name: "I"
};

var z1Tetra = {
	rotations: [
		[[0,0],[0,1],[1,1],[1,2]],
		[[0,1],[1,0],[1,1],[2,0]],
	],
	name: "Z1"
};

var z2Tetra = {
	rotations: [
		[[0,1],[0,2],[1,0],[1,1]],
		[[0,0],[1,0],[1,1],[2,1]]
	],
	name: "Z2"
};
	
var blockTetra = {
	rotations: [
		[[0,0],[0,1],[1,0],[1,1]]
	],
	name: "Block"
}

var tetras = [ l1Tetra, l2Tetra, tTetra, iTetra, blockTetra, z1Tetra, z2Tetra ];
var tetraRotationIndex = 0;
var movingTetraRow = 0;
var movingTetraCol = squaresWide / 2 - 1;
var tetra;
var gridSize = 30;
var highscores = {};
			
$(document).ready(function() {	
	var height = $("#gridWrap").height();
	var width = $("#gridWrap").width();

	//delete localStorage["highScores"];
	if(localStorage["highScores"] == undefined)
		localStorage["highScores"] = JSON.stringify([
			{ score: 500, name: "Jack" },
			{ score: 0, name: "None" },
			{ score: 0, name: "None" },
			{ score: 0, name: "None" },
			{ score: 0, name: "None" },
			{ score: 0, name: "None" },
			{ score: 0, name: "None" },
			{ score: 0, name: "None" },
			{ score: 0, name: "None" },
			{ score: 0, name: "None" },
		]);
		
	highScores = JSON.parse(localStorage["highScores"]);
	for(var i = 0; i < highScores.length; i++)
		$("#highScores").append(`<tr><th>${i + 1}.</th><td>${highScores[i].score}</td><td>${highScores[i].name}</td></tr>`);
	
	var numSquares = (height / gridSize) * (width / gridSize);
	squaresWide = width / gridSize;
	squaresHigh = height / gridSize;
	
	for(var i = 0; i < numSquares; i++)
		$("#gridWrap").append("<div>");
	
	$(document).keydown(function(e) {
		switch(e.keyCode)
		{
			case 39: //right
				if(checkContact(0,1) == false)
					movingTetraCol++;
				break;
			case 37: //left
				if(checkContact(0,-1) == false)
					movingTetraCol--;
				break;
			case 40: //down
				movingTetraRow++;
				drawTetra();
				break;
			case 32: //space
			case 38: //up
				tetraRotationIndex++;
				if(tetraRotationIndex >= tetra.rotations.length)
					tetraRotationIndex = 0;
				break;					
		}
	});
	
	$("#btnSaveNewScore").click(function() {
		for(var i = 0; i < highScores.length; i++)
		{
			if(score >= highScores[i].score)
			{
				for(var n = highScores.length - 1; n > i; n--)
					highScores[n] = highScores[n - 1];
	
				highScores[i] = { score: score, name: $("#newScoreName").val() };
				break;
			}
		}
		localStorage["highScores"] = JSON.stringify(highScores);
		window.location = window.location;
	});
	
	startTetra();
});

function getSquare(row, col)
{
	var index = row * squaresWide + col;
	return $($("#gridWrap div")[index]);
}

function startTetra()
{
	tetra = tetras[Math.floor((Math.random() * 100) % tetras.length)];
	tetraRotationIndex = 0;
	movingTetraRow = 0;
	movingTetraCol = squaresWide / 2 - 1;
	var numFilled = 0;
	for(var col = 0; col < squaresWide; col++)
		numFilled += getSquare(0,col).hasClass("stopped");
	
	//Handle when the board is full
	if(numFilled > 0)
	{
		clearInterval(intervalDrawTetra);
		clearInterval(intervalMoveTetra);
		$("#btnClose").hide();
		$("#btnSaveNewScore").hide();
		$("#modalHighScore").hide();
		for(var i = 0; i < highScores.length; i++)
		{
			if(score >= highScores[i].score)
			{
				$("#btnSaveNewScore").show();
				$("#modalHighScore").show();
				break;
			}
		}
		$("#youLoose").modal();
		return;
	}
	drawTetra();
	intervalDrawTetra = setInterval(drawTetra, 10);
	
	intervalMoveTetra = setInterval(function() {
		movingTetraRow++;
	}, moveSpeed);
}

function drawTetra()
{
	var tetraRotation = tetra.rotations[tetraRotationIndex];
	if(checkContact(0,0) == true)
	{
		startNextTetra();
		return;
	}
	$(".moving").removeClass("moving tetra tetra" + tetra.name);
	for(var i = 0; i < tetraRotation.length; i++)
	{
		var p = tetraRotation[i];
		var row = p[0] + movingTetraRow;
		var col = p[1] + movingTetraCol;
		getSquare(row,col).addClass("moving tetra tetra" + tetra.name);
	}
}

function checkContact(rowsToAdd, colsToAdd)
{
	var tetraRotation = tetra.rotations[tetraRotationIndex];
	for(var i = 0; i < tetraRotation.length; i++)
	{
		var p = tetraRotation[i];
		var row = p[0] + movingTetraRow + rowsToAdd;
		var col = p[1] + movingTetraCol + colsToAdd;
		if(row == squaresHigh)
			return true;
		if(col == -1 || col == squaresWide)
			return true;
			
		var work = getSquare(row,col);
		if(work.hasClass("stopped"))
			return true;
	}
	
	return false;
}

function checkRowComplete()
{
	for(var row = 0; row < squaresHigh; row++)
	{
		var numFilled = 0;
		for(var col = 0; col < squaresWide; col++)
			if(getSquare(row,col).hasClass("stopped"))
				numFilled++;
				
		if(numFilled == squaresWide)
		{
			for(var col = 0; col < squaresWide; col++)
			{
				getSquare(row,col).removeClass("stopped").slideDown(1000, function() { 
					$(this).remove(); 
					$("#gridWrap").prepend("<div>");
				});
			}
			
			score += squaresWide;
			$("#lblScore").text(score);
			moveSpeed -= 15;
			if(moveSpeed < 50)
				moveSpeed = 50;
		}
		
		
	}
}

function startNextTetra()
{
	clearInterval(intervalDrawTetra);
	clearInterval(intervalMoveTetra);
	$(".moving").removeClass("moving").addClass("stopped");
	checkRowComplete();
	startTetra();
}

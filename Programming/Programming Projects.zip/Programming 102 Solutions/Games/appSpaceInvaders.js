﻿var squaresHigh;

var grid = [];
var invadersLeft = 0;
var invaders = [];
var numInvadersWide = 10;
var numInvadersTall = 5;
var invaderTopIndex = 0;
var invaderLeftIndex = 5;
var invaderDirection = 1;	
	
$(document).ready(function() {	
	var height = $("#gridWrap").height();
	var width = $("#gridWrap").width();
	
	var gridSize = 20;
	
	var numSquares = (height / gridSize) * (width / gridSize);
	var squaresWide = width / gridSize;
	squaresHigh = height / gridSize;
	
	for(var i = 0; i < numSquares; i++)
		$("#gridWrap").append("<div>");
	
	var gridDivs = $("#gridWrap div");
	var index = 0;
	for(var row = 0; row < squaresHigh; row++)
	{
		grid[row] = [];
		for(var col = 0; col < squaresWide; col++)
		{
			grid[row].push($(gridDivs[index]));
			index++;
		}
	}
	
	var shooterIndex = squaresWide / 2;
	var currShooter = $(grid[squaresHigh - 1][shooterIndex]);
	currShooter.addClass("shooter");
	
	invadersLeft = numInvadersWide * numInvadersTall;
	
	setInterval(function() {
		$(".invader").removeClass("invader");
		if(invaderLeftIndex + numInvadersWide == squaresWide)
		{
			invaderDirection = -1;
			invaderTopIndex++;
		}
		if(invaderLeftIndex == 0)
		{
			invaderDirection = 1;
			invaderTopIndex++
		}
		invaderLeftIndex += invaderDirection;
		
		if(invaderTopIndex + numInvadersTall == squaresHigh)
			alert("You Died!");
					
		for(var row = 0; row < numInvadersTall; row++)
		{
			if(invaders[row] === undefined)
			{
				invaders[row] = [];
				for(var col = 0; col < numInvadersWide; col++)
					invaders[row].push("alive");
			}
			for(var col = 0; col < numInvadersWide; col++)
			{
				if(invaders[row][col] == "alive")
				{
					var work = $(grid[row + invaderTopIndex][col + invaderLeftIndex]);
					work.addClass("invader");
					
					var shouldShoot = Math.random() < 0.03;
					if(shouldShoot)
						moveInvaderLaser(row + invaderTopIndex, col + invaderLeftIndex);
				}
			}
		}
	}, 250);
	
	
	$(document).keydown(function(e) {
		switch(e.keyCode)
		{
			case 39: //right
				if(shooterIndex + 1 < gridSize) 
					shooterIndex++;
				break;
			case 37: //left
				if(shooterIndex - 1 >= 0)
					shooterIndex--;
				break;
			case 32: //space
				var row = squaresHigh - 1;
				moveLaser(row, shooterIndex);
				break;					
		}
		
		currShooter.removeClass("shooter");
		currShooter = $(grid[squaresHigh - 1][shooterIndex]).addClass("shooter");
	});
});

function moveLaser(row, col)
{
	$(grid[row][col]).removeClass("laser");
	row--;
	if(row >= 0)
	{
		var work = $(grid[row][col]);
		if(work.hasClass("invader"))
		{
			invaders[row - invaderTopIndex][col - invaderLeftIndex] = "dead";
			work.addClass("boom");
			setTimeout(function() {
				work.removeClass("boom");
			}, 500);
			
			if(invadersLeft == 0)
				alert("you won!");
				
			return;
		}
		$(work).addClass("laser");	
		setTimeout(function() { moveLaser(row, col); }, 100);
	}
}

function moveInvaderLaser(row, col)
{
	$(grid[row][col]).removeClass("invaderLaser");
	row++;
	if(row < squaresHigh)
	{
		var work = $(grid[row][col]);
		if(work.hasClass("shooter"))
		{
			alert("You Died!");
			work.addClass("boom");
			setTimeout(function() {
				work.removeClass("boom");
			}, 1000);
			
			return;
		}
		$(work).addClass("invaderLaser");	
		setTimeout(function() { moveInvaderLaser(row, col); }, 100);
	}
}

﻿$(document).ready(function() {
	console.log("Loaded!");	
		
	$("#btnAddItem").click(function() {
		var val = $("#txtInput").val();
		
		$.get("/lesson9?content=" + val, function(data) {
			$("#myList").append(`<li class="list-group-item">${data}</li>`);
			$("#txtInput").val("");		
		});
	});
	
	var dob = "1980-04-02";
	var obj = {
		firstName: "Jack",
		lastName: "Castillo",
		id: 382847,
		birthDate: dob
	};
	obj["room"] = "254";
	obj["firstName"] = "Julio";
	
	var str = JSON.stringify(obj);
	var json = JSON.parse(str);
	
	$("#btnCalculate").click(function() {
		var json_poco = {
			X: $("#txtX").val(),
			Y: $("#txtY").val(),
			Operation: $("#drpOperation").val()
		};
		
		$.ajax({
			url: "/lesson9",
			type: "POST",
			contentType: "application/json",
			dataType: "json",
			headers: {
				Authorization: "AuthToken"
			},
			data: JSON.stringify(json_poco),
			success: function (data, status) {
				$("#divResult")
					.fadeIn()
					.text(data.Result);	
			}
		});
		
		
	});
	
	
});

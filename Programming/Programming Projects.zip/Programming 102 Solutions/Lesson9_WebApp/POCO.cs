﻿

public class CalculatorPOCO
{
	public int X;
	public int Y;
	public string Operation;
	public int Result { 
		get {
			if(Operation == "+")
				return X + Y;
			else if(Operation == "-")
				return X - Y;
			else if(Operation == "*")
				return X * Y;
			else if(Operation == "/")
				return X / Y;
			
			return 0;
		}
	}
}

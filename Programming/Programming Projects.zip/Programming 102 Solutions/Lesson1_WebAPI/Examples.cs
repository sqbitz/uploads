﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data.SQLite;

[RoutePrefix("employees/{id:int}")]
public class EmployeeController : ApiController
{
	[Route(""), HttpGet]
	public string GetName(int id)
	{
		return "hi!" + id;
	}
	
	[Route("giveRaise/{amt:decimal}"), HttpPost]
	public bool GiveRaise(int id, decimal amt)
	{
		Console.WriteLine(amt.ToString("c") + " to " + id);
		return true;
	}
}

public class InmatesController : ApiController
{
	[Route("inmates/{id}/notes"), HttpPost]
	public string AddNodes(int id, [FromBody]string notes)
	{
		return notes.Length + " added for inmate " + id;
	}
	
	[Route("inmates/{id}/release"), HttpPost]
	public string SetRelease(int id, [FromBody]DateTime releaseDate)
	{
		return id + " set for release on " + releaseDate;
	}
	
	
	
	[Route("inmates/{id}/changeID"), HttpPost]
	public string SetRelease(int id, [FromBody]int newID)
	{
		return id + " changed to " + newID;
	}
	
	
	[Route("inmates/search"), HttpGet]
	public List<string> Search()
	{
		return new List<string>();
	}
	
	[Route("inmates/search"), HttpGet]
	public List<string> Search(int id, string fName, string lName)
	{
		return new List<string> { id + " " + fName + " " + lName };
	}
}

﻿using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Results;
using System.Net.Http;
using System.Net.Http.Headers;
using System;
using System.IO;

[RoutePrefix("api")]
public class ValuesController : ApiController
{
	[Route(""), HttpGet]
	public IEnumerable<string> Get()
	{
		return new List<string> { "ASP.NET", "Docker", "Windows Containers" };
	}	
}




	[RoutePrefix("inmate/{id:int}")]
	public class InmateController : ApiController
	{
		[Route("")]
		public string GetName(string id)
		{
			if(id == "382847")
				return "Jack Castillo";
			
			return "unknown";
		}
		
		[Route("photo"), HttpGet]
		public byte[] GetImage(string id)
		{
			return File.ReadAllBytes(@"images\" + id + ".jpg");
		}
		
		[Route("photo"), HttpPost]
		public void UpdateImage(string id, [FromBody] byte[] newImage)
		{
			File.WriteAllBytes(@"images\" + id + ".jpg", newImage);
		}
		
		public void stuff(string stuff)
		{
			
		}
	}

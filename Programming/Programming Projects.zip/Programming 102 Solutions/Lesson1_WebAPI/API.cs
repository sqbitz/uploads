﻿using System;
using System.Web.Http;

[RoutePrefix("lesson1")]
public class CalculatorController : ApiController
{
	[Route("add/{x}/{y}"), HttpGet]
	public int Add(int x, int y)
	{
		return x + y;
	}
	
	[Route("subtract"), HttpPost]
	public int Subtract(int x, int y)
	{
		return x - y;
	}
	
	[Route("divide/{x}"), HttpGet]
	public double Divide(double x, double y)
	{
		return x / y;
	}
	
	[Route("multiply"), HttpPost]
	public int Multiply([FromBody] string csv)
	{
		var split = csv.Split(',');
		var x = int.Parse(split[0]);
		var y = int.Parse(split[1]);
		return x * y;
	}
	
	[Route("length"), HttpPost]
	public int Length([FromBody] string str)
	{
		return str.Length;	
	}
	
	[Route("sqrt/{x}"), HttpGet]
	public double SquareRoot(int x)
	{
		return Math.Sqrt(x);
	}
	
	
	
	
}

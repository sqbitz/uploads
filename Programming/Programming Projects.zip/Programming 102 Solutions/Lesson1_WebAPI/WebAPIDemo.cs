﻿using System;
using System.Web.Http;

public class DemoController : ApiController
{
	[Route("hello_world"), HttpGet]
	public string[] HelloWorld()
	{
		return new string[] {
			"Hello World!",
			"Now: " + DateTime.Now
		};
	}
}

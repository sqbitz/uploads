﻿using System;
using System.Data.SQLite;
using System.Web.Http;
using System.Collections.Generic;
using System.Linq;

[RoutePrefix("phonebook")]
public class PhonebookController : ApiController
{
	[Route("{id}"), HttpGet]
	public string GetEntry(int id)
	{
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand(@"SELECT * FROM Phonebook
																	WHERE BookID = @id", conn))
			{
				cmd.Parameters.AddWithValue("id", id);
				using(var rdr = cmd.ExecuteReader())
				{
						rdr.Read();
						return  rdr["BookID"] + ". " + rdr["PhoneNumber"] + " @ " + rdr["Line1"];
				}
			}
		}
	}
	
	[Route(""), HttpPost]
	public void AddEntry(string phone, string line1, string city, string state, string zip)
	{
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand(@"INSERT INTO Phonebook (PhoneNumber, Line1, City, State, Zip)
																						VALUES (@phone, @line, @city, @state, @zip)", conn))
			{
				cmd.Parameters.AddWithValue("phone", phone);
				cmd.Parameters.AddWithValue("line", line1);
				cmd.Parameters.AddWithValue("city", city);
				cmd.Parameters.AddWithValue("state", state);
				cmd.Parameters.AddWithValue("zip", zip);
				
				cmd.ExecuteNonQuery();
			}
		}
	}
}

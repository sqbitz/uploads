﻿
using System;
using System.Data.SQLite;
using System.Web.Http;
using System.Collections.Generic;
using System.Linq;

[RoutePrefix("todo")]
public class TodoController : ApiController
{
	[Route(""), HttpGet]
	public List<string> GetTodos()
	{
		var ret = new List<string>();
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand("SELECT TodoID, Task FROM Todo", conn))
			using(var rdr = cmd.ExecuteReader())
			{
				while(rdr.Read())
				{
					var todoItem = rdr["TodoID"] + ". " + rdr["Task"];
					ret.Add(todoItem);
				}
			}
		}
		return ret;
	}
	
	
	[Route("employee/{employeeID}"), HttpGet]
	public List<string> GetTodosForEmployee(int employeeID)
	{
		var ret = new List<string>();
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand(@"SELECT TodoID, Task 
																FROM Todo 
																WHERE employeeID = @empID", conn))
			{
				cmd.Parameters.AddWithValue("empID", employeeID);
				using(var rdr = cmd.ExecuteReader())
				{
					while(rdr.Read())
					{
						var todoItem = rdr["TodoID"] + ". " + rdr["Task"];
						ret.Add(todoItem);
					}
				}
			}
		}
		return ret;
	}
	
	[Route("add"), HttpPost]
	public void Add(int employeeID, string task, DateTime dueDate)
	{
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand(@"INSERT INTO Todo (EmployeeID, Task, DueDate)
																				VALUES (@empID, @task, @dueDate)", conn))
			{
				cmd.Parameters.AddWithValue("empID", employeeID);
				cmd.Parameters.AddWithValue("task", task);
				cmd.Parameters.AddWithValue("dueDate", dueDate);
				cmd.ExecuteNonQuery();
			}
		}
	}
	
	
	[Route("{todoID}/delete"), HttpPost]
	public int DeleteTodo(int todoID)
	{
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand(@"DELETE FROM Todo 
																WHERE todoID = @todoID", conn))
			{
				cmd.Parameters.AddWithValue("todoID", todoID);
				return cmd.ExecuteNonQuery();
			}
		}
	}
	
	[Route("{todoID}/complete"), HttpPost]
	public int CompleteTodo(int todoID)
	{
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand(@"UPDATE Todo SET CompletedDate = CURRENT_TIMESTAMP
																WHERE todoID = @todoID", conn))
			{
				cmd.Parameters.AddWithValue("todoID", todoID);
				return cmd.ExecuteNonQuery();
			}
		}
	}
	
	[Route("{todoID}/notes"), HttpPost]
	public int CompleteTodo(int todoID, [FromBody] string notes)
	{
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand(@"UPDATE Todo SET Notes = @notes
																WHERE todoID = @todoID", conn))
			{
				cmd.Parameters.AddWithValue("todoID", todoID);
				cmd.Parameters.AddWithValue("notes", notes);
				return cmd.ExecuteNonQuery();
			}
		}
	}
}

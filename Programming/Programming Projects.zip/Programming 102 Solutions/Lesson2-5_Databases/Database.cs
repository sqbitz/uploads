﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data.SQLite;
using System.Linq;

[RoutePrefix("lesson5")]
public class DatabaseController : ApiController
{
	[Route("lastNames"), HttpGet]
	public List<string> EmployeeNames()
	{
		var ret = new List<string>();
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand("SELECT LastName FROM Employees", conn))
			using(var rdr = cmd.ExecuteReader())
			{
				while(rdr.Read())
				{
					ret.Add(rdr["LastName"].ToString());
				}
			}
			
		}
		return ret;
	}
	
	[Route("recentOrder"), HttpGet]
	public List<int> MostRecentOrders(int numOrders)
	{
		var ret = new List<int>();
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand(@"SELECT OrderID FROM Orders
									ORDER BY OrderID DESC
									LIMIT @num", conn))
			{
				cmd.Parameters.AddWithValue("num", numOrders);
				using(var rdr = cmd.ExecuteReader())
					while(rdr.Read())
						ret.Add(int.Parse(rdr["OrderID"].ToString()));
			}
		}
		return ret;
	}
	
	[Route("recentOrder"), HttpGet]
	public int MostRecentOrder()
	{
		return MostRecentOrders(1).First();
	}
	
	[Route("employees/update"), HttpPost]
	public void Update(int employeeID, string newTitle)
	{
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand(@"UPDATE Employees 
										SET Title = @title
									WHERE employeeID = @empID", conn))
			{
				cmd.Parameters.AddWithValue("title", newTitle);
				cmd.Parameters.AddWithValue("empID", employeeID);
				int numRowsAffected = cmd.ExecuteNonQuery();
			}
		}
	}
	
	[Route("updateWithInjection"), HttpPost]
	public void UpdateInject(int employeeID, string newName)
	{
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			Console.WriteLine(newName);
			using(var cmd = new SQLiteCommand(@"UPDATE Employees 
										SET LastName = '" + newName + @"'
									WHERE employeeID = " + employeeID, conn))
				cmd.ExecuteNonQuery();
		}
	}
	
	
	[Route("employees"), HttpPost]
	public void AddEmployee(string fName,string lName, string t, DateTime dt)
	{
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand(@"INSERT INTO Employees 
										(LastName, FirstName, Title, BirthDate) 
									VALUES (@last, @first, @title, @bd)", conn))
			{
				cmd.Parameters.AddWithValue("last", lName);
				cmd.Parameters.AddWithValue("first", fName);
				cmd.Parameters.AddWithValue("title", t);
				cmd.Parameters.AddWithValue("bd", dt);
				cmd.ExecuteNonQuery();
			}
		}
	}
	
	[Route("employees"), HttpDelete]
	public void Delete(int employeeID)
	{
		using(var conn = new SQLiteConnection("Data Source=app.db"))
		{
			conn.Open();
			using(var cmd = new SQLiteCommand(@"DELETE FROM Employees 
										WHERE employeeID = @empID", conn))
			{
				cmd.Parameters.AddWithValue("empID", employeeID);
				int numRowsAffected = cmd.ExecuteNonQuery();
			}
		}
	}
}

﻿$(document).ready(function() {
	console.log("Loaded!");	
		
	$("#btnAddItem").click(function() {
		var val = $("#txtInput").val();
		$("#myList").append(`<li class="list-group-item">${val}</li>`);
		$("#txtInput").val("");
	});
});

function asdf() {
	
	var name = "Jack";
	console.log(`Hello World ${3 + 5} I'm ${name}`);
	

	var items = ["Jack", "James", "Sam", "Bob"];
	for(var i = 0; i < items.length; i++)
		$("#myList").append(`<li>${items[i]}</li>`);

		
	$("#btnAddItem").click(function() {
		var val = $("#txtInput").val();
		
		$.get("/lesson9?content=" + val, function(data) {
			$("#myList").append(`<li class="list-group-item">${data}</li>`);
			$("#txtInput").val("");
		});
	});
}

﻿$(document).ready(function() {
	console.log("Loaded!");
	
	$.get("/calendar/month", function(data) {
		$("#month").text(`${data.Name} :: ${data.Year}`);
		
		$("#calendar").empty();
		for(var w = 0; w < data.Weeks.length; w++)
		{
			var row = $("<div class='row'>");
			for(var d = 0; d < data.Weeks[w].Days.length; d++)
			{
				var col = $("<div class='col day'>");
				
				var day = data.Weeks[w].Days[d];
				if(day != null)
				{
					col.html(`${day.DayNumber}<br />${day.Name}`);
					col.attr("date", day.Date);
				}
				
				col.click(function () {
					$(".day").removeClass("bg-primary");
					$(this).addClass("bg-primary");
					
					var date = $(this).attr("date");
					$.get(`/calendar/day/${date}`, 
						function(data) {
							$("#info").html(`${data.DayNumber}
									<br />${data.Name}`);
					});
				});
					
				row.append(col);
			}
			$("#calendar").append(row);
		}
	});
});









﻿using System;
using System.Net.Http;
using System.Web.Http;
using System.Collections.Generic;
using System.Linq;

[RoutePrefix("calendar")]
public class CalendarController : ApiController
{
	[Route("today"), HttpGet]
	public Day Today() {
		return new Day(DateTime.Now);
	}
	
	[Route("day/{date}"), HttpGet]
	public Day GetDay(DateTime date)
	{
		return new Day(date);
	}
	
	[Route("month"), HttpGet]
	public Month ThisMonth()
	{
		return GetMonth(DateTime.Now.Year, DateTime.Now.Month);
	}
	
	[Route("month/{year}/{month}"), HttpGet]
	public Month GetMonth(int year, int month)
	{
		var m = new DateTime(year, month, 1);
		
		var ret = new Month() {
			Name = m.ToString("MMMM"),
			Num = month,
			Year = year,
			Weeks = new List<Week>()
		};
		
		var w = new Week() { Num = 1	};
	
		do
		{
			var weekDay = (int)m.DayOfWeek;
			w.Days[weekDay] = new Day(m);
			
			m = m.AddDays(1.0);
			if(m.DayOfWeek == DayOfWeek.Sunday)
			{
				ret.Weeks.Add(w);
				w = new Week() {
					Num = w.Num + 1
				};
			}
		} while(m.Month == month);
		
		ret.Weeks.Add(w);
		
		return ret;
	}
	
}

public class Month
{
	public string Name;
	public int Num;
	public int Year;
	
	public List<Week> Weeks;
}

public class Week
{
	public int Num;
	public Day[] Days;
	
	public Week() {
		Days = new Day[7];	
	}
}

public class Day
{
	public Day(DateTime d)
	{
		Name = d.DayOfWeek.ToString();
		DayNumber = d.Day;
		DayOfWeekNum = (int)d.DayOfWeek;
		DayOfYear = d.DayOfYear;
		Date = d;
	}
	public string Name;
	public int DayNumber;
	public int DayOfYear;
	public int DayOfWeekNum;
	public DateTime Date;
}





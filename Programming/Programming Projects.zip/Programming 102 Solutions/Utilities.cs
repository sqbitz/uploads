﻿
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Results;
using System.Net.Http;
using System.Net.Http.Headers;
using System;
using System.Text;
using System.Linq;
using System.Data.SQLite;

public class Utilities
{
	public void GenerateActions()
	{
		var actions = new string[] 
		{
			"Place Order",
			"Change Password",	
			"Call Customer",
			"Send Email",
			"Read Email",
			"Type Letter",
			"Attend Meeting"
		};
		
		var sourceIPs = new List<string>();
		
		var rnd = new Random();
		while(sourceIPs.Count() < 30)
		{
			var sb = new StringBuilder();
			sb.Append(rnd.Next(1, 250)).Append(".");
			sb.Append(rnd.Next(1, 250)).Append(".");
			sb.Append(rnd.Next(1, 250)).Append(".");
			sb.Append(rnd.Next(1, 250));
			sourceIPs.Add(sb.ToString());
		}
		
		int totalActions = 0;
		var dtTimestamp = new DateTime(2000, 1, 1);
		using(var conn = new SQLiteConnection("Data Source=app.db;Pooling=true;FailIfMissing=false"))
		{
			conn.Open();
			
			while(totalActions < 1000000)
				using(var cmd = new SQLiteCommand("SELECT EmployeeID FROM Employees ORDER BY RANDOM() LIMIT 1;", conn))
				{
					var employee = cmd.ExecuteScalar();
					var sourceIP = sourceIPs[rnd.Next(0, sourceIPs.Count)];
					
					dtTimestamp = dtTimestamp.AddMinutes(rnd.Next(1, 1440));
					
					Console.WriteLine("\n{0,-5} {1,-30} {2} {3}", employee, sourceIP, dtTimestamp, totalActions);
					
					var sb = new StringBuilder("INSERT INTO EmployeeActions VALUES (NULL, @employeeID, @timestampLogin, @sourceIP, 'Login');");
	
					using(var cmd2 = new SQLiteCommand(conn))
					{
						cmd2.Parameters.AddWithValue("employeeID", employee);
						cmd2.Parameters.AddWithValue("sourceIP", sourceIP);
						
						cmd2.Parameters.AddWithValue("timestampLogin", dtTimestamp);
	
						var numActions = rnd.Next(0, 20);
						while(numActions > 0)
						{
							var action = actions[rnd.Next(0, actions.Length)];
							dtTimestamp = dtTimestamp.AddSeconds(rnd.Next(0, 360));
							sb.Append("INSERT INTO EmployeeActions VALUES (NULL, @employeeID, @timestamp").Append(numActions)
									.Append(", @sourceIP, @action").Append(numActions)
									.Append(");");
							
							cmd2.Parameters.AddWithValue("timestamp" + numActions, dtTimestamp);
							cmd2.Parameters.AddWithValue("action" + numActions, action);
							Console.Write(".");
							numActions--;
						}
						
						sb.Append("INSERT INTO EmployeeActions VALUES (NULL, @employeeID, @timestampLogout, @sourceIP, 'Logout');");
						
						dtTimestamp = dtTimestamp.AddSeconds(rnd.Next(0, 60));
						cmd2.Parameters.AddWithValue("timestampLogout", dtTimestamp);			
						
						cmd2.CommandText = sb.ToString();
						totalActions += cmd2.ExecuteNonQuery();
					}
					
				}
		}
	}
}

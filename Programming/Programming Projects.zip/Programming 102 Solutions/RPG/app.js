﻿var squaresWide;
var squaresHigh;
var gridSize = 32;
		
$(document).ready(function() {
	var docHeight = $(document).height();
	var height = $("#layer1").height();
	var width = $("#layer2").width();
	
	var numSquares = (height / gridSize) * (width / gridSize);
	squaresWide = width / gridSize - 1;
	squaresHigh = height / gridSize;
	
	var col = 0;
	var row = 0;
	for(var i = 0; i < numSquares; i++)
	{
		var imgIndex = Math.floor((Math.random() * 100) % 3);
		var zIndex = Math.floor((Math.random() * 100) % 5) + 5;
		var type = "dirt";
		if(col > 40 || row > 25)
			type = "water";
		$("#layer1").append(`<div class="z${zIndex} ${type}${imgIndex}"></div>`);
		col++;
		if(col > squaresWide)
		{
			col = 0;
			row++;
		}
		
		imgIndex = Math.floor((Math.random() * 100) % 6);
		zIndex = Math.floor((Math.random() * 100) % 5) + 1;
		if(col < 2 || col > 39 || row > 24)
		{
			imgIndex = 50;	
		}
		$("#layer2").append(`<div class="z${zIndex + 10} grass${imgIndex}">`);		
	}
	
	$(document).keydown(function(e) {
		switch(e.keyCode)
		{
			case 39: //right
				break;
			case 37: //left
				break;
			case 40: //down
				break;
			case 32: //space
			case 38: //up
				break;					
		}
	});
});

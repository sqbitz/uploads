﻿using System;
using System.Windows.Forms;
using System.Data;
using System.Drawing;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mime;
using System.Web;
using System.Web.Http;
using System.Web.Http.Filters;
using System.Web.Http.Dispatcher;
using System.Web.Http.Controllers;
using Owin;
using Microsoft.Owin;
using Microsoft.Owin.Hosting;
using System.Reflection;
using Newtonsoft.Json;

public class SelfHostApp
{
	[STAThread]
	public static void Main(string[] args)
	{
		//Load DLLs from bin directory if they exist
		var ad = System.Threading.Thread.GetDomain();
		ad.AssemblyResolve += (o,e) => {
			var dllName = new AssemblyName(e.Name).Name + ".dll";
			var testPath = Path.Combine(Directory.GetCurrentDirectory(), "bin", dllName);
			if(!File.Exists(testPath))
				return null;

			var assem = Assembly.LoadFile(testPath);
			return assem;
		};

		Application.SetCompatibleTextRenderingDefault(true);
		Application.EnableVisualStyles();
		Application.Run(new ApplicationContext(new WebServer()));	
	}
}

public class WebServer : Form
{
	private IDisposable webServer; 
	private DataGridView dgv;
	private DataTable dt;
	private BindingList<RequestEvent> requests;
	
	private DataGridView dgvRequestHeaders;
	private DataGridView dgvResponseHeaders;
	private DataGridView dgvRequestProperties;
	private Label lblPathDetails;
	private Label lblContentType;
	private TextBox txtRequestBody;
	private TextBox txtResponseBody;
	
	public WebServer()
	{
		var url = "http://localhost:12345";
		Console.WriteLine("Running at " + url);
		
		requests = new BindingList<RequestEvent>();
		var diagHandler = new DiagnosticHandler();
		
		webServer = WebApp.Start(url, app => {
			var config = new HttpConfiguration();

			config.MapHttpAttributeRoutes();
			config.MessageHandlers.Add(diagHandler);
			app.UseWebApi(config);	
		});
		
		Process.Start(url);
		
		Closing += closingHandler;
		diagHandler.Request += (o,e) => {
			dgv.Invoke(new Action(delegate() {
				requests.Add(e);	
			}));
		};
		setupForm();
		dgv.Focus();
	}
	
	public void closingHandler(object o, EventArgs e)
	{
		webServer.Dispose();
	}
	
	public void setupForm()
	{
		Text = Name = "Programming 102 Webserver";
		Width = 1100;
		Height = 800;
		BackColor = Color.FromArgb(47, 47, 51);
		ForeColor = Color.White;
		var tlp = new TableLayoutPanel(){
			Dock = DockStyle.Fill,
			Padding = new Padding(0)
		};
		
		dgv = new DataGridView(){
			Dock = DockStyle.Fill,
			AutoGenerateColumns = false,
			RowHeadersVisible = false,
			GridColor = Color.FromArgb(30, 30, 34),
			BackColor = Color.FromArgb(47, 47, 51),
			BackgroundColor = Color.FromArgb(47, 47, 51),
			EditMode = DataGridViewEditMode.EditProgrammatically,
			ForeColor = Color.White,
			BorderStyle = BorderStyle.None,
			SelectionMode = DataGridViewSelectionMode.FullRowSelect,
			AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
			AllowUserToAddRows = false,
			AllowUserToDeleteRows = false,
			AllowUserToOrderColumns = false,
			AllowUserToResizeRows = false,
			ShowCellErrors = false,
			ShowEditingIcon = false,
		};
		dgv.AdvancedCellBorderStyle.All = DataGridViewAdvancedCellBorderStyle.Single;
		dgv.RowsDefaultCellStyle = new DataGridViewCellStyle{
			BackColor = Color.FromArgb(47, 47, 51),
			ForeColor = Color.White
		};
		dgv.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle {
			BackColor = Color.FromArgb(37, 37, 41),
			ForeColor = Color.White,
			SelectionBackColor = Color.FromArgb(37, 37, 41)
		};
		
		dgv.Columns.Add(new DataGridViewColumn() { 
			DataPropertyName = "Timestamp",
			CellTemplate = new DataGridViewTextBoxCell(),
			AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
		});
		dgv.Columns.Add(new DataGridViewColumn() { 
			DataPropertyName = "Method",
			CellTemplate = new DGVTextBoxCell(),
			AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
		});
		dgv.Columns.Add(new DataGridViewColumn() { 
			DataPropertyName = "Path",
			CellTemplate = new DataGridViewTextBoxCell(),
			AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
		});
		dgv.Columns.Add(new DataGridViewColumn() { 
			DataPropertyName = "StatusCode",
			CellTemplate = new DGVTextBoxCell(),
			AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
		});
		dgv.Columns.Add(new DataGridViewColumn() { 
			DataPropertyName = "Reason",
			CellTemplate = new DataGridViewTextBoxCell(),
			AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
		});
		dgv.Columns.Add(new DataGridViewColumn() { 
			DataPropertyName = "Took",
			HeaderText = "Took (ms)",
			CellTemplate = new DataGridViewTextBoxCell(),
			AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
		});
		dgv.Columns.Add(new DataGridViewColumn() { 
			DataPropertyName = "QueryString",
			HeaderText = "Query",
			CellTemplate = new DataGridViewTextBoxCell(),
			AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
		});
		foreach(DataGridViewColumn c in dgv.Columns)
			if(string.IsNullOrEmpty(c.HeaderText))
				c.HeaderText = c.DataPropertyName;
		
		dgv.DataSource = requests;
		dgv.RowsAdded += (o,e) => {
			dgv.CurrentCell = dgv.Rows[e.RowIndex].Cells[0];
		};
		dgv.CurrentCellChanged += currentCellChangedHandler;
		tlp.Controls.Add(dgv, 0, 0);
		
		var pnlDetails = new Panel(){
			Dock = DockStyle.Fill,
		};
		tlp.Controls.Add(pnlDetails, 1, 0);
		
		var tlpDetails = new TableLayoutPanel() {
			Dock = DockStyle.Fill,
			AutoScroll = true
		};
		
		lblPathDetails = new Label() {
			Font = new Font(this.Font.FontFamily, 10, FontStyle.Bold),
			Dock = DockStyle.Fill,
			Margin = new Padding(0, 0, 0, 5),
			Cursor = Cursors.Hand
		};
		lblPathDetails.Click += (o,e) => {
			Process.Start(lblPathDetails.Tag.ToString());
		};
		var row = 0;
		tlpDetails.Controls.Add(lblPathDetails, 0, row);
		
		lblContentType = new Label() { 
			Dock = DockStyle.Fill,
			Margin = new Padding(0, 0, 0, 5)
		};
		tlpDetails.Controls.Add(lblContentType, 0, ++row);
		
		tlpDetails.Controls.Add(new Label() { 
			Text = "Request Body",
			Dock = DockStyle.Fill, 
			Font = new Font(this.Font, FontStyle.Bold), 
			Margin = new Padding(0, 5, 0, 0)
		}, 0, ++row);
		txtRequestBody = new TextBox() {
			Dock = DockStyle.Fill,
			Margin = new Padding(2, 0, 2, 10),
			Padding = new Padding(1),
			Multiline = true,
			Height = 100,
			BorderStyle = BorderStyle.None,
			BackColor = Color.FromArgb(50, 50, 54),
			ForeColor = Color.White
		};
		tlpDetails.Controls.Add(txtRequestBody, 0, ++row);
		
		tlpDetails.Controls.Add(new Label() { 
			Text = "Response Body", 
			Dock = DockStyle.Fill, 
			Font = new Font(this.Font, FontStyle.Bold), 
			Margin = new Padding(0, 5, 0, 0) 
		}, 0, ++row);
		txtResponseBody = new TextBox() {
			Dock = DockStyle.Fill,
			Margin = new Padding(2, 0, 2, 10),
			Padding = new Padding(1),
			Multiline = true,
			Height = 100,
			BorderStyle = BorderStyle.None,
			BackColor = Color.FromArgb(50, 50, 54),
			ForeColor = Color.White
		};
		tlpDetails.Controls.Add(txtResponseBody, 0, ++row);
		
		tlpDetails.Controls.Add(new Label() { 
			Text = "Request Headers", 
			Dock = DockStyle.Fill, 
			Font = new Font(this.Font, FontStyle.Bold), 
			Margin = new Padding(0, 5, 0, 0) 
		}, 0, ++row);
		dgvRequestHeaders = new DataGridView() {
			Dock = DockStyle.Fill,
			AutoGenerateColumns = true,
			BorderStyle = BorderStyle.None,
			AutoSize = true,
			AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
			GridColor = Color.FromArgb(30, 30, 34),
			BackgroundColor = Color.FromArgb(47, 47, 51),
			EditMode = DataGridViewEditMode.EditProgrammatically,
			ForeColor = Color.White,
			SelectionMode = DataGridViewSelectionMode.FullRowSelect,
			AllowUserToAddRows = false,
			AllowUserToDeleteRows = false,
			AllowUserToOrderColumns = false,
			AllowUserToResizeRows = false,
			ShowCellErrors = false,
			ShowEditingIcon = false,
			RowHeadersVisible = false
		};
		
		dgvRequestHeaders.AdvancedCellBorderStyle.All = DataGridViewAdvancedCellBorderStyle.Single;
		dgvRequestHeaders.RowsDefaultCellStyle = dgv.RowsDefaultCellStyle;
		dgvRequestHeaders.ColumnHeadersDefaultCellStyle = dgv.ColumnHeadersDefaultCellStyle;
		tlpDetails.Controls.Add(dgvRequestHeaders, 0, ++row);
		
		tlpDetails.Controls.Add(new Label() { 
			Text = "Response Headers", 
			Dock = DockStyle.Fill, 
			Font = new Font(this.Font, FontStyle.Bold), 
			Margin = new Padding(0, 5, 0, 0) 
		}, 0, ++row);
		dgvResponseHeaders = new DataGridView() {
			Dock = DockStyle.Fill,
			AutoGenerateColumns = true,
			BorderStyle = BorderStyle.None,
			AutoSize = true,
			AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
			GridColor = Color.FromArgb(30, 30, 34),
			BackgroundColor = Color.FromArgb(47, 47, 51),
			EditMode = DataGridViewEditMode.EditProgrammatically,
			ForeColor = Color.White,
			SelectionMode = DataGridViewSelectionMode.FullRowSelect,
			AllowUserToAddRows = false,
			AllowUserToDeleteRows = false,
			AllowUserToOrderColumns = false,
			AllowUserToResizeRows = false,
			ShowCellErrors = false,
			ShowEditingIcon = false,
			RowHeadersVisible = false
		};
		dgvResponseHeaders.AdvancedCellBorderStyle.All = DataGridViewAdvancedCellBorderStyle.Single;
		dgvResponseHeaders.RowsDefaultCellStyle = dgv.RowsDefaultCellStyle;
		dgvResponseHeaders.ColumnHeadersDefaultCellStyle = dgv.ColumnHeadersDefaultCellStyle;
		tlpDetails.Controls.Add(dgvResponseHeaders, 0, ++row);
		
		tlpDetails.Controls.Add(new Label() { 
			Text = "Request Properties", 
			Dock = DockStyle.Fill, 
			Font = new Font(this.Font, FontStyle.Bold), 
			Margin = new Padding(0, 5, 0, 0) 
		}, 0, ++row);
		dgvRequestProperties = new DataGridView() {
			Dock = DockStyle.Fill,
			AutoGenerateColumns = true,
			BorderStyle = BorderStyle.None,
			AutoSize = true,
			AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
			GridColor = Color.FromArgb(30, 30, 34),
			BackgroundColor = Color.FromArgb(47, 47, 51),
			EditMode = DataGridViewEditMode.EditProgrammatically,
			ForeColor = Color.White,
			SelectionMode = DataGridViewSelectionMode.FullRowSelect,
			AllowUserToAddRows = false,
			AllowUserToDeleteRows = false,
			AllowUserToOrderColumns = false,
			AllowUserToResizeRows = false,
			ShowCellErrors = false,
			ShowEditingIcon = false,
			RowHeadersVisible = false
		};
		dgvRequestProperties.AdvancedCellBorderStyle.All = DataGridViewAdvancedCellBorderStyle.Single;
		dgvRequestProperties.RowsDefaultCellStyle = dgv.RowsDefaultCellStyle;
		dgvRequestProperties.ColumnHeadersDefaultCellStyle = dgv.ColumnHeadersDefaultCellStyle;
		tlpDetails.Controls.Add(dgvRequestProperties, 0, ++row);
		
		
		pnlDetails.Controls.Add(tlpDetails);
		
		tlp.ColumnStyles.Add(new ColumnStyle {
			SizeType = SizeType.Percent,
			Width = 63
		});
		tlp.ColumnStyles.Add(new ColumnStyle {
			SizeType = SizeType.Percent,
			Width = 37
		});
		
		tlp.CellPaint += (o,e) => {
			if(e.CellBounds.X < 10)
				return;
			
			e.Graphics.DrawLine(Pens.DarkRed, e.CellBounds.X, e.CellBounds.Y, e.CellBounds.X, e.CellBounds.Y + e.CellBounds.Height);	
		};
			
		this.Controls.Add(tlp);	
	}
	
	private void currentCellChangedHandler(object sender, EventArgs e)
	{
		if(dgv.SelectedRows.Count == 0)
			return;
			
		var row = dgv.SelectedRows[0];
		var requestEvent = (RequestEvent)row.DataBoundItem;
		
		lblPathDetails.Text = requestEvent.Method + " " + requestEvent.Path;
		var url = "http://localhost:12345" + requestEvent.Path;
		if(!string.IsNullOrEmpty(requestEvent.QueryString))
		{
			lblPathDetails.Text += requestEvent.QueryString;
			url += requestEvent.QueryString;
		}
		lblPathDetails.Tag = url;
		
		
		lblContentType.Text = requestEvent.ContentType;
		txtRequestBody.Text = requestEvent.RequestBody;
		if(requestEvent.ContentType.Contains("json"))
			txtRequestBody.Text = JsonConvert.SerializeObject(JsonConvert.DeserializeObject(requestEvent.RequestBody), Formatting.Indented);
		
		txtResponseBody.Text = requestEvent.ResponseBody;	
		try
		{
			txtResponseBody.Text = JsonConvert.SerializeObject(JsonConvert.DeserializeObject(requestEvent.ResponseBody), Formatting.Indented);
		}
		catch(Exception)	{}
		
		dgvRequestHeaders.DataSource = requestEvent.RequestHeaders;
		dgvResponseHeaders.DataSource = requestEvent.ResponseHeaders;
		dgvRequestProperties.DataSource = requestEvent.RequestProperties;
	}
}

public class DGVTextBoxCell : DataGridViewTextBoxCell {
	
	protected override void Paint(Graphics g, Rectangle clipBounds, Rectangle cellBounds, int rowIndex, DataGridViewElementStates cellState, object value, object formattedValue, string errorText, DataGridViewCellStyle cellStyle, DataGridViewAdvancedBorderStyle abs, DataGridViewPaintParts paintParts) 
	{
		int statusCode;
		int.TryParse(value.ToString(), out statusCode);
		
		cellStyle.BackColor = Color.Green;
		
		cellState = DataGridViewElementStates.None;
				
		if(value.ToString() == "POST")
			cellStyle.BackColor = Color.Blue;
		else if(value.ToString() == "PUT")
			cellStyle.BackColor = Color.Cyan;
		else if(value.ToString() == "DELETE")
			cellStyle.BackColor = Color.DarkRed;
		
		if(statusCode >= 500)
			cellStyle.BackColor = Color.DarkRed;
		else if(statusCode >= 400)
		{
			cellStyle.BackColor = Color.Orange;
			cellStyle.ForeColor = Color.Black;
		}	
		else if(statusCode >= 300)
			cellStyle.BackColor = Color.Blue;
					
		base.Paint(g, clipBounds, cellBounds, rowIndex, cellState, value, formattedValue, errorText, cellStyle, abs, paintParts);
	}
}

public class RequestEvent : EventArgs
{
	public DateTime Timestamp {get;set;}
	public HttpMethod Method {get;set;}
	public string Path {get;set;}
	public string ContentType {get;set;}
	public int StatusCode {get;set;}
	public string Reason {get;set;}
	public int Took {get;set;}
	public string QueryString {get;set;}
	
	public string RequestBody {get;set;}
	public string ResponseBody {get;set;}
	
	public Guid SessionID {get;set;}
	
	public DataTable RequestHeaders {get;set;}
	public DataTable ResponseHeaders {get;set;}
	public DataTable RequestProperties {get;set;}
	
	public bool ResponseIsJSON {get;set;}
	
	public int ResponseSize {get;set;}
}


public class DiagnosticHandler : DelegatingHandler
{
	
	public EventHandler<RequestEvent> Request;
	
	protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
	{
		var start = DateTime.Now;
		
		var requestEvent = new RequestEvent();

		if(request.Content != null)
			requestEvent.RequestBody = await request.Content.ReadAsStringAsync();
			
		var sessionIDName = "SessionID";
		var sessionCookie = request.Headers.GetCookies(sessionIDName).FirstOrDefault();
		Guid sessionGUID;
		if(sessionCookie == null || Guid.TryParse(sessionCookie.ToString().Replace(sessionIDName + "=", ""), out sessionGUID) == false)
			sessionGUID = Guid.NewGuid();
		
		request.Properties[sessionIDName] = sessionGUID;
		requestEvent.SessionID = sessionGUID;

		//Handle the request
		var response = await base.SendAsync(request, ct);
		
		if(request.Method != HttpMethod.Get)
			response.Headers.AddCookies(new CookieHeaderValue[] {
				new CookieHeaderValue(sessionIDName, requestEvent.SessionID.ToString())
			});
			
		
		//Handle NotFound and loading web pages and resources
		if(response.StatusCode == HttpStatusCode.NotFound)
		{
			try
			{
				var path = request.RequestUri.AbsolutePath;
				if(path == "/")
					path = "index.html";

				var content = File.ReadAllText(path.TrimStart('/'));
				response.Content = new StringContent(content);

				var contentType = "text/html";
				if(path.Contains("/js/") || path.Contains(".js"))
					contentType = "application/js";
				else if(path.Contains("/css/") || path.Contains(".css"))
					contentType = "text/css";
				else if(path.Contains("/images/"))
				{
					contentType = "image/jpeg";
					if(path.EndsWith("png"))
						contentType = "image/png";
					else if(path.EndsWith("gif"))
						contentType = "image/gif";

					response.Content = new ByteArrayContent(File.ReadAllBytes(path.TrimStart('/')));
				}

				if(contentType == "text/html")
				{
					//Add OnError logging
					content = content.Replace("</head>", strOnError);
					//Add Custom error logging pane to page
					content = content.Replace("<!--Logging-->", strLogging);
					content = content.Replace("?vary=always", "?vary=" + DateTime.Now.Ticks);
					response.Content = new StringContent(content);
				}

				response.Content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
				response.Headers.CacheControl = new CacheControlHeaderValue() {
					NoCache = true,
					MaxAge = TimeSpan.FromSeconds(1)
				};
				response.Headers.ETag = new EntityTagHeaderValue("\"" + DateTime.Now.Ticks.ToString() + "\"");
				response.StatusCode = HttpStatusCode.OK;
			}
			catch(DirectoryNotFoundException dnfe){}
			catch(FileNotFoundException fnfe){}
			catch(UnauthorizedAccessException uae) {}
			catch(Exception c)
			{
				Console.WriteLine("Error:" + c);
				response.StatusCode = HttpStatusCode.InternalServerError;
			}
		}
		var end = DateTime.Now;

		if(response.Content != null)
			requestEvent.ResponseBody = await response.Content.ReadAsStringAsync();
			
		if(requestEvent.ResponseBody != null)
			requestEvent.ResponseSize = requestEvent.ResponseBody.Length;

		if(!string.IsNullOrEmpty(requestEvent.ResponseBody) && requestEvent.ResponseBody.Length > 1000)
			requestEvent.ResponseBody = requestEvent.ResponseBody.Substring(0, 995);
	
		
		requestEvent.Timestamp = start;
		requestEvent.Method = request.Method;
			
		var reqContentType = request.Content.Headers.ContentType;
		var strContentType = "";
		if(reqContentType != null)
			strContentType = reqContentType.ToString();
		
		requestEvent.ContentType = strContentType;
		requestEvent.Path = request.RequestUri.AbsolutePath;

		var statusCode = (int)response.StatusCode;
		if(statusCode == null)
			statusCode = 500;
				
		requestEvent.StatusCode = statusCode;
		requestEvent.Reason = response.ReasonPhrase;

		TimeSpan took = end - start;
		requestEvent.Took = (int)took.TotalMilliseconds;
		requestEvent.QueryString = request.RequestUri.Query;
		
		requestEvent.RequestHeaders = new DataTable();
		requestEvent.RequestHeaders.Columns.Add("Header");
		requestEvent.RequestHeaders.Columns.Add("Value");
		foreach(var rh in request.Headers)
			requestEvent.RequestHeaders.Rows.Add(new[] { rh.Key, rh.Value.FirstOrDefault() });
			
		requestEvent.RequestProperties = new DataTable();
		requestEvent.RequestProperties.Columns.Add("Key");
		requestEvent.RequestProperties.Columns.Add("Value");
		foreach(var rp in request.Properties)
			requestEvent.RequestProperties.Rows.Add(new[] { rp.Key, rp.Value.ToString() });
		
		requestEvent.ResponseHeaders = new DataTable();
		requestEvent.ResponseHeaders.Columns.Add("Header");
		requestEvent.ResponseHeaders.Columns.Add("Value");
		foreach(var rh in response.Headers)
			requestEvent.ResponseHeaders.Rows.Add(new[] { rh.Key, rh.Value.FirstOrDefault() });
			
		//lock(semaphore)
		//	requests.Add(requestEvent);
		Request(this, requestEvent);

		return response;
	}

	private readonly string strOnError = @"
	<script type=""text/javascript"">
		window.onerror = function(error, file, line, col) {
			console.log(""<strong>"" + error + ""</strong><br>"" + file.replace(""http://localhost:12345"", """") + ' @ ' + line + ':' + col, 'danger');
		}
	</script>
</head>";

	private readonly string strLogging =  @"
	<script type=""text/javascript"">
		var old = console.log;
		document.write(""<div class='shadow-lg rounded' style='font-size: .9em; width: 300px; z-index: 100; position: fixed; bottom: 0px; right: 0px;'><ul class='list-group' id='ulLogging'></ul></div>"");
		console.log = function(message, type) {
			var m = message;
			if(typeof(message) == 'object')
				m = JSON.stringify(message);

			$('#ulLogging').append(""<li class='list-group-item "" +( type ? ""list-group-item-"" + type : """") + "" p-2'>"" + m + ""</li>"");
		};
	</script>";
}

﻿using System;
using System.Web.Http;

[RoutePrefix("lesson9")]
public class Lesson9Controller : ApiController
{
}

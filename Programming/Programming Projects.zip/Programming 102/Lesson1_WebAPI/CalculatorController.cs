﻿using System;
using System.Web.Http;

//route prefix "lesson1"
//class definition

//Routes inside class
//Add			GET  /lesson1/add/{xVal}/{yVal}
//Subtract		POST /lesson1/subtract?xVal=###&yVal=###
//Divide		GET  /lesson1/divide/{xVal}?yVal=###
//Multiply		POST /lesson1/multiply 	xVal & yVal from Body as CSV  Remember how to handle CSV?
//String Length	POST	/lesson1/length	string loaded from Body
//Square Root	your choice


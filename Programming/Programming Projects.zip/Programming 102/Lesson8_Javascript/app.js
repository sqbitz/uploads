﻿$(document).ready(function() {
	console.log("Loaded!");	
});

﻿using System;
using System.Web.Http;

[RoutePrefix("lesson5")]
public class DatabaseController : ApiController
{
	
}

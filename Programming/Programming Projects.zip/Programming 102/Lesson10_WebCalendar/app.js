﻿$(document).ready(function() {
	console.log("Loaded!");	
	
	$("#txtAutoComplete").keyup(function() {
		$("#drpAutoComplete").empty();
		$.get("/lesson10/autocomplete?q=" + $(this).val(), function(data) {
			$.each(data, function(index, value) {
				$("#drpAutoComplete").append(`<a class="dropdown-item" href="#">${value}</a>`);	
			});
			$("#drpAutoComplete").dropdown("show");
		});
	});
});

﻿using System;
using System.Diagnostics;
using System.Text;
using System.IO;
using System.Collections.Generic;
using Newtonsoft.Json;

public class Run
{
	public static void Main()
	{	
		using(var atm = new ATM())
			atm.Run();
	}
}

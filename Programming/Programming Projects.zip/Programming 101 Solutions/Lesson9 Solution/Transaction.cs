﻿using System;
using System.Diagnostics;
using System.Text;
using System.IO;

public class Transaction
{
	public Transaction()
	{
	
	}
		
	public DateTime Timestamp { get; private set; }
	public decimal Amount { get; private set;}
	public decimal AccountBalance {get; private set;}
	
	protected Transaction(decimal amount, decimal newBalance) {
		Timestamp = DateTime.Now;
		Amount = amount;
		AccountBalance = newBalance;
	}
}

public class Withdrawal : Transaction
{
	public Withdrawal(decimal amount, decimal newBalance) : base(amount, newBalance)
	{}
	
	public string ToString() {
		return "Withdrawal: " + Amount.ToString("c");
	}
}

public class Deposit : Transaction
{
	public Method Method {get; private set;}
	 
	public Deposit (decimal amount, decimal newBalance, Method source) : base(amount, newBalance)
	{
		Method = source;
	}
	
	public string ToString() {
		return "Deposit: " + Amount.ToString("c") + " via " + Method;
	}
}

public enum Method { Cash, Credit, Check, Transfer };

public class TransferOut : Withdrawal
{
	public string DestinationAccount;
	public TransferOut(decimal amount, decimal newBalance, string destinationAccount) : base(amount, newBalance)
	{
		DestinationAccount = destinationAccount;
	}
	
	public string ToString() {
		return "TransferOut: " + Amount.ToString("c") + " to " + DestinationAccount;
	}
}

public class TransferIn : Deposit
{
	public string SourceAccount { get; private set;} 
	public TransferIn(decimal amount, decimal newBalance, string sourceAccount) : base(amount, newBalance, Method.Transfer)
	{
		SourceAccount = sourceAccount;
	}
	
	public string ToString() {
		return "TransferIn: " + Amount.ToString("c") + " to " + SourceAccount;
	}
}

﻿using System;
using System.Diagnostics;
using System.Text;
using System.IO;
using System.Collections.Generic;

public class ATM : IDisposable
{
	private Dictionary<string, Account> accounts = new Dictionary<string, Account>();
	private string filename = "accounts.csv";
	private string headerLine;
	private StreamWriter transactionLog;

	public ATM()
	{
		var lines = File.ReadAllLines(filename);
		headerLine = lines[0];
		
		//Skip the header line
		for(var i = 1; i < lines.Length; i++)
		{
			var split = lines[i].Split(',');
			var acct = new Account(split[0], split[1], split[2], split[3]);
			accounts[split[0]] = acct;
		}
		
		Console.WriteLine("Loaded {0} accounts", accounts.Count);
		transactionLog = new StreamWriter("transactions.log");
	}
	
	public void Run()
	{
		while(true)
		{
			drawInterface();
			Console.Write("Please enter your account number and press <Enter>: ");
			var acctNum = Console.ReadLine();
	
			if(!accounts.ContainsKey(acctNum))
			{
				drawInterface();
				Console.ForegroundColor = ConsoleColor.Red;
				write("Unable to find account.  Please try again.");
				Console.ReadLine();
				continue;
			}
			
			var acct = accounts[acctNum];
			write("Please enter your account PIN and press <Enter>:    ");
			var pin = Console.ReadLine();
			var match = acct.CheckPIN(pin);
			if(!match)
			{
				drawInterface();
				write("PIN Didn't Match!", ConsoleColor.Red);
				Console.ReadLine();
				continue;
			}
			
			handleAccount(acct);			
		}
	}
	
	private void handleAccount(Account account)
	{
		while(true)
		{
			drawInterface();
			writeLine("Welcome!  Your balance is " + account.Balance.ToString("c") + ".");
			writeLine("");
			writeLine("Press the number for the option you want.");
			writeLine("1.  Deposit");
			writeLine("2.  Withdraw");
			writeLine("3.  Transfer");
			writeLine("4.  Show Transactions");
			writeLine("5.  Exit");
			var option = Console.ReadLine();
			
			if(option == "1")
			{
				write("How much do you want to deposit? ");
				var amt = decimal.Parse(Console.ReadLine().Replace("$", "").Trim());
				writeLine("How do you want to fund this deposit?");
				writeLine("1.  Check");
				writeLine("2.  Cash");
				var method = Console.ReadLine();
				handleDeposit(account, amt, method == "1" ? Method.Check : Method.Cash);
			}		
			else if(option == "2")
			{
				writeLine("How much do you want to withdraw? ");
				var amt = decimal.Parse(Console.ReadLine().Replace("$", "").Trim());
				handleWithdrawal(account, amt);
			}
			else if(option == "3")
			{
				write("Enter the amount to transfer: ");
				var amt = decimal.Parse(Console.ReadLine().Replace("$", "").Trim());
				write("Enter the account number to transfer " + amt.ToString("c") + " to: ");
				var acct = Console.ReadLine();
				if(!accounts.ContainsKey(acct))
				{
					writeLine("Could not find account!", ConsoleColor.Red);
					Console.ReadLine();
					continue;
				}
				
				handleTransfer(account, accounts[acct], amt);
			}
			else if(option == "4")
				account.ShowTransactions();
			else if(option == "5")
			{
				writeLine("Thank you for banking with us!");
				System.Threading.Thread.Sleep(2000);
				return;
			}
		}
	}
	
	private void handleDeposit(Account account, decimal amount, Method source)
	{
		account.Deposit(amount, source);
		transactionLog.WriteLine("{0},{1},{2:MMddyyyyHHmm},{3:c},{4:c}", account.AccountNumber, "deposit", DateTime.Now, account.Balance, amount);
		transactionLog.Flush();
	}
	
	private void handleWithdrawal(Account account, decimal amount)
	{
		try
		{
			account.Withdraw(amount);
			transactionLog.WriteLine("{0},{1},{2:MMddyyyyHHmm},{3:c},{4:c}", account.AccountNumber, "widthdrawal", DateTime.Now, account.Balance, amount);
			transactionLog.Flush();
		}
		catch(Exception c)
		{
			writeLine("Error Withdrawing: " + c.Message, ConsoleColor.Red);
			Console.ReadLine();
		}
	}
	
	private void handleTransfer(Account source, Account dest, decimal amount)
	{
		try
		{
			source.Withdraw(amount);
			transactionLog.WriteLine("{0},{1},{2:MMddyyyyHHmm},{3:c},{4:c}", source.AccountNumber, "transferOut", DateTime.Now, source.Balance, amount);
			transactionLog.Flush();
			dest.Deposit(amount, Method.Transfer);
			transactionLog.WriteLine("{0},{1},{2:MMddyyyyHHmm},{3:c},{4:c}", dest.AccountNumber, "transferIn", DateTime.Now, dest.Balance, amount);
			transactionLog.Flush();
		}
		catch(Exception c)
		{
			writeLine("Error Withdrawing: " + c.Message, ConsoleColor.Red);
			Console.ReadLine();
			return;
		}
	}
	
	private void write(string s, ConsoleColor color)
	{
		Console.ForegroundColor = color;
		Console.SetCursorPosition(20, Console.CursorTop);
		Console.Write(s);
		Console.ResetColor();
	}
	
	private void write(string s)
	{
		write(s, ConsoleColor.White);
	}
	
	private void writeLine(string s, ConsoleColor color)
	{
		write(s, color);
		Console.WriteLine();
		Console.SetCursorPosition(20, Console.CursorTop);
	}
	
	private void writeLine(string s)
	{
		writeLine(s, ConsoleColor.White);
	}
	
	private void drawInterface()
	{
		Console.Clear();
		Console.ResetColor();
		Console.SetCursorPosition(4,3);
		//Console.Write("??????");
		for(var i = 4; i < Console.WindowWidth - 5; i++)
			Console.Write("=");
		Console.WriteLine();
		
		for(var i = 3; i < Console.WindowHeight - 6; i++)
		{
			Console.Write("    |");
			Console.SetCursorPosition(Console.WindowWidth - 6, Console.CursorTop);
			Console.WriteLine("|");
		}
		
		Console.Write("    ");
		for(var i = 4; i < Console.WindowWidth - 5; i++)
			Console.Write("=");
			
		
		Console.SetCursorPosition(20, 6);
		Console.ForegroundColor = ConsoleColor.Green;
		Console.Write("Welcome to RAATM");
		
		setCursorPos();
		Console.ResetColor();
	}
	
	private void setCursorPos()
	{
		Console.SetCursorPosition(20, 10);
	}	
		
 	public void Dispose()
	{
		transactionLog.Dispose();
	}
}

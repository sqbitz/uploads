﻿using System;
using System.Diagnostics;
using System.Text;
using System.IO;
using System.Collections.Generic;

public class Account
{
	private string pin;

	public string AccountNumber { get; set; }
	public DateTime LastLogin { get; set; }
	public decimal Balance { get; set; }
	
	public List<Transaction> Transactions {get; private set;}
	
	public Account()
	{
	}
	
	public Account(string accountNum, string PIN, string lastLogin, string currBalance)
	{
		AccountNumber = accountNum;
		LastLogin = DateTime.Parse(lastLogin);
		Balance = decimal.Parse(currBalance);
		
		pin = PIN;
		Transactions = new List<Transaction>();
	}
	
	public bool CheckPIN(string PIN)
	{
		return PIN == pin;
	}
	
	public decimal Withdraw(decimal amount)
	{
		if(Balance - amount < 0)
			throw new Exception("Insufficient Funds");
		
		Balance = Balance - amount;
			
		Transactions.Add(new Withdrawal(amount, Balance));
		
		return Balance;
	}
	
	public decimal Deposit(decimal amount, Method source)
	{
		Balance = Balance + amount;
		
		Transactions.Add(new Deposit(amount, Balance, source));
		return Balance;
	}
	
	public void ShowTransactions()
	{
		foreach(var t in Transactions)
			Console.WriteLine(t.ToString());
			
		Console.ReadLine();
	}
}

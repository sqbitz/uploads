﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class LabDay
{
	public static void Main()
	{
		var intArr = new int[] { 5,2,1,4,1,7,8,0,9,3,1 };
		var strArr = new string[] { "Jack", "Chris", "Luke", 
													"James", "Jo", "B" };
		
		//All() - Returns true if ALL elements match predicate
		bool all = intArr.All(x => x < 10);
		
		//Average() - Calculates the average of the input
		double avg = intArr.Average();
		double strLenAvg = strArr.Average(x => x.Length);
		
		//Count() - Counts elements
		int simpleCount = intArr.Count();
		int predCount = intArr.Count(x => x > 4);
		
		//Distinct() - Returns a list of unique values
		var intArrDistinct = intArr.Distinct();

		//OrderBy - Returns the list sorted by value
		var ordered = intArr.OrderBy(x => x);
		var distinctOrdered = intArr.Distinct()
													.OrderBy(x => x);

		//Sum() - Calculates the Sum
		var sum = intArr.Sum();
		var predSum = intArr.Sum(x => x * 2 + 3);
		
		//Where - Returns a filtered list by predicate
		var filtered = strArr.Where(x => x.Length > 2 
															&& x.StartsWith("J"));
		
		//Lets go crazy :-)
		var crazy = strArr.Sum(x => {
			if(x.Contains("Ja"))
				return 5;
			if(x.Length == 1)
				return 20;
			
			return x.Length;
		});


		Console.WriteLine("All:            " + all);
		Console.WriteLine("Average:        " + avg);
		Console.WriteLine("Str Avg:        " + strLenAvg);
		Console.WriteLine("Count:          " + simpleCount);
		Console.WriteLine("Pred Count:     " + predCount);
		Console.WriteLine("Distinct:       " + string.Join(",", intArrDistinct));
		Console.WriteLine("Ordered:        " + string.Join(",", ordered));
		Console.WriteLine("Distinct Order: " + string.Join(",", distinctOrdered));
		Console.WriteLine("Sum:            " + sum);
		Console.WriteLine("Pred Sum:       " + predSum);
		
		Console.WriteLine("Filtered:       " + string.Join(",", filtered));
		Console.WriteLine("Crazy Sum:      " + crazy);

			
		
		
		
		
		
		
		
		var intArray = new int[] { 25, 32, 1, -19, 22, 112, 49 };
		var strArray = new string[] { "Word", "PowerPoint", "Excel", 
							"Outlook", "OneNote" };
							
		var count = strArray.Sum(x => x.Count(y => char.IsUpper(y)));
		var count2 = intArray.Count(x => x < 30);
		
		var any = strArray.Any(x => x.Length > 4 && x.Substring(1).StartsWith("o"));
		var show = strArray.FirstOrDefault(x => x.Length > 4 && x.Substring(1).StartsWith("o"));
		
		Console.WriteLine("Num UpperCase:       " + count);
		Console.WriteLine("Num < 30:            " + count2);
		Console.WriteLine("Any 2nd letter o:    " + any);
		Console.WriteLine("1st w/ 2nd letter o: " + string.Join(",", show));
		
		Console.ReadLine();
		
	}
}

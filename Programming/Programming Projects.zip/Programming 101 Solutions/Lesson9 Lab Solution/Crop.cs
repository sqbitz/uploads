using System;
using System.Collections.Generic;

public class Crop
{
	public Crop(decimal acrePurchaseCost, DateTime planted)
	{
		AcrePurchaseCost = acrePurchaseCost;
	
	}
	
	public decimal AcrePurchaseCost {get;protected set;}
	public decimal AcreDailyMaintenanceCost;
	
	public int MonthsToMaturity {get; protected set;}
	
	public DateTime PlantedDate {get; protected set;}
	public DateTime HarvestDate 
	{ 
		get 
		{ 
			return PlantedDate.AddMonths(MonthsToMaturity); 
		}
	}
}

public interface IGrain {}
public interface IVegetable {}
public interface IFruit {}
public interface ICashCrop {}

public class Strawberry : Crop, IFruit, ICashCrop 
{
	public Strawberry(decimal acrePurchaseCost, DateTime planted) : base(acrePurchaseCost, planted)
	{
		MonthsToMaturity = 6;
		AcreDailyMaintenanceCost = 5;
	}
}

public class Wheat : Crop, IGrain 
{
	public Wheat(decimal acrePurchaseCost, DateTime planted) : base(acrePurchaseCost, planted)
	{
		MonthsToMaturity = 3;
		AcreDailyMaintenanceCost = 0.7m;
	}
}

public class Tobacco : Crop, ICashCrop
{
	public Tobacco(decimal acrePurchaseCost, DateTime planted) : base(acrePurchaseCost, planted)
	{
		MonthsToMaturity = 24;
		AcreDailyMaintenanceCost = 2;
	}
}
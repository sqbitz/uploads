using System;
using System.Collections.Generic;

public class Animal
{
	public decimal PurchasePrice;
	public decimal DailyMaintenanceCost;
	
	public DateTime BirthDate;
	public DateTime PurchaseDate;
	
	public decimal CalculateCost()
	{
		var days = (DateTime.Now - BirthDate).TotalDays;
		return PurchasePrice + (DailyMaintenanceCost * (decimal)days);
	}
	
	public Animal(decimal purchase, decimal maint, DateTime birth, DateTime purchased)
	{
		PurchasePrice = purchase;
		DailyMaintenanceCost = maint;
		
		PurchaseDate = purchased;
		BirthDate = birth;
	}
	
	public decimal Weight {get;set;}
}

public class Cow : Animal, IButcherable, IMilkable
{
	public Cow(decimal purchase, decimal maint, DateTime birth, DateTime purchased) : base(purchase, maint, birth, purchased)
	{
		lastMilking = DateTime.MinValue;
	}
	
	public decimal SalePricePerPound { get; set; }
	public bool WasButchered { get; private set; }
	public decimal CalculateProfit()
	{
		return (WasButchered ? (SalePricePerPound * Weight) : 0) 
					- CalculateCost();
	}
	
	public void Butcher(decimal salePrice)
	{
		WasButchered = true;
		SalePricePerPound = salePrice;
	}
	
	private DateTime lastMilking;
	public bool TryMilk()
	{
		if((DateTime.Now - lastMilking).TotalHours < 5)
			return false;
			
		lastMilking = DateTime.Now;
		return true;
	}
}

public class Horse : Animal
{
	public Horse(decimal purchase, decimal maint, DateTime birth, DateTime purchased) : base(purchase, maint, birth, purchased)
	{
	
	}
	public decimal Hands {get;set;}
}

public class Sheep : Animal, IButcherable
{
	private List<Sheering> sheerings;
	public Sheep(decimal purchase, decimal maint, DateTime birth, DateTime purchased) : base(purchase, maint, birth, purchased)
	{
		sheerings = new List<Sheering>();
	}
	
	public void AddSheering(DateTime time, decimal lbsProduced, decimal salePrice)
	{
		sheerings.Add(new Sheering() { Timestamp = time, LbsProduced = lbsProduced, SalePrice = salePrice });
	}


	public decimal SalePricePerPound {get; private set;}
	public decimal CalculateProfit()
	{
		decimal profit = 0;
		foreach(var s in sheerings)
			profit += s.SalePrice;
			
		if(WasButchered)
			profit += (SalePricePerPound * Weight);
			
		profit -= CalculateCost();
			
		return profit;
	}
	public bool WasButchered {get; private set;}
	
	public void Butcher(decimal salePrice)
	{
		WasButchered = true;
		SalePricePerPound = salePrice;
	}

	
	public List<Sheering> Sheerings {
		get { 
			return sheerings; 
		}
	}	
	
	public class Sheering {
		public DateTime Timestamp {get;set;}
		public decimal LbsProduced {get;set;}
		public decimal SalePrice {get;set;}
	}
}

public class Chicken : Animal
{
	public Chicken(decimal purchase, decimal maint, DateTime birth, DateTime purchased) : base(purchase, maint, birth, purchased)
	{}
	
	public decimal SalePrice {get;set;}
	public decimal CalculateProfit()
	{
		return ProfitFromEggs + SalePrice - CalculateCost();
	}
	
	public int NumEggsLayed { get;set;}
	public decimal ProfitFromEggs {get;set;}
}

public interface IHasProfit
{
	decimal CalculateProfit();
}

public interface IButcherable : IHasProfit
{
	decimal Weight { get; set;}
	decimal SalePricePerPound { get; }
	bool WasButchered { get; }
	
	void Butcher(decimal pricePerPound);
}

public interface IMilkable
{
	//returns true if milked successfully
	bool TryMilk();
}





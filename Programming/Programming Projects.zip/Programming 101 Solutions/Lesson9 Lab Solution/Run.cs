using System;
using System.Collections.Generic;

public class Run
{
	public static void Main()
	{		
		var rand = new Random();	
		
		var f = new Farm("OK Corral", "123 Main");
		f.Locations.Add(new House());
		
		var oldBarn = new Barn();
		oldBarn.Stalls.Add(new Barn.Stall(1));
		oldBarn.Stalls.Add(new Barn.Stall(2));
		f.Locations.Add(oldBarn);
		
		var newBarn = new Barn();
		for(var i = 0; i < 5; i++)
			newBarn.Stalls.Add(new Barn.Stall(1));
		f.Locations.Add(newBarn);
			
		var wheatField = new Field() { 
			Crop = new Wheat(5.0m, DateTime.Now.AddYears(-1)),
			Acres = 20 
		};
		f.Locations.Add(wheatField);
		
		var tobaccoField = new Field() { 
			Crop = new Tobacco(0.25m, DateTime.Now.AddDays(-50)),
			Acres = 100 
		};
		f.Locations.Add(tobaccoField);
		
		var cowPen = new Pen();
		for(var i = 0; i < 200; i++)
			cowPen.Animals.Add(new Cow(i, .3m, DateTime.Now.AddYears(-2), DateTime.Now.AddYears(-1)));
		f.Locations.Add(cowPen);
		
		foreach(IButcherable c in cowPen.Animals)
		{
			var n = rand.Next(1000, 1555);
			c.Weight = n;
			
			n = rand.Next(0, 1);
			if(n >.5)
				c.Butcher(rand.Next(500, 1000));	
		}
		
		var sheepPen = new Pen();
		for(var i = 0; i < 50; i++)
			sheepPen.Animals.Add(new Sheep(i, .2m, DateTime.Now.AddYears(-2), DateTime.Now.AddDays(-400)));
		
		foreach(Sheep s in sheepPen.Animals)
		{
			var n = rand.Next(0, 10);
			for(int i = 0; i < n; i++)
				s.AddSheering(DateTime.Now, rand.Next(1, 10), rand.Next(50, 90));
				
			s.Weight = rand.Next(50, 100);
			
			n = rand.Next(0, 1);
			if(n >.8)
				s.Butcher(rand.Next(100, 500));
		}
		f.Locations.Add(sheepPen);
			
		var crops = new List<Crop>();
		crops.Add(new Strawberry(5.00m, new DateTime(2020, 1, 1)));
		crops.Add(new Wheat(30.00m, new DateTime(2020, 5, 24)));
		crops.Add(new Tobacco(2.00m, new DateTime(2019, 12, 1)));
		var numFruit = 0;
		foreach(var c in crops)
		{
			if(c is IFruit)
				numFruit++;
		}
		Console.WriteLine(numFruit + " fruit crops planted");
				
		decimal totalCost = 0;
		decimal totalProfit = 0;
		foreach(var l in f.Locations)
		{
			if(l is Pen)
			{
				var p = l as Pen;
				foreach(var a in p.Animals)
				{
					totalCost += a.CalculateCost();
					var hasProfit = a as IHasProfit;
					if(hasProfit != null)
						totalProfit += hasProfit.CalculateProfit();
					
				}
			}
			else if(l is Field)
			{
				var fi = l as Field;
			}
			else if(l is Barn)
			{
				var b = l as Barn;
				
			}
		}
		
		Console.WriteLine("Profit: " + totalProfit.ToString("c"));
		Console.WriteLine("Cost: " + totalCost.ToString("c"));
		
		var sheep = new Sheep(100, 0.50m, DateTime.Now.AddYears(-2), DateTime.Now.AddDays(100));
		sheep.Weight = 100;
		sheep.AddSheering(DateTime.Now, 100, 200);
		sheep.AddSheering(DateTime.Now, 50, 100);
		sheep.Butcher(30);
		
		Console.WriteLine("Cost:   " + sheep.CalculateCost().ToString("c"));
		Console.WriteLine("Profit:  " + sheep.CalculateProfit().ToString("c"));

		Console.ReadLine();		
	}
}
﻿using System;
using System.Diagnostics;
using System.Text;
using System.IO;

public class Review
{
	public static void Main()
	{
		
		
		using(var rdr = new StreamReader("config.txt"))
			while(!rdr.EndOfStream)
			{
				var line = rdr.ReadLine();
				var split = line.Split('=');
				if(split[0] == "file")
					filesToLoad.Add(split[1]);
				else if(split[0] == "level")				
					level = int.Parse(split[1]);
				else if(split[0] == "projectType")
					projectType = split[1];
				else if(split[0] == "reference")
					referenceDLLs.Add(split[1]);
			}
			
		
		
		
			Console.SetCursorPosition(lastLocation.Left + 1, 
							lastLocation.Top + 1);
											
			for(var i = 0; i < 3; i++)
			{
				Console.CursorLeft = lastLocation.Left;
				var write = "---";
				
				if(lastFacing == Direction.Up 
						|| lastFacing == Direction.Down)
					write = "------";
	
				Console.WriteLine(write);
			}		
					
					
					
			Console.ForegroundColor = ConsoleColor.DarkRed;
			string message = "  Hit for " + attackPoints;
			if(attackPoints == 0)
			{
				Console.ForegroundColor = ConsoleColor.Green;
				message = "   Attack Missed!";		
			}
			Console.WriteLine(message);	
			
			
			
			Console.SetCursorPosition(7, 25);
			foreach(var m in messages)
			{
				Console.ForegroundColor = m.Color;
				Console.CursorLeft = 7;
				Console.WriteLine(m.Text.PadRight(23));
			}
	
			Console.ResetColor();	
				
				
				
			var tName = "System.IO.File";
	
			if(tName.Contains("."))
					tName = tName.Substring(tName.LastIndexOf(".") + 1);
					
			Console.WriteLine(tName);
			
			
			
		int remainingRooms = 10;
		var DDRandom = new Random();
		while(remainingRooms > 0)
		{
			var numDoors = DDRandom.Next(0, 4);
			Console.WriteLine("new room with " + numDoors);
			remainingRooms--;
		}
		
			var Lines = new string[5];
			var currentLineIndex = 0;
			bool typedIsLetterDigitPeriod;
			char typedChar;
		
		
			string c = Lines[currentLineIndex];
			if(typedIsLetterDigitPeriod)
			{
				var indexOfNew = c.IndexOf(" new ");
				if(indexOfNew >= 0)
				{
					string typeName = c.Substring(indexOfNew + 5) + typedChar;
					Console.WriteLine("typeName: " + typeName);
				}
			}		
					
					
		
		var year = int.Parse(Console.ReadLine());
		var firstDay = new DateTime(year, 1, 1);
		var lastDay = firstDay.AddYears(1).AddDays(-1.0);
		
		var start = firstDay;
		while(start.DayOfWeek != DayOfWeek.Monday)
			start = start.AddDays(-1);
			
		var end = lastDay;
		while(end.DayOfWeek != DayOfWeek.Sunday)
			end = end.AddDays(1);			
		
		Console.WriteLine("Start: " + start);
		Console.WriteLine("End:   " + end);
					
	}
}

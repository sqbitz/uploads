using System;
using System.Collections.Generic;

public class Run
{
	public static void Main()
	{	
		var normalCourse = new Course("CS101");
		
		Console.WriteLine(normalCourse.Name);
	}
}
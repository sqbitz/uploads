using System;
using System.Collections.Generic;

public class Collections
{
	public static void Main()
	{
		var l = new List<int>();
		int num;
		do
		{
			num = int.Parse(Console.ReadLine());
			l.Add(num);
		}while(num != 0);
	
		foreach(var i in l)
			Console.Write(i + " ");
	
		Console.ReadLine();
	
		Console.Write("Enter a number to add: ");
		num = int.Parse(Console.ReadLine());
	
		Console.WriteLine("Adding " + num + " to each item");
		var bl = new List<bool>();
		foreach(var i in l)
		{
			i += num;
			bl.Add(i >= 50);
		}
	
		for(var i = 0; i < l.Count; i++)
			Console.WriteLine(arr[i].ToString().PadRight(5)
					+ bl[i]);
	}
}
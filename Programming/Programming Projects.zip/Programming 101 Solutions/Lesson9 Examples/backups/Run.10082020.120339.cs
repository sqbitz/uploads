using System;
using System.Collections.Generic;

public class Run
{
	public static void Main()
	{	
		
		var bar = new List<IEnumerable<string>>();
		bar.Add(new [] { "asdf", "zxcv" });
		bar.Add(new List<string>());
		
		var a = bar[1] as List<string>;
		Console.WriteLine(a == null);
		Console.ReadLine();

		
		var cs101 = new SchoolCourse("CS101");		
		cs101.AddStudent("Jack");
		cs101.AddStudent("James		");
		var numStudents = cs101.AddStudent("James");
		
		var enrolled1 = cs101.IsEnrolled("Susan");
		var enrolled2 = cs101.IsEnrolled("James");
		
		Console.WriteLine(cs101.Name + "   " + numStudents + " Students     Susan Enrolled? " + enrolled1 + "        James Enrolled? " + enrolled2);
		
		
		var cs200 = new SchoolCourse() {
			Name = "CS200"
		};
		cs200.Name = "CS200-1";
		numStudents = cs200.AddStudent("Jack");
		
		enrolled1 = cs200.IsEnrolled("Susan");
		enrolled2 = cs200.IsEnrolled("James");
		
		Console.WriteLine(cs200.Name + " " + numStudents + " Students     Susan Enrolled? " + enrolled1 + "        James Enrolled? " + enrolled2);
		
		
		var math300 = new MathCourse("Math300");
		math300.AddStudent("Amber");
		math300.AddStudent("Joe");
		math300.AddStudent("Jack");
		numStudents = math300.AddStudent("James");
		
		enrolled1 = math300.IsEnrolled("Susan");
		enrolled2 = math300.IsEnrolled("James");
		
		Console.WriteLine(math300.Name + " " + numStudents + " Students     Susan Enrolled? " + enrolled1 + "        James Enrolled? " + enrolled2);
		foreach(var s in math300.GetStudents())
			Console.WriteLine("   " + s);

		
		Console.ReadLine();
	}
}
using System;
using System.Collections.Generic;

public class Run
{
	public static void Main()
	{	
		var cs101 = new SchoolCourse("CS101");		
		cs101.AddStudent("Jack");
		cs101.AddStudent("James		");
		var numStudents = cs101.AddStudent("James");
		
		var enrolled1 = cs101.IsEnrolled("Susan");
		var enrolled2 = cs101.IsEnrolled("James");
		
		Console.WriteLine(cs101.Name + "   " + numStudents + " Students     Susan Enrolled? " + enrolled1 + "        James Enrolled? " + enrolled2);
		
		var cs200 = new SchoolCourse() {
			Name = "CS200"
		};
		cs200.Name = "CS200-1";
		numStudents = cs200.AddStudent("Jack");
		
		enrolled1 = cs200.IsEnrolled("Susan");
		enrolled2 = cs200.IsEnrolled("James");

		Console.WriteLine(cs200.Name + " " + numStudents + " Students     Susan Enrolled? " + enrolled1 + "        James Enrolled? " + enrolled2);

		
		Console.ReadLine();
	}
}
using System;
using System.Collections.Generic;

public class SchoolCourse
{
	public string Name;
	public List<string> Students;
	
	public SchoolCourse(string courseName)
	{
		Name = courseName;
		Students = new List<string>();
	}
}
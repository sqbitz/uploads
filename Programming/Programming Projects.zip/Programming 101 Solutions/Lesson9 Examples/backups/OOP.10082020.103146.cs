using System;
using System.Collections.Generic;

public class SchoolCourse
{
	public string Name;
	protected HashSet<string> students;
	
	public SchoolCourse()
	{
		students = new HashSet<string>();
	}
	
	public SchoolCourse(string courseName)
	{
		Name = courseName;
		students = new HashSet<string>();

	}
	
	//Returns the number of students in the class
	public int AddStudent(string studentName)
	{
		students.Add(studentName);
		return students.Count;
	}
	
	//Returns  true  if the student is enrolled
	public bool IsEnrolled(string studentName)
	{
		return students.Contains(studentName);
	}
}

public class MathCourse : SchoolCourse
{
	public int GradeLevel;
	
	public MathCourse(string courseName)
	{
		super(courseName);
	}
}
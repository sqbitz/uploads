using System;
using System.Collections.Generic;

public class SchoolCourse
{
	public string Name;
	protected HashSet<string> students;
	
	public SchoolCourse(string courseName)
	{
		Name = courseName;
		Students = new HashSet<string>();
	}
	
	//Returns the number of students in the class
	public int AddStudent(string studentName)
	{
		Students.Add(studentName);
		return Students.Count;
	}
	
	//Returns  true  if the student is enrolled
	public bool StudentEnrolled(string studentName)
	{
		return Students.Contains(studentName);
	}
}

public class MathCourse : SchoolCourse
{
	public int GradeLevel;
}
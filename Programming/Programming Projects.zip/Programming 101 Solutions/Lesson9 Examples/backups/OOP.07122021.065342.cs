﻿using System;
using System.Collections.Generic;



public class ATM {
	private Dictionary<int, Account> accts;
	
	public ATM() {
		//Load the file 
		
		LoginLoop();
	}
	
	public void LoginLoop() {
		while(true) {
			//Display the welcome message
			//Display login prompt
			
			Console.WriteLine("Welcome!");
			Console.Write("Enter your acct number: ");
			var strAcctNum = Console.ReadLine();
			var acctNum = int.Parse(strAcctNum);

			if(accts.ContainsKey(acctNum))
			{
				var acct = accts[acctNum];
				
				Console.Write("Please enter your PIN: ");
				var strPin = Console.ReadLine();
				var intPin = int.Parse(strPin);
				
				var isAuthenticated = acct.Login(intPin);
				if(!isAuthenticated)
					continue;
					
				//Start Menu Loop
			}
			else {
				Console.WriteLine("Sorry... Account number doesn't exist...");
				Console.ReadLine();
			}
				
		}
	}
	
	public bool Save() {
		//write the storage to file
		
		return false;
	}
	
}

public class Account
{
	public int Number {get;set;}
	private int PIN;
	
	public decimal Balance {get; private set;}
	public DateTime DateOfLastTransaction {get; private set;}
	
	public Account(int acctNum, int pin, decimal currBalance, DateTime dolt) {
		Number = acctNum;
		PIN = pin;
		Balance = currBalance;
		DateOfLastTransaction = dolt;
	}
	
	public bool Login(int userEnteredPIN) {
		return userEnteredPIN == PIN;	
	}
}


























public class SchoolCourse
{
	public string Name;
	protected HashSet<string> students;
	
	public string DateString {
		get { 
			return DateTime.Now.ToShortDateString();
		}
	}
	
	public SchoolCourse()
	{
		students = new HashSet<string>();
		
		
		
		var bar = new List<IEnumerable<string>>();
		bar.Add(new[] { "Joe", "Jack" });
		bar.Add(new List<string>());
		
		
		
		
		
		
		
		
	}
	
	public SchoolCourse(string courseName)
	{
		students = new HashSet<string>();
		Name = courseName;
	}
	
	//Returns the number of students in the class
	public int AddStudent(string studentName)
	{
		students.Add(studentName);
		return students.Count;
	}
	
	//Returns  true  if the student is enrolled
	public bool IsEnrolled(string studentName)
	{
		return students.Contains(studentName);
	}
}

public class MathCourse : SchoolCourse
{
	public int GradeLevel;
	
	public MathCourse(string courseName) : base(courseName)
	{
	}
	
	public string[] GetStudents()
	{
		var ret = new string[students.Count];
		int i = 0;
		foreach(var s in students)
			ret[i++] = s;
			
		return ret;
	}
}

public interface ISellable
{
	decimal SalePrice {get;}
	DateTime SaleDate {get;}
	bool Sell(decimal price);
	DateTime LastInventoried {get;set;}
}

public class Coin : ISellable
{
	public decimal SalePrice { get; private set; }
	public DateTime SaleDate { get; private set; }
	public DateTime LastInventoried {get;set;}
	
	private bool isSold;
	
	public bool Sell(decimal price)
	{
		if(isSold == true)
			return false;
			
		isSold = true;
		SalePrice = price;
		SaleDate = DateTime.Now;
		return isSold;		
	}
}

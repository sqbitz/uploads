using System;
using System.Collections.Generic;

public class Run
{
	public static void Main()
	{	
		var cs101 = new SchoolCourse("CS101");		
		cs101.AddStudent("Jack");
		var numStudents = cs101.AddStudent("James");
		var exists = cs101.IsEnrolled("Susan");
		Console.WriteLine(cs101.Name + " " + numStudents);
		
		var cs200 = new SchoolCourse() {
			Name = "CS200"
		};
		
		Console.ReadLine();
	}
}
using System;
using System.Collections.Generic;

public class SchoolCourse
{
	public string Name;
	protected HashSet<string> students;
	
	public string DateString {
		get { 
			return DateTime.Now.ToShortDateString();
		}
	}
	
	public SchoolCourse()
	{
		students = new HashSet<string>();
	}
	
	public SchoolCourse(string courseName)
	{
		students = new HashSet<string>();
		Name = courseName;
	}
	
	//Returns the number of students in the class
	public int AddStudent(string studentName)
	{
		students.Add(studentName);
		return students.Count;
	}
	
	//Returns  true  if the student is enrolled
	public bool IsEnrolled(string studentName)
	{
		return students.Contains(studentName);
	}
}

public class MathCourse : SchoolCourse
{
	public int GradeLevel;
	
	public MathCourse(string courseName) : base(courseName)
	{
	}
	
	public string[] GetStudents()
	{
		var ret = new string[students.Count];
		int i = 0;
		foreach(var s in students)
			ret[i++] = s;
			
		return ret;
	}
}

public interface I
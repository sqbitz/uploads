using System;

public class ArraysLoops
{
	public static void Main()
	{
		var a = new int[5,5,3];
		var b = new[*,*,*] { {5,5,3} };
		Console.WriteLine(a[0,0,0]);		
	
		Console.Write("Enter a length for your array: ");
		var arrayLength = int.Parse(Console.ReadLine());
		
		Console.WriteLine("Creating array of length " + arrayLength);
		var arr = new int[arrayLength];
		for(var i = 0; i < arrayLength; i++)
		{
			Console.Write("Enter a value for array index " + i + ": ");
			arr[i] = int.Parse(Console.ReadLine());
		}
		
		foreach(var i in arr)
			Console.Write(i + " ");
			
		Console.WriteLine();
		Console.Write("Enter a number to add: ");
		var num = int.Parse(Console.ReadLine());
		
		Console.WriteLine("Adding " + num + " to each item");
		for(var i = 0; i < arrayLength; i++)
			arr[i] += num;
			
		foreach(var i in arr)
			Console.Write(i + " ");
			
		Console.WriteLine();
		var bArr = new bool[arrayLength];
		for(var i = 0; i < arrayLength; i++)
			bArr[i] = arr[i] >= 50;			
		
		for(var i = 0; i < arrayLength; i++)
			Console.WriteLine(arr[i].ToString().PadRight(5) + bArr[i]);		
		
		Console.ReadLine();
	}
}
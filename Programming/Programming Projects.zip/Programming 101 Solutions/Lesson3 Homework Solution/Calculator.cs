using System;
public class Calculator
{
	public static void Main()
	{
		Console.Write("Please enter a number: ");
		var intVal1 = int.Parse(Console.ReadLine());
		Console.WriteLine("Please enter an operator");
		Console.Write("Valid Ops: +-/* == != < >    :");
		var strOp = Console.ReadLine();
		Console.Write("Please enter a number: ");
		var intVal2 = int.Parse(Console.ReadLine());

		Console.Write(intVal1 + " " + strOp + " " + intVal2 + " = ");
		if(strOp == "+")
			Console.WriteLine(intVal1 + intVal2);
		else if(strOp == "-")
			Console.WriteLine(intVal1 - intVal2);
		else if(strOp == "*")
			Console.WriteLine(intVal1 * intVal2);
		else if(strOp == "/")
			Console.WriteLine(intVal1 / intVal2);
		else if(strOp == "==")
			Console.WriteLine(intVal1 == intVal2);
		else if(strOp == "!=")
			Console.WriteLine(intVal1 != intVal2);
		else if(strOp == ">")
			Console.WriteLine(intVal1 > intVal2);
		else if(strOp == "<")
			Console.WriteLine(intVal1 < intVal2);

		Console.ReadLine();	
	}
}
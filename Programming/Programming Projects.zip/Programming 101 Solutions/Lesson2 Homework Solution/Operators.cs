using System;
public class OperatorsLab
{
	public static void Main()
	{

		Console.Write("Please enter a number: ");
		var numVal = int.Parse(Console.ReadLine());
		
		if(numVal > 5)
			Console.WriteLine(numVal + " is greater than 5");
		else
			Console.WriteLine(numVal + " is 5 or less");
			
		numVal++;
		Console.WriteLine("numVal is now " + numVal);
		Console.ReadLine();
		
		Console.Write("Please enter a string: ");
		var strVal = Console.ReadLine();
		
		if(strVal == "Time")
			Console.WriteLine(DateTime.Now);
		else if(strVal == "Hello")
			Console.WriteLine("Hey what's up?");
		else if(strVal == "GoodBye")
			Console.WriteLine("See you later!");
		



		//Current Hour in 24 hour time
		var nowHour = DateTime.Now.Hour;
		
		var tod = "";
		if(nowHour >= 0 && nowHour < 12)
			tod = "Morning";
		else if(nowHour >= 12 && nowHour < 24)
			tod = "Afternoon";
			
		Console.WriteLine("Now " + tod);


















		Console.ReadLine();
	}
}
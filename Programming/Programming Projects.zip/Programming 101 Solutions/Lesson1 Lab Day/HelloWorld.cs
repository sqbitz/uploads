﻿using System;
using System.Text;

public class HelloWorld
{
	public static void Main()
	{
		var b = "";
		
		Console.WriteLine("Hello World");
		Console.ReadLine();
		Console.WriteLine(DateTime.Now);

		var sb = new StringBuilder();
		while(true)
		{
			var input = Console.ReadKey(true);
			if(input.Key == ConsoleKey.Enter)
				break;
				
			sb.Append(input.KeyChar);
			Console.CursorLeft = Console.WindowWidth / 2 - (sb.Length - 1) / 2;
			Console.Write(sb);
		}
		
		Console.WriteLine();
		Console.WriteLine(sb);
		
		
		Console.ReadLine();
	}
}

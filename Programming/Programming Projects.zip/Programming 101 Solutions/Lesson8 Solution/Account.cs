﻿using System;
using System.Diagnostics;
using System.Text;
using System.IO;

public class Account
{
	private string pin;
	private string accountNumber;
	private DateTime lastLogin;
	private decimal balance;
	
	public Account(string accountNum, string PIN, string LastLogin, string currBalance)
	{
		accountNumber = accountNum;
		pin = PIN;
		lastLogin = DateTime.Parse(LastLogin);
		balance = decimal.Parse(currBalance);
	}
	
	public bool CheckPIN(string PIN)
	{
		return PIN == pin;
	}
	
	public decimal GetBalance()
	{
		return balance;
	}
	
	public decimal Withdraw(decimal amount)
	{
		balance = balance - amount;
		
		return balance;
	}
	
	public decimal Deposit(decimal amount)
	{
		balance = balance + amount;
		return balance;
	}
}

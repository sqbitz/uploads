using System;
using System.Diagnostics;
using System.Text;
using System.IO;
using System.Collections.Generic;

public class ATM
{
	private Dictionary<string, Account> accounts = new Dictionary<string, Account>();
	private string filename = "accounts.csv";
	private string headerLine;
	public ATM()
	{
		var lines = File.ReadAllLines(filename);
		headerLine = lines[0];
		
		//Skip the header line
		for(var i = 1; i < lines.Length; i++)
		{
			var split = lines[i].Split(',');
			var acct = new Account(split[0], split[1], split[2], split[3]);
			accounts[split[0]] = acct;
		}
		
		Console.WriteLine("Loaded {0} accounts", accounts.Count);
	}
	
	public void Run()
	{
		while(true)
		{
			drawInterface();
			Console.Write("Please enter your account number and press <Enter>: ");
			var acctNum = Console.ReadLine();
	
			if(!accounts.ContainsKey(acctNum))
			{
				drawInterface();
				Console.ForegroundColor = ConsoleColor.Red;
				write("Unable to find account.  Please try again.");
				Console.ReadLine();
				continue;
			}
			
			var acct = accounts[acctNum];
			write("Please enter your account PIN and press <Enter>:    ");
			var pin = Console.ReadLine();
			var match = acct.CheckPIN(pin);
			if(!match)
			{
				drawInterface();
				write("PIN Didn't Match!", ConsoleColor.Red);
				Console.ReadLine();
				continue;
			}
			
			handleAccount(acct);			
		}
	}
	
	private void handleAccount(Account account)
	{
		while(true)
		{
			drawInterface();
			writeLine("Welcome!  Your balance is " + account.GetBalance().ToString("c") + ".");
			writeLine("");
			writeLine("Press the number for the option you want.");
			writeLine("1.  Deposit");
			writeLine("2.  Withdraw");
			writeLine("3.  Exit");
			var option = Console.ReadLine();
			
			if(option == "1")
			{
				writeLine("How much do you want to deposit? ");
				var amt = decimal.Parse(Console.ReadLine().Replace("$", "").Trim());
				account.Deposit(amt);
			}		
			if(option == "2")
			{
				writeLine("How much do you want to withdraw? ");
				var amt = decimal.Parse(Console.ReadLine().Replace("$", "").Trim());
				account.Withdraw(amt);
			}
			else if(option == "3")
			{
				writeLine("Thank you for banking with us!");
				System.Threading.Thread.Sleep(2000);
				return;
			}
		}
	}
	
	private void write(string s, ConsoleColor color)
	{
		Console.ForegroundColor = color;
		Console.SetCursorPosition(20, Console.CursorTop);
		Console.Write(s);
		Console.ResetColor();
	}
	
	private void write(string s)
	{
		write(s, ConsoleColor.White);
	}
	
	private void writeLine(string s, ConsoleColor color)
	{
		write(s, color);
		Console.WriteLine();
		Console.SetCursorPosition(20, Console.CursorTop);
	}
	
	private void writeLine(string s)
	{
		writeLine(s, ConsoleColor.White);
	}
	
	private void drawInterface()
	{
		Console.Clear();
		Console.ResetColor();
		Console.SetCursorPosition(4,3);
		//Console.Write("??????");
		for(var i = 4; i < Console.WindowWidth - 5; i++)
			Console.Write("=");
		Console.WriteLine();
		
		for(var i = 3; i < Console.WindowHeight - 6; i++)
		{
			Console.Write("    |");
			Console.SetCursorPosition(Console.WindowWidth - 6, Console.CursorTop);
			Console.WriteLine("|");
		}
		
		Console.Write("    ");
		for(var i = 4; i < Console.WindowWidth - 5; i++)
			Console.Write("=");
			
		
		Console.SetCursorPosition(20, 6);
		Console.ForegroundColor = ConsoleColor.Green;
		Console.Write("Welcome to RAATM");
		
		setCursorPos();
		Console.ResetColor();
	}
	
	private void setCursorPos()
	{
		Console.SetCursorPosition(20, 10);
	}	
}
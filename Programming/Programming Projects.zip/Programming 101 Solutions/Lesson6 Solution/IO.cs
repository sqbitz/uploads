﻿using System;
using System.Diagnostics;
using System.Text;
using System.IO;

public class IO
{
	public static void Main()
	{		
		var lines = File.ReadAllLines("inmates.csv");
		using(var sw = new StreamWriter("inmatesNew.csv"))
			foreach(var l in lines)
			{
				var split = l.Split(',');
				for(var i = 0; i < split.Length; i++)
				{
					var value = split[i];
					
					if(i == 2)
						value = (int.Parse(value) + 5).ToString();
					if(i == 5)
						value = DateTime.Now.ToShortDateString();
					
					sw.Write(value + ",");
				}
				
				sw.WriteLine("released");
			}
	}
}

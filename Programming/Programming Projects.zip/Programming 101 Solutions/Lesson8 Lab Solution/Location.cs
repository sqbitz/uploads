using System;
using System.Collections.Generic;

public class Location
{
	public int Acres;
	public double Latitude;
	public double Longitude;
	
	public Location()
	{ 
	
	}
}

public class Building : Location
{
	public decimal SquareFeet;
	public int Doors;
}

public class House : Building
{
	public int Rooms;
}

public class Barn : Building
{
	public List<Stall> Stalls {get;set;}
	public Barn()
	{
		Stalls = new List<Stall>();
	}
	
	public class Stall
	{
		public int MaxAnimals {get;set;}
	
		private List<Animal> animals;
		public Stall(int maxAnimals)
		{
			MaxAnimals = maxAnimals;
			animals = new List<Animal>();
		}
	
		public bool AddAnimal(Animal a)
		{
			if(animals.Count + 1 >= MaxAnimals)
				return false;
	
			animals.Add(a);
			return true;
		}	
	}
}

public class Field : Location
{
	public Crop Crop {get; set;}
	
	public decimal CalculateProfit(decimal AcreSalePrice)
	{
		if(Crop == null)
			return 0;
			
		var daysSincePlanting = (DateTime.Now - Crop.PlantedDate).TotalDays;
		var maintenanceCost = Acres * Crop.AcreDailyMaintenanceCost * (decimal)daysSincePlanting;
		
		return (Crop.AcrePurchaseCost * Acres)- maintenanceCost + (AcreSalePrice * Acres);
	}
}

public class Pen : Location
{
	public List<Animal> Animals {get;set;}
	public Pen()
	{
		Animals = new List<Animal>();
	}
}
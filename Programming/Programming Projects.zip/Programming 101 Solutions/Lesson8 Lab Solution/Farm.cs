using System;
using System.Collections.Generic;

public class Farm
{
	public string Name {get;set;}
	public string Address {get;set;}
	public List<Location> Locations {get;set;}
	
	public Farm(string name, string address)
	{
		Name = name;
		Address = address;
		
		Locations = new List<Location>();
	}
}
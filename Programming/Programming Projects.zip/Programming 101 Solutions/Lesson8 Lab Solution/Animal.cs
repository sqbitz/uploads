using System;
using System.Collections.Generic;

public class Animal
{
	public decimal PurchasePrice;
	public decimal DailyMaintenanceCost;
	
	public DateTime BirthDate;
	public DateTime PurchaseDate;
	
	public decimal CalculateCost()
	{
		var days = (DateTime.Now - BirthDate).TotalDays;
		return PurchasePrice + (DailyMaintenanceCost * (decimal)days);
	}
	
	public Animal(decimal purchase, decimal maint, DateTime birth, DateTime purchased)
	{
		PurchasePrice = purchase;
		DailyMaintenanceCost = maint;
		
		PurchaseDate = purchased;
		BirthDate = birth;
	}	
}

public class Cow : Animal, IButcherable
{
	private decimal salePrice;
	public Cow(decimal purchase, decimal maint, decimal salePrice,
				DateTime birth, DateTime purchased) : base(purchase, maint, 
																birth, purchased)
	{
		this.salePrice = salePrice;
	}
	
	public decimal CalculateProfit()
	{
		return salePrice - CalculateCost();
	}
	
	public decimal Weight {get {
		return 0;
	}
	set {
		
	}}
	public decimal SalePricePerPound {get {return 0; } }
	public bool WasButchered {get { return true; } }
	
	public void Butcher(decimal pricePerPound){
	
	}
}

public class Horse : Animal
{
	public Horse(decimal purchase, decimal maint, DateTime birth, DateTime purchased) : base(purchase, maint, birth, purchased)
	{
	
	}
	public decimal Hands {get;set;}
}


public class Chicken : Animal, ISellable
{
	public Chicken(decimal purchase, decimal maint, DateTime birth, DateTime purchased) : base(purchase, maint, birth, purchased)
	{}
	
	public decimal SalePrice {get;set;}
	public decimal CalculateProfit()
	{
		return ProfitFromEggs + SalePrice - CalculateCost();
	}
	
	public int NumEggsLayed { get;set;}
	public decimal ProfitFromEggs {get;set;}
}

public interface IHasProfit
{
	decimal CalculateProfit();
}

public interface ISellable : IHasProfit
{
	decimal SalePrice {get;set;}
}
public interface IButcherable : IHasProfit
{
	decimal Weight {get;set;}
	decimal SalePricePerPound {get; }
	bool WasButchered {get; }
	
	void Butcher(decimal pricePerPound);
}
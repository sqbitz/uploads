﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

public class LabDay
{
	public static void Main()
	{
		var b = Console.ReadLine();
		Console.WriteLine("You typed: " + b);
		
		
		
		
		
		Console.ReadLine();

















		try
		{
			var a = new PostfixInfix();
			a.Run();
		}
		catch(Exception c)
		{
			Console.WriteLine(c);
		}
		
		Console.ReadLine();
	}
}

public class LabStuff1
{
	public void Run()
	{
		Console.WriteLine("Hello World!");
		Console.WriteLine("My name is C.R.A.P.e");
		Console.WriteLine("Do you want to play a game?");
		var input = Console.ReadLine();
		Console.WriteLine("You said: " + input);
		Console.WriteLine("I don't like your answer.");
		input = Console.ReadLine();
		Console.WriteLine("Now you are talking crap...");
		var num = int.Parse(Console.ReadLine());
		var carp = 5;
		carp = 7 * carp;
		Console.WriteLine("You entered " + carp);
		
		
		var rl = Console.ReadLine();
		if(rl == "Yo")
			Console.WriteLine("Yo back at ya!");
		else if(rl == "hi!")
			Console.WriteLine("Hi back!");
		else if(rl == "really?");
			Console.WriteLine("yep... Really.");
	}
	
	public void Screenshot()
	{
		var a = Console.ReadLine();
		if(a == "5")
		{
			var p = int.Parse(a);
			Console.WriteLine(p * 2);
		}
		else
			Console.WriteLine(a);
			
		var arr = new int[5];
		for(var i = 0; i < arr.Length; i++)
		{
			var b = Console.ReadLine();
			arr[i] = int.Parse(b);
		}
		
		int c = 0;
		while(c < 5)
			Console.WriteLine(++c);
	}
}



public class LabStuff3
{
	public void Run()
	{
	
	
		int hrs = TimeSpan.FromMinutes(66).Hours;
		Console.WriteLine(hrs);
		double hrs2 = TimeSpan.FromMinutes(66).TotalHours;
		Console.WriteLine(hrs2);
	
	
	
		var a = 13.0;
		var b = 3;
		var c = a/b;
		Console.WriteLine(c);
		
		
		Console.Write("Enter 1st #:");
		var num1 = Console.ReadLine();
		
		Console.Write("Enter 2nd #:");
		var num2 = Console.ReadLine();
		
		Console.WriteLine(num1 + num2);
		//Console.WriteLine(num1 * num2);
		
		
		
		var dt = DateTime.Now;
		
		var dtPlusOneMonth = dt.AddMonths(1);
		var strNextMonth = dtPlusOneMonth.ToString("MM/1/yyyy");
		var nextMonth = DateTime.Parse(strNextMonth);
		var lastDayOfThisMonth = nextMonth.AddDays(-1);
		Console.WriteLine(dt);
		Console.WriteLine(nextMonth);		
		Console.WriteLine(lastDayOfThisMonth);
		
		
		Console.WriteLine(dt.Hour);
		dt = dt.AddHours(6);
		Console.WriteLine(dt.Hour);
		
		
		var user = Console.ReadLine();
		var now = DateTime.Now;
		Console.WriteLine("Hi {0}! it's {1:MMM} the {1:dd}", user, now);       
		Console.WriteLine("5/3={0,2}", 5.0/3);
		Console.WriteLine("5/3={0,2:f2}", 5.0/3);
		
		
		Console.Clear();
		
		var username = Console.ReadLine();
		Console.WriteLine("Welcome{0,10}!", username);
		Console.WriteLine("Welcome{0,-10}!", username);
		
		Console.WriteLine("{0}+{1}={2}", 5, 6, 5+6);
		Console.WriteLine("{0:n0}*{1:n0}={2:n0}", 60, 59, 60*59);
		Console.WriteLine("{0}/{1}={2:f}",  6,   9, 6/9);
		Console.WriteLine("{0}/{1}={2:f}",  6.0, 9, 6.0/9);
		Console.WriteLine("{0}/{1}={2:f7}", 6.0, 9, 6.0/9);
		
		var arr = new int[3];
		//arr[3] = 12;

		//for(var i = 0; i <= arr.Length; i++)
		//	Console.WriteLine("index {0} = {1}", i, arr[i]);
		
	}
}


public class IntParse
{
	public void Run()
	{
		/*
		var input = Console.ReadLine();
		var sw = new Stopwatch();
		sw.Start();
		Try1(input);
		Console.WriteLine("Elapsed: " + sw.ElapsedMilliseconds);
		sw.Reset();
		sw.Start();
		Try2(input);
		Console.WriteLine("Elapsed: " + sw.ElapsedMilliseconds);
		sw.Reset();
		sw.Start();
		Try3(input);
		Console.WriteLine("Elapsed: " + sw.ElapsedMilliseconds);
		sw.Reset();
		*/
	
	}
	public void Try1()//string input)
	{
		var input = Console.ReadLine();
		
		var x = 0;
		var placeValue = 1;
		
		for(var i = input.Length - 1; i >= 0; i--)
		{
			var chars = "0123456789";
			var digit = chars.IndexOf(input[i]);
			
			x += digit * placeValue;
			placeValue = placeValue * 10;
		}
		
		Console.WriteLine(x);
		
	}
	
	public void Try2()//string input)
	{
		var input = Console.ReadLine();
		
		var x = 0;
		var placeValue = 1;
		
		for(var i = input.Length - 1; i >= 0; i--)
		{
			var digitChar = input[i];
			var digit = 0;
			if(digitChar == '1')
				digit = 1;
			else if(digitChar == '2')
				digit = 2;
			else if(digitChar == '3')
				digit = 3;
			else if(digitChar == '4')
				digit = 4;
			else if(digitChar == '5')
				digit = 5;
			else if(digitChar == '6')
				digit = 6;
			else if(digitChar == '7')
				digit = 7;
			else if(digitChar == '8')
				digit = 8;
			else if(digitChar == '9')
				digit = 9;
							
			x += digit * placeValue;
			placeValue = placeValue * 10;
		}
		
		Console.WriteLine(x);
		
	}
	
	public void Try3()//string input)
	{
		var input = Console.ReadLine();
		
		var num = 0;
		while(input != num.ToString())
			num++;
			
		Console.WriteLine(num);
	}
}		
		
		
public class PostfixInfix
{
	public void Run()
	{			
		//Postfix / Infix Calculator
		var queue = new Queue<string>();
		var stack = new Stack<string>();
		var rank = new Dictionary<string, int>() {
			{ "(", 6 },	{ ")", 5 },
			{ "*", 4 },	{ "/", 3 },
			{ "+", 2 },	{ "-", 1 }	};

		var prob = "5 * 6 + ( 4 - 2 )";
		foreach(var t in prob.Split(' '))
		{
			int i;
			if(int.TryParse(t, out i))
				queue.Enqueue(t);
			else if(t == "(")
				stack.Push("(");
			else if(t == ")") {
				while(stack.Any() 
						&& stack.Peek() != "(")
					queue.Enqueue(stack.Pop());
				stack.Pop();
			}
			else {
				while(stack.Any() 
						&& rank[t] < rank[stack.Peek()] 
						&& stack.Peek() != "(")
				{
					var pop = stack.Pop();
					Console.WriteLine("opPop: " + pop);
					queue.Enqueue(pop);
				}
				stack.Push(t);
			}
		}		
		while(stack.Any())
			queue.Enqueue(stack.Pop());
		prob = string.Join(" ", queue.ToArray());
		Console.WriteLine(prob);
		
		
		stack.Clear();
		foreach(var t in prob.Split(' '))
		{
			stack.Push(t);
			Console.WriteLine("Push " + t);
			if("+-*/".Any(opt => opt.ToString() == t))
			{
				var op = stack.Pop();
				var y = int.Parse(stack.Pop());
				var x = int.Parse(stack.Pop());
				
				if(op == "+")
					stack.Push((x + y).ToString());
				else if(op == "*")
					stack.Push((x * y).ToString());
				else if(op == "-")
					stack.Push((x - y).ToString());
			}
		}
		Console.WriteLine("Answer: " + stack.Pop());
		
		
		Console.WriteLine("\n\n\n\n\n");
	}
}
	
public class CaesarCipher
{
	public void Run()
	{
		var rand = new Random();
		var letters = "abcdefghijklmnopqrstuvwxyz 1234567890";
		var qE = new Queue<char>(letters);
		var qD = new Queue<char>(letters.OrderBy(x => rand.Next()));
		var encrypt = new Dictionary<char, char>();
		var decrypt = new Dictionary<char, char>();
		while(qE.Any())
		{
			var e = qE.Dequeue();
			var d = qD.Dequeue();
			encrypt[e] = d;
			decrypt[d] = e;
		}


		var sbE = new StringBuilder();
		var sbD = new StringBuilder();
		foreach(var k in encrypt.Keys)
		{
			sbE.Append(k);
			sbD.Append(encrypt[k]);
		}
		Console.ForegroundColor = ConsoleColor.Red;
		Console.WriteLine(" " + sbE);
		Console.ForegroundColor = ConsoleColor.DarkGreen;
		Console.WriteLine(" " + sbD);

		Console.ForegroundColor = ConsoleColor.DarkBlue;
		Console.Write("\n\n Please enter your message to encrypt\n ");
		Console.ResetColor();
		var message = Console.ReadLine();

		var encryptedMessage = new StringBuilder();
		foreach(var l in message)
			encryptedMessage.Append(encrypt[l]);

		Console.Write("\n\n Encrypted: ");
		Console.ForegroundColor = ConsoleColor.DarkGreen;
		Console.WriteLine(encryptedMessage);

		var decryptedMessage = new StringBuilder();
		foreach(var el in encryptedMessage.ToString())
			decryptedMessage.Append(decrypt[el]);

		Console.ResetColor();
		Console.Write(" Decrypted: ");
		Console.ForegroundColor = ConsoleColor.Red;
		Console.WriteLine(decryptedMessage);

		Console.ResetColor();
	}
}

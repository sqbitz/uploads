﻿using System;
using System.Collections.Generic;

public class Collections
{
	public static void Main()
	{	
		var intList = new List<int>();
		
		int num;
		do
		{
			num = int.Parse(Console.ReadLine());
			intList.Add(num);
		} while(num != 0);
	
		foreach(var i in intList)
			Console.Write(i + " ");
	
		Console.Write("Enter a number to add: ");
		num = int.Parse(Console.ReadLine());
	
		Console.WriteLine("Adding " + num + " to each item");
		var bList = new List<bool>();
		for(var i = 0; i < intList.Count; i++)
		{
			intList[i] += num;
			bList.Add(intList[i] >= 50);
		}
	
		for(var i = 0; i < intList.Count; i++)
			Console.WriteLine(intList[i].ToString().PadRight(5) + bList[i]);	
				
		Console.ReadLine();	
	}
}

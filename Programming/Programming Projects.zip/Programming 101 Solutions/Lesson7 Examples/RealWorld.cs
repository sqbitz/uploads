﻿using System;
using System.Collections.Generic;

public class Record
{
	public int Year {get;set;}
	
	public string ID {get;set;}
	
	public DateTime Created {get;set;}
	public DateTime LastUpdated {get;set;}
	public DateTime DueDate {get;set;}
	public DateTime LastPayment {get;set;}
	
	public string RecordType {get;set;}
	
	public decimal AmountDue {get;set;}
	public decimal AmountPaid {get;set;}
	public decimal OriginalAmountDue {get;set;}	
}

public class TaxRecord : Record
{
	public string OwnerName1 {get;set;}
	public string Ownername2 {get;set;}
	
	public Address OwnerAddress {get;set;}
	public Address LocationAddress {get;set;}
	
	public int AssessedValue {get;set;}
	public int AppraisedValue {get;set;}
}

public class UtilityRecord : Record
{
	public string AccountName {get;set;}
	public Address OwnerAddress {get;set;}
	public Address LocationAddress {get;set;}
	
	public int WaterUsage {get;set;}
	public int SewerUsage {get;set;}
	public int ElectricityUsage {get;set;}
}

public class SCTaxRecord : TaxRecord
{
	public DateTime PenaltyDate1 {get;set;}
	public DateTime PenaltyDate2 {get;set;}
	public decimal PenaltyAmount1 {get;set;}
	public decimal PenaltyAmount2 {get;set;}
	
	public decimal AmountDue {
		get {
			var ret = base.AmountDue;
			if(DateTime.Now > PenaltyDate1)
				ret += PenaltyAmount1;
			if(DateTime.Now > PenaltyDate2)
				ret += PenaltyAmount2;
				
			return ret;
		}
		set {
			base.AmountDue = value;
		}
	}
}

public class Address 
{
	public string Line1 {get;set;}
	public string Line2 {get;set;}
	public string Line3 {get;set;}
	public string City {get;set;}
	public States State {get;set;}
	public string Zip {get;set;}
	
	public string ToString() {
		return Line1 + "\n" 
				+ (Line2 != "" ? Line2 + "\n" : "")
				+ (Line3 != "" ? Line3 + "\n" : "")
				+ City + ", " + State + "  " + Zip;
	}
}

public enum States { SC, GA, NC, TX, IN, OH, CA }

public interface ISearchable
{
	List<string> SearchValues {get;set;}
}

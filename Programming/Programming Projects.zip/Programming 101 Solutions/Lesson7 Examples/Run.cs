﻿using System;
using System.Collections.Generic;

public class Run
{
	public static void Main()
	{	
		
		try
		{
			Console.WriteLine("Hi!");
		
			var course = new MathCourse("Math 101", "Algebra");
			Console.WriteLine(course.Name);
			
			while(true)
			{
				Console.Write("Name: ");
				string name = Console.ReadLine();
				if(name == "")
					break;
					
				Console.Write("DOB:  ");
				var dob = DateTime.Parse(Console.ReadLine());
				Console.Write("ID:   ");
				var id = int.Parse(Console.ReadLine());
				
				course.Students.Add(new Student(name, dob, id, 15));
			}
		
			course.PrintCourseInfo();
			course.PrintStudents();
		
		
		
		




















		
		
		
		
		/*
		var cs101 = new SchoolCourse("CS101");		
		cs101.AddStudent("Jack");
		cs101.AddStudent("James		");
		var numStudents = cs101.AddStudent("James");
		
		var enrolled1 = cs101.IsEnrolled("Susan");
		var enrolled2 = cs101.IsEnrolled("James");
		
		Console.WriteLine(cs101.Name + "   " + numStudents + " Students     Susan Enrolled? " + enrolled1 + "        James Enrolled? " + enrolled2);
		
		
		var cs200 = new SchoolCourse() {
			Name = "CS200"
		};
		cs200.Name = "CS200-1";
		numStudents = cs200.AddStudent("Jack");
		
		enrolled1 = cs200.IsEnrolled("Susan");
		enrolled2 = cs200.IsEnrolled("James");
		
		Console.WriteLine(cs200.Name + " " + numStudents + " Students     Susan Enrolled? " + enrolled1 + "        James Enrolled? " + enrolled2);
		
		
		var math300 = new MathCourse("Math300");
		math300.AddStudent("Amber");
		math300.AddStudent("Joe");
		math300.AddStudent("Jack");
		numStudents = math300.AddStudent("James");
		
		enrolled1 = math300.IsEnrolled("Susan");
		enrolled2 = math300.IsEnrolled("James");
		
		Console.WriteLine(math300.Name + " " + numStudents + " Students     Susan Enrolled? " + enrolled1 + "        James Enrolled? " + enrolled2);
		foreach(var s in math300.GetStudents())
			Console.WriteLine("   " + s);
		*/
		}
		catch(Exception c)
		{
			Console.WriteLine("Error: " + c);
		}		
		Console.ReadLine();
	}
}

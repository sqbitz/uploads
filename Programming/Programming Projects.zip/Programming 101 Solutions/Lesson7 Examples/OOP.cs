﻿using System;
using System.Collections.Generic;

public class SchoolCourse2
{
	public string Name;
	protected HashSet<string> students;
	
	public string DateString {
		get { 
			return DateTime.Now.ToShortDateString();
		}
	}
	
	public SchoolCourse2()
	{
		students = new HashSet<string>();
	}
	
	public SchoolCourse2(string courseName) : this()
	{
		Name = courseName;
	}
	
	//Returns the number of students in the class
	public int AddStudent(string studentName)
	{
		students.Add(studentName);
		return students.Count;
	}
	
	//Returns  true  if the student is enrolled
	public bool IsEnrolled(string studentName)
	{
		return students.Contains(studentName);
	}
}

public class MathCourse2 : SchoolCourse2
{
	public int GradeLevel;
	
	public MathCourse2(string courseName) : base(courseName)
	{
	}
	
	public bool IsEnrolled(string studentName)
	{
		Console.WriteLine("MathCourse IsEnrolled");
		return base.IsEnrolled(studentName);
	}
	
	public string[] GetStudents()
	{
		var ret = new string[students.Count];
		int i = 0;
		foreach(var s in students)
			ret[i++] = s;
			
		return ret;
	}
}

public interface ISellable
{
	decimal SalePrice {get;}
	DateTime SaleDate {get;}
	bool Sell(decimal price);
	DateTime LastInventoried {get;set;}
}

public class Coin : ISellable
{
	public decimal SalePrice {get; private set;}
	public DateTime SaleDate {get;private set;}
	public DateTime LastInventoried {get;set;}
	
	private bool isSold;
	
	public bool Sell(decimal price)
	{
		if(isSold == true)
			return false;
			
		isSold = true;
		SalePrice = price;
		SaleDate = DateTime.Now;
		return isSold;
	}
}




public class Person
{
	public string Name;
	public int ID;
	public DateTime DOB;
	
	public Person(string name, DateTime dateOfBirth, int id)
	{
		Name = name;
		DOB = dateOfBirth;
		ID = id;
	}
}

public class Student : Person
{
	public DateTime EnrollmentDate;
	public int Grade;
	
	public Student(string name, DateTime dateOfBirth, int id, int grade) 
		: base(name, dateOfBirth, id)
	{
		Grade = grade;
	}
}

public class Teacher : Person
{
	public DateTime HireDate;
	public Teacher(string name, DateTime dateOfBirth, int id, DateTime hired) 
		: base(name, dateOfBirth, id)
	{
		HireDate = hired;
		
	}
}

public class SchoolCourse
{
	public Teacher Instructor;
	public List<Student> Students;
	public string Name;
	
	public SchoolCourse(string courseTitle)
	{
			Name = courseTitle;
			Students = new List<Student>();
	}
	
	public void PrintStudents()
	{
		foreach(var s in Students)
		{
			Console.WriteLine("{0,-20} {1:MM-dd-yy} {2}", s.Name, s.DOB, s.ID);
		}
	}	
}

public class MathCourse : SchoolCourse
{
	public string ClassLevel;
	public MathCourse(string name, string level) : base(name)
	{
		ClassLevel = level;
	}
	
	public void PrintCourseInfo()
	{
		Console.WriteLine(Name);
		Console.WriteLine("Math Course -- Level " + ClassLevel);
		
		PrintStudents();
	}	
}

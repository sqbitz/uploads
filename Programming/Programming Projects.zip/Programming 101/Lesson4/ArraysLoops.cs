﻿using System;

public class ArraysLoops
{
	public static void Main()
	{
		//Create an array with a few values
		
		//Print one of the values   
		//How do you print a value?
		
		//Change one of the values 
		//remember Arrays are just a variable... 
		
		var stringToSplit = "Jack,39,4/3/1981,F1,254,McCI";
		//Split the example string above

		//Print the 4th value (remember 0 based indexing!)
		



		
		
		//Lab
		//Have user enter a number... 
		//you'll need to store that in a variable
		
		//Create Array of that size
		
		//Loop through Array	for
		
		//Loop through array and print out each item	foreach
			
			
		
		//Practice
		//Try this on your own
		
			
			
		Console.ReadLine();
	}
}

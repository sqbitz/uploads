using System;
using System.Diagnostics;
using System.Text;
using System.Collections.Generic;
using System.IO;
using System.Web.Script.Serialization;

public class Run
{
	public static void Main()
	{		
		
	}
}
﻿using System;
public class MethodsAndProperties
{
	public static void Main()
	{
		//Experiment with string Methods and Properties
		
		//Print out current date and time
		
		
		
		
		
		//Have user enter a string at least 10 characters long
		
		//Print out the last 3 characters
		
		//Print the first 5 characters as UPPER CASE






		//Store the current date and time as a variable		
		
		//Print out this variable
		
		//Add 4 days to the variable
		
		//Print out the Month and Day of the variable
		
		
		
		
		
		
		
		
		
		//Leave this Console.ReadLine() here to keep your application from closing
		Console.ReadLine();
		
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Collections
{
	public static void Main()
	{
		//Declare a List  What type should it be?
		
		//Start reading numbers from the user  (Going to need a loop... what type?)
				
		//Loop through List and print out each item	foreach
			
		//Have the user enter a number (we're going to add this to each item in  the List we created above)			
		
		//Loop through the List and add the number to each one
		
		//Create the List<bool> and store true if >= 50 and false if < 50
		
		//Print out both Lists side by side
			
		Console.ReadLine();
	}
}

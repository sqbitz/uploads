﻿using System;
using System.Diagnostics;
using System.Text;
using System.IO;

public class IO
{
	public static void Main()
	{
		
		//Before
		//Jack,5/1/1981,60,F6,254,11/26/2020
		
		//After
		//Jack,5/1/1981,65,F6,254,5/19/2021,released
		
		
		//Read in the text file  inmates.csv
		
		//Split each CSV line
		
		//Add 5 to the value in the 3rd column in each line
		
		//Set the value in the 6th column to today’s date
		
		//Add the string "released" as the last value for each line
		
		//Write a new file with the updated data as CSV  (make sure to save it as a different file name!)
	}
}

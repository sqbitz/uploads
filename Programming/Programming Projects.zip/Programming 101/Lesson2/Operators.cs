﻿using System;

public class Operators
{
	public static void Main() 
	{
		//Test Some Operators	

		//Use int.Parse() and .ToString() to convert between ints and strings



		
		
		
		//Have the user enter a number 
		
		
		//Test if the number is greater than or less than a number of your choosing
		
		
		//Print out the result
	
		
		//Increment the number by one and print out the new value
		
		
		
		
		
		
		//Leave this ReadLine here to keep your application from closing
		Console.ReadLine();	
	}
}

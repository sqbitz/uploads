﻿using System;
public class Calculator
{
	public static void Main()
	{
		//Have user enter a number   How do you get input from the user??
		
		//Have user enter an operator
		//Please give the user some instructions here
		
		//Have user enter a second number
		
		//Calculate
		//Going to need a lot of ifs and else ifs for each operator you handle
		//Either store the result in a variable then print it out below
		//or
		//Print out the result inside your if / else if
		
		
		
		//Print out the result
		
		
		
		
		
		
		Console.ReadLine();
	}
}

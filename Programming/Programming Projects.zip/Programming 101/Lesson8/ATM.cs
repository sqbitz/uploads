using System;
using System.Diagnostics;
using System.Text;
using System.IO;

public class ATM
{
	public ATM()
	{
		
	}
	
	public void Run()
	{
	
	}
}
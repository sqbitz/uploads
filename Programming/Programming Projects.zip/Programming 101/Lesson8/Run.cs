﻿using System;
using System.Diagnostics;
using System.Text;
using System.IO;

public class Run
{
	public static void Main()
	{		
		var atm = new ATM();
		atm.Run();	
	}
}
